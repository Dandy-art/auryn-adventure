import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Auryn's Pink Adventure — 2D Fantasy Platformer",
  description:
    "A colorful 2D side-scrolling fantasy platformer. Play as Auryn, the pink magic hero, journey through five worlds and defeat the rival Dandy!",
  keywords: ["platformer game", "2D game", "Auryn", "Dandy", "fantasy platformer", "HTML5 game"],
  authors: [{ name: "Auryn's Pink Adventure" }],
  openGraph: {
    title: "Auryn's Pink Adventure",
    description: "A 2D fantasy platformer starring Auryn vs the rival Dandy — 5 worlds, secrets, and a boss battle!",
    siteName: "Auryn's Pink Adventure",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#ff5fa8",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased overflow-hidden overscroll-none bg-[#170a1e] text-foreground">
        {children}
      </body>
    </html>
  );
}
