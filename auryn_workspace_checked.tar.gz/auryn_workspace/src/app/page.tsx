'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { Game } from '@/game/game';
import type { InputKey } from '@/game/types';

function TouchBtn({
  k, label, sub, gameRef, big, onFire,
}: {
  k: InputKey;
  label: string;
  sub?: string;
  gameRef: React.RefObject<Game | null>;
  big?: boolean;
  onFire?: boolean;
}) {
  const [down, setDown] = useState(false);
  const set = useCallback(
    (v: boolean) => {
      setDown(v);
      gameRef.current?.setKey(k, v);
      if (v && onFire) {
        window.setTimeout(() => {
          setDown(false);
          gameRef.current?.setKey(k, false);
        }, 90);
      }
    },
    [k, gameRef, onFire]
  );
  return (
    <button
      aria-label={sub ?? label}
      className={`flex flex-col items-center justify-center rounded-full border-2 font-black text-white shadow-lg transition-transform select-none ${
        down
          ? 'bg-pink-400/70 border-white scale-95'
          : 'bg-white/15 border-pink-200/60 backdrop-blur-sm'
      } ${big ? 'w-[76px] h-[76px]' : 'w-[60px] h-[60px]'}`}
      style={{ touchAction: 'none' }}
      onPointerDown={(e) => {
        e.preventDefault();
        set(true);
        try {
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        } catch { /* synthetic pointers may fail capture — input still registers */ }
      }}
      onPointerUp={(e) => {
        e.preventDefault();
        set(false);
      }}
      onPointerCancel={() => set(false)}
      onPointerLeave={() => down && set(false)}
      onContextMenu={(e) => e.preventDefault()}
    >
      <span className={big ? 'text-2xl leading-none' : 'text-xl leading-none'}>{label}</span>
      {sub && <span className="text-[9px] tracking-widest opacity-80 mt-0.5">{sub}</span>}
    </button>
  );
}

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const gameRef = useRef<Game | null>(null);
  const [touchMode, setTouchMode] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = new Game(canvas);
    gameRef.current = game;
    // debug/testing hook
    (window as unknown as { __aurynGame?: Game }).__aurynGame = game;

    const coarse = window.matchMedia('(pointer: coarse)');
    const applyCoarse = () => {
      if (coarse.matches) setTouchMode(true);
    };
    // defer state update out of the effect body (async tick)
    const tId = window.setTimeout(applyCoarse, 0);
    coarse.addEventListener?.('change', applyCoarse);
    const onFirstTouch = () => setTouchMode(true);
    window.addEventListener('touchstart', onFirstTouch, { once: true, passive: true });
    const noScroll = (e: TouchEvent) => e.preventDefault();
    document.addEventListener('touchmove', noScroll, { passive: false });

    return () => {
      window.clearTimeout(tId);
      coarse.removeEventListener?.('change', applyCoarse);
      window.removeEventListener('touchstart', onFirstTouch);
      document.removeEventListener('touchmove', noScroll);
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  return (
    <main
      className="fixed inset-0 flex items-center justify-center overflow-hidden bg-[#170a1e] select-none"
      style={{ touchAction: 'none' }}
    >
      <canvas ref={canvasRef} className="block shadow-2xl" />

      {touchMode && (
        <>
          {/* left cluster: movement */}
          <div className="absolute left-3 bottom-5 flex items-end gap-2 z-10">
            <TouchBtn k="left" label="◀" gameRef={gameRef} big />
            <div className="flex flex-col gap-2 pb-1">
              <TouchBtn k="down" label="▼" gameRef={gameRef} onFire />
            </div>
            <TouchBtn k="right" label="▶" gameRef={gameRef} big />
          </div>
          {/* right cluster: actions */}
          <div className="absolute right-3 bottom-5 flex items-end gap-3 z-10">
            <TouchBtn k="attack" label="B" sub="MAGIC" gameRef={gameRef} />
            <TouchBtn k="jump" label="A" sub="JUMP" gameRef={gameRef} big />
          </div>
          {/* pause */}
          <button
            aria-label="Pause"
            className="absolute right-3 top-3 w-12 h-12 rounded-xl bg-white/15 border-2 border-pink-200/60 text-white text-lg font-black z-10"
            style={{ touchAction: 'none' }}
            onPointerDown={(e) => {
              e.preventDefault();
              gameRef.current?.setKey('pause', true);
              window.setTimeout(() => gameRef.current?.setKey('pause', false), 90);
            }}
          >
            ❙❙
          </button>
        </>
      )}
    </main>
  );
}
