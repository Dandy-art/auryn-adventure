// Level construction: tile-grid builder + the five worlds
import { LevelDef, MovingPlatformDef, PipeWarp, ROWS, TILE } from './types';

const px = (col: number) => col * TILE;

class LB {
  g: string[][];
  W: number;
  H = ROWS;
  pipes: PipeWarp[] = [];
  platforms: MovingPlatformDef[] = [];
  castleX = 0;
  boss?: { triggerX: number; left: number; right: number; gateX: number; gateY: number; bossX: number };

  constructor(W: number) {
    this.W = W;
    this.g = Array.from({ length: this.H }, () => Array<string>(W).fill('.'));
  }
  set(x: number, y: number, c: string): void {
    if (x >= 0 && x < this.W && y >= 0 && y < this.H) this.g[y][x] = c;
  }
  fill(x0: number, y0: number, x1: number, y1: number, c: string): void {
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) this.set(x, y, c);
  }
  ground(x0: number, x1: number, top = 13): void {
    for (let x = x0; x <= x1; x++) {
      this.set(x, top, 'G');
      for (let y = top + 1; y < this.H; y++) this.set(x, y, 'R');
    }
  }
  platform(x: number, y: number, w: number, c = 'T'): void {
    for (let i = 0; i < w; i++) this.set(x + i, y, c);
  }
  pipe(x: number, top: number, base = 13, enter?: { destX: number; destY: number }): void {
    this.set(x, top, '[');
    this.set(x + 1, top, ']');
    for (let y = top + 1; y < base; y++) {
      this.set(x, y, '{');
      this.set(x + 1, y, '}');
    }
    if (enter) this.pipes.push({ tx: x, ty: top, destX: enter.destX, destY: enter.destY });
  }
  coins(x: number, y: number, n: number, step = 1): void {
    for (let i = 0; i < n; i++) this.set(x + i * step, y, 'C');
  }
  stairs(x: number, h: number, c = 'R', base = 13): void {
    for (let i = 0; i < h; i++) for (let y = base - 1 - i; y <= base - 1; y++) this.set(x + i, y, c);
  }
  enemy(x: number, y: number, t: number): void {
    this.set(x, y, String(t));
  }
  checkpoint(x: number, top = 13): void {
    this.set(x, top - 1, '*');
  }
  flag(x: number, top = 13): void {
    this.set(x, top - 1, 'F');
  }
  gate(x: number, top = 13): void {
    this.set(x, top - 1, 'E');
  }
  rows(): string[] {
    return this.g.map((r) => r.join(''));
  }
}

// ---------------- WORLD 1 — GREEN MUSHROOM HILLS ----------------
function w1(): LevelDef {
  const b = new LB(252);
  b.ground(0, 46);
  b.ground(51, 62);
  b.ground(67, 80);
  b.ground(85, 99);
  b.ground(108, 149);
  b.ground(158, 224);
  // secret vault beyond the castle
  b.fill(226, 2, 227, 14, 'R');
  b.ground(228, 249);

  // opening blocks
  b.set(14, 9, '?'); b.set(15, 9, 'B'); b.set(16, 9, 'M'); b.set(17, 9, 'B'); b.set(18, 9, '?');
  b.coins(14, 5, 5);
  b.coins(7, 11, 3);
  // pipes
  b.pipe(24, 11);
  b.set(25, 10, '5');
  b.pipe(30, 10);
  b.set(31, 9, '5');
  b.pipe(36, 9, 13, { destX: px(231), destY: 520 }); // secret entrance
  b.coins(41, 11, 3);
  b.enemy(44, 12, 1);
  // first gap + arc of coins
  b.set(47, 10, 'C'); b.set(48, 9, 'C'); b.set(49, 9, 'C'); b.set(50, 10, 'C');
  b.coins(53, 10, 4);
  b.enemy(57, 12, 6); // turtle
  // bridge over gap
  b.platform(63, 10, 4, 'W');
  b.coins(63, 7, 4);
  b.stairs(70, 4);
  b.enemy(76, 12, 2);
  // moving platform across gap 81-84
  b.platforms.push({ x: px(80), y: 10 * 40, w: 120, dx: 60, dy: 0, range: 140, speed: 55 });
  b.set(88, 9, '?'); b.set(89, 9, 'L'); b.set(90, 9, '?');
  b.enemy(93, 12, 1);
  b.checkpoint(96);
  // floating platforms over gap 100-107
  b.platform(101, 10, 3);
  b.platform(105, 8, 3);
  b.coins(101, 8, 2);
  b.coins(105, 6, 3);
  // Dandy's first showdown
  b.coins(118, 9, 4);
  b.enemy(112, 12, 1);
  b.enemy(115, 12, 1);
  b.enemy(122, 12, 4); // DANDY
  b.pipe(126, 11);
  b.set(127, 10, '5');
  b.set(131, 9, '?');
  b.enemy(135, 12, 2);
  b.coins(140, 10, 5);
  // gap with floating shroom platforms
  b.platform(151, 10, 2);
  b.platform(154, 8, 2);
  b.platform(156, 10, 2);
  b.enemy(155, 6, 3);
  b.coins(154, 6, 2);
  // star block + final stretch
  b.set(170, 9, 'N');
  b.enemy(175, 12, 1);
  b.enemy(178, 12, 1);
  b.checkpoint(182);
  b.coins(186, 10, 5);
  b.enemy(196, 12, 6); // turtle
  b.stairs(198, 6);
  b.coins(199, 5, 4);
  b.flag(210);
  b.castleX = px(214);
  // secret vault interior
  b.coins(230, 10, 6);
  b.coins(230, 6, 6);
  b.set(236, 9, 'K');
  b.set(238, 9, 'K');
  b.coins(241, 11, 3);
  b.pipe(244, 10, 13, { destX: px(122), destY: 520 }); // way back
  return {
    world: 1, name: 'Green Mushroom Hills', theme: 'hills',
    rows: b.rows(), startX: px(3), startY: 520,
    pipes: b.pipes, platforms: b.platforms, castleX: b.castleX,
  };
}

// ---------------- WORLD 2 — BLUE SKY KINGDOM ----------------
function w2(): LevelDef {
  const b = new LB(252);
  b.ground(0, 14);
  b.ground(26, 40, 12);
  b.ground(47, 60, 12);
  b.ground(79, 86, 11);
  b.ground(92, 104);
  b.ground(110, 121, 7);
  b.ground(131, 150);
  b.ground(169, 200);
  b.ground(209, 251);
  b.coins(6, 11, 4);
  b.platform(17, 10, 3);
  b.platform(22, 8, 3);
  b.coins(17, 7, 3);
  b.coins(22, 5, 3);
  b.pipe(30, 10, 12);
  b.set(31, 9, '5');
  b.coins(34, 9, 3);
  b.enemy(36, 11, 1);
  b.platforms.push({ x: px(41), y: 9 * 40, w: 120, dx: 60, dy: 0, range: 140, speed: 70 });
  b.enemy(52, 11, 1);
  b.enemy(56, 11, 6); // turtle
  b.coins(55, 9, 3);
  // rope bridge with holes
  b.platform(61, 10, 6, 'W');
  b.platform(69, 10, 6, 'W');
  b.platform(77, 10, 2, 'W');
  b.coins(62, 7, 5);
  b.enemy(70, 7, 3);
  b.set(81, 8, '?'); b.set(82, 8, 'M');
  b.coins(84, 9, 2);
  b.platform(89, 9, 3);
  b.checkpoint(96);
  b.coins(98, 10, 4);
  b.enemy(100, 12, 3);
  // vertical lift up to the sky island
  b.platforms.push({ x: px(106), y: 9 * 40, w: 120, dx: 0, dy: 70, range: 120, speed: 50 });
  b.ground(110, 121, 7);
  b.coins(112, 4, 4);
  b.enemy(114, 6, 1);
  b.platform(124, 9, 3);
  b.platform(128, 11, 3);
  b.enemy(135, 12, 1);
  b.enemy(140, 12, 4); // DANDY — ranged attacks
  b.pipe(145, 11);
  b.set(146, 10, '5');
  b.coins(147, 10, 3);
  // long sky bridge
  b.platform(151, 11, 18, 'W');
  b.coins(154, 8, 4);
  b.coins(160, 9, 4);
  b.enemy(158, 8, 3);
  b.enemy(164, 7, 3);
  b.set(172, 9, '?'); b.set(173, 9, 'K'); b.set(174, 9, '?');
  b.enemy(180, 12, 1);
  b.checkpoint(185);
  b.coins(188, 10, 5);
  b.platforms.push({ x: px(201), y: 10 * 40, w: 120, dx: 55, dy: 0, range: 160, speed: 65 });
  b.enemy(212, 12, 3);
  b.coins(213, 10, 3);
  b.stairs(216, 4);
  b.flag(225);
  b.castleX = px(229);
  return {
    world: 2, name: 'Blue Sky Kingdom', theme: 'sky',
    rows: b.rows(), startX: px(3), startY: 520,
    pipes: b.pipes, platforms: b.platforms, castleX: b.castleX,
  };
}

// ---------------- WORLD 3 — ENCHANTED FOREST ----------------
function w3(): LevelDef {
  const b = new LB(262);
  b.ground(0, 29);
  b.ground(40, 60);
  b.ground(65, 90);
  b.ground(96, 130);
  b.ground(144, 158, 6);
  b.ground(169, 200);
  b.ground(207, 238);
  // secret grotto
  b.fill(239, 0, 240, 14, 'R');
  b.ground(241, 261);

  b.set(12, 9, '?'); b.set(13, 9, 'M'); b.set(14, 9, '?');
  b.pipe(20, 11);
  b.set(21, 10, '5');
  b.coins(6, 11, 3);
  b.set(9, 12, 'm'); b.set(16, 12, 'm'); b.set(24, 12, 'v'); b.set(26, 12, 'm');
  b.platform(31, 10, 3);
  b.platform(35, 8, 3);
  b.coins(31, 8, 3);
  b.coins(35, 6, 2);
  b.enemy(46, 12, 2);
  b.enemy(52, 12, 1);
  b.enemy(55, 12, 1);
  b.coins(50, 10, 4);
  b.platforms.push({ x: px(60), y: 10 * 40, w: 120, dx: 55, dy: 0, range: 120, speed: 60 });
  b.checkpoint(70);
  b.pipe(76, 9, 13, { destX: px(243), destY: 520 }); // into the grotto
  b.coins(79, 10, 4);
  b.enemy(84, 12, 2);
  b.enemy(88, 12, 2);
  b.platform(91, 10, 2);
  b.platform(94, 8, 2);
  b.enemy(93, 6, 3);
  b.coins(94, 6, 2);
  b.enemy(100, 12, 1);
  b.enemy(104, 12, 6); // turtle
  b.enemy(108, 12, 1);
  b.coins(110, 11, 4);
  b.set(115, 9, 'L');
  b.enemy(118, 12, 2);
  b.coins(119, 10, 3);
  b.enemy(122, 12, 4); // DANDY — fast
  b.platform(133, 10, 3);
  b.platform(137, 8, 3);
  b.platform(141, 6, 3);
  b.coins(133, 8, 3);
  b.coins(141, 4, 3);
  b.ground(144, 158, 6);
  b.coins(146, 4, 5);
  b.enemy(150, 5, 2);
  b.platform(161, 8, 3);
  b.platform(165, 10, 3);
  b.checkpoint(172);
  b.pipe(180, 11);
  b.set(181, 10, '5');
  b.set(188, 12, '^'); b.set(189, 12, '^');
  b.enemy(194, 12, 1);
  b.coins(184, 10, 3);
  b.platforms.push({ x: px(200), y: 10 * 40, w: 120, dx: 60, dy: 0, range: 150, speed: 70 });
  b.enemy(214, 12, 2);
  b.coins(215, 10, 3);
  b.flag(225);
  b.castleX = px(229);
  // grotto interior
  b.set(244, 2, 'i'); b.set(250, 2, 'i'); b.set(258, 2, 'i');
  b.coins(243, 10, 8);
  b.set(247, 9, 'K'); b.set(249, 9, 'K');
  b.set(251, 9, 'N');
  b.coins(252, 11, 3);
  b.pipe(256, 10, 13, { destX: px(98), destY: 520 });
  b.set(242, 12, 'i'); b.set(253, 12, 'i'); b.set(259, 12, 'i');
  return {
    world: 3, name: 'Enchanted Forest', theme: 'forest',
    rows: b.rows(), startX: px(3), startY: 520,
    pipes: b.pipes, platforms: b.platforms, castleX: b.castleX,
  };
}

// ---------------- WORLD 4 — CRYSTAL UNDERGROUND ----------------
function w4(): LevelDef {
  const b = new LB(282);
  b.fill(0, 0, 281, 1, 'R'); // cave ceiling
  b.ground(0, 55);
  b.ground(60, 90);
  b.ground(105, 140);
  b.ground(147, 180);
  b.ground(184, 200, 8);
  b.ground(206, 240);
  b.ground(236, 252); // overlaps for castle ground
  // secret vault
  b.fill(253, 0, 254, 14, 'R');
  b.ground(255, 281);

  b.set(10, 9, '?'); b.set(11, 9, 'K'); b.set(12, 9, '?');
  b.set(6, 12, 'i'); b.set(16, 12, 'i'); b.set(24, 12, 'i');
  b.set(9, 2, 'i'); b.set(20, 2, 'i'); b.set(30, 2, 'i');
  b.coins(6, 11, 3);
  b.coins(15, 11, 4);
  b.enemy(34, 12, 1);
  b.set(48, 2, 'i');
  // gap
  b.set(57, 10, 'C'); b.set(58, 9, 'C');
  b.enemy(66, 12, 2);
  b.enemy(72, 12, 1);
  b.pipe(78, 11, 13, { destX: px(257), destY: 520 }); // to the vault
  b.coins(83, 10, 3);
  b.set(88, 12, 'i');
  b.platforms.push({ x: px(91), y: 10 * 40, w: 120, dx: 55, dy: 0, range: 140, speed: 60 });
  b.platforms.push({ x: px(98), y: 8 * 40, w: 120, dx: 0, dy: 65, range: 110, speed: 50 });
  b.coins(92, 7, 2);
  b.coins(99, 5, 2);
  b.set(112, 12, '^'); b.set(113, 12, '^');
  b.enemy(118, 12, 1);
  b.checkpoint(120);
  b.set(125, 12, '^'); b.set(126, 12, '^');
  b.enemy(130, 12, 2);
  b.coins(108, 10, 3);
  b.set(122, 12, 'i'); b.set(134, 2, 'i');
  b.platform(142, 10, 2, 'S');
  b.platform(145, 8, 2, 'S');
  b.coins(142, 8, 2);
  b.set(155, 9, 'L');
  b.enemy(160, 12, 1);
  b.enemy(165, 12, 4); // DANDY — guardian of the deep
  b.enemy(172, 8, 3);
  b.coins(168, 10, 4);
  b.set(178, 12, 'i');
  b.platforms.push({ x: px(181), y: 9 * 40, w: 120, dx: 0, dy: 70, range: 120, speed: 50 });
  b.coins(186, 4, 4);
  b.enemy(190, 7, 1);
  b.set(196, 2, 'i');
  b.platform(203, 10, 2);
  b.checkpoint(208);
  b.enemy(212, 12, 2);
  b.enemy(216, 12, 2);
  b.set(218, 12, '^'); b.set(219, 12, '^');
  b.enemy(224, 12, 1);
  b.coins(210, 10, 4);
  b.set(228, 12, 'i');
  b.flag(232);
  b.castleX = px(236);
  // vault interior
  b.set(256, 2, 'i'); b.set(266, 2, 'i'); b.set(276, 2, 'i');
  b.coins(257, 10, 9);
  b.set(262, 9, 'K'); b.set(264, 9, 'N'); b.set(266, 9, 'L');
  b.coins(268, 11, 4);
  b.pipe(274, 10, 13, { destX: px(108), destY: 520 });
  b.set(260, 12, 'i'); b.set(270, 12, 'i');
  return {
    world: 4, name: 'Crystal Underground', theme: 'cave',
    rows: b.rows(), startX: px(3), startY: 520,
    pipes: b.pipes, platforms: b.platforms, castleX: b.castleX,
  };
}

// ---------------- WORLD 5 — ROYAL FANTASY CASTLE ----------------
function w5(): LevelDef {
  const b = new LB(242);
  b.ground(0, 40);
  b.ground(49, 80);
  b.ground(89, 120);
  b.ground(129, 241);
  b.set(12, 9, '?'); b.set(13, 9, 'M');
  b.set(18, 12, '^'); b.set(19, 12, '^');
  b.pipe(26, 11);
  b.set(27, 10, '5');
  b.coins(6, 11, 4);
  b.coins(14, 10, 3);
  b.enemy(34, 12, 2);
  b.platforms.push({ x: px(41), y: 10 * 40, w: 120, dx: 60, dy: 0, range: 170, speed: 70 });
  b.enemy(54, 12, 2);
  b.enemy(60, 12, 6); // turtle
  b.checkpoint(58);
  b.set(64, 9, 'K');
  b.enemy(70, 7, 3);
  b.coins(66, 10, 4);
  b.set(74, 12, '^'); b.set(75, 12, '^');
  b.platforms.push({ x: px(81), y: 10 * 40, w: 110, dx: 55, dy: 0, range: 130, speed: 65 });
  b.platforms.push({ x: px(86), y: 8 * 40, w: 110, dx: 0, dy: 60, range: 100, speed: 55 });
  b.set(96, 12, '^'); b.set(97, 12, '^');
  b.checkpoint(100);
  b.set(105, 9, 'L');
  b.enemy(110, 12, 2);
  b.pipe(114, 11);
  b.set(115, 10, '5');
  b.coins(106, 10, 3);
  b.platforms.push({ x: px(121), y: 10 * 40, w: 120, dx: 60, dy: 0, range: 150, speed: 70 });
  b.set(135, 9, '?'); b.set(137, 9, '?');
  b.checkpoint(145);
  b.set(150, 12, '^'); b.set(151, 12, '^');
  b.enemy(156, 12, 2);
  b.coins(140, 10, 5);
  b.coins(160, 10, 4);
  b.enemy(163, 12, 2);
  b.coins(176, 10, 5);
  b.enemy(180, 12, 2);
  // boss arena — the throne gate
  b.boss = { triggerX: px(170), left: px(170), right: px(218), gateX: px(226), gateY: 520, bossX: px(205) };
  b.gate(226);
  return {
    world: 5, name: 'Royal Fantasy Castle', theme: 'castle',
    rows: b.rows(), startX: px(3), startY: 520,
    pipes: b.pipes, platforms: b.platforms, castleX: 0, boss: b.boss,
  };
}

export const LEVELS: LevelDef[] = [w1(), w2(), w3(), w4(), w5()];
export function worldMusic(world: number): string {
  return `world${world}`;
}
