// Character & creature rendering: AURYN, DANDY, enemies, projectiles, particles
import { heart, rr, star, text } from './draw';

type Ctx = CanvasRenderingContext2D;

const SKIN = '#ffe3d0';
const OUT = '#7a2b56';

export interface AurynVis {
  facing: number; // 1 | -1
  run: number; // run cycle phase (0 = idle)
  moving: boolean;
  onGround: boolean;
  vy: number;
  attackT: number;
  hurtT: number;
  power: boolean;
  invuln: boolean;
  win: boolean;
  crouch: boolean;
  t: number;
  dead?: boolean;
}

export function drawAuryn(ctx: Ctx, px: number, py: number, v: AurynVis): void {
  ctx.save();
  ctx.translate(px, py);
  if (v.invuln && Math.floor(v.t * 18) % 2 === 0) ctx.globalAlpha = 0.45;
  ctx.scale(v.facing, 1);
  const s = v.power ? 1.14 : 1;
  if (v.crouch) ctx.scale(s * 1.1, s * 0.66);
  else ctx.scale(s, s);

  const runA = v.moving && v.onGround ? Math.sin(v.run) : 0;
  const bob = v.moving && v.onGround ? Math.abs(Math.cos(v.run)) * 2 : Math.sin(v.t * 2.4) * 0.8;
  const airUp = !v.onGround && v.vy < -40;
  const airDown = !v.onGround && v.vy > 40;
  const legF = airUp ? -6 : airDown ? 7 : runA * 7;
  const legB = airUp ? 5 : airDown ? -4 : -runA * 7;
  const armF = v.attackT > 0 ? -2.6 : airUp ? -2 : runA * 5;
  const armB = v.win ? -2.8 : airUp ? 1.6 : -runA * 5;
  const hairSw = v.moving && v.onGround ? Math.sin(v.run * 2) * 4 : Math.sin(v.t * 2.2) * 2;
  const lean = v.attackT > 0 ? 0.1 : v.moving && v.onGround ? 0.05 * Math.sign(runA) : 0;
  ctx.rotate(-lean);

  // ---- long flowing back hair (down to the knees) ----
  drawBackHair(ctx, hairSw, bob);
  // ---- back arm ----
  drawArm(ctx, -4, -35 + bob, armB, '#f3b0cf', v);
  // ---- legs & boots ----
  drawLeg(ctx, -5, legB);
  drawLeg(ctx, 5, legF);
  // ---- skirt ----
  ctx.fillStyle = v.power ? '#ff5fa8' : '#ff7fbf';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-9, -31 + bob);
  ctx.lineTo(9, -31 + bob);
  ctx.lineTo(13, -17 + bob * 0.4);
  ctx.lineTo(-13, -17 + bob * 0.4);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.moveTo(-9, -31 + bob);
  ctx.lineTo(9, -31 + bob);
  ctx.lineTo(11.5, -25 + bob * 0.6);
  ctx.lineTo(-11.5, -25 + bob * 0.6);
  ctx.closePath();
  ctx.fill();
  // ---- bodice ----
  ctx.fillStyle = '#fff';
  rr(ctx, -8, -39 + bob, 16, 10, 4);
  ctx.fill();
  ctx.strokeStyle = OUT;
  ctx.stroke();
  star(ctx, 3, -34 + bob, 2.6, 1.3, 5, '#ff5fa8', '', 0);
  // ---- front arm ----
  drawArm(ctx, 4, -35 + bob, armF, '#ffc3dd', v);
  // ---- head ----
  const hy = -47 + bob;
  ctx.fillStyle = SKIN;
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, hy, 10.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // hair back cap
  ctx.fillStyle = '#ffb3dd';
  ctx.beginPath();
  ctx.arc(0, hy - 2.5, 10.8, Math.PI * 0.95, Math.PI * 2.05);
  ctx.closePath();
  ctx.fill();
  // bangs
  ctx.beginPath();
  ctx.moveTo(-10.5, hy - 1);
  ctx.quadraticCurveTo(-11, hy - 12, 0, hy - 11.5);
  ctx.quadraticCurveTo(11, hy - 12, 10.5, hy - 1);
  ctx.quadraticCurveTo(7, hy - 6, 4.5, hy - 2);
  ctx.quadraticCurveTo(1, hy - 7, -3, hy - 2.5);
  ctx.quadraticCurveTo(-7, hy - 7, -10.5, hy - 1);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = '#e27fb4';
  ctx.lineWidth = 1.4;
  ctx.stroke();
  // front side-lock (long strand over the shoulder)
  drawFrontLock(ctx, 10.5, hy + 1, -hairSw * 0.5);
  // star clip
  star(ctx, 6.5, hy - 7, 2.8, 1.4, 5, '#ffe14d', '#d99a00', v.t * 2);
  // crown beret (pink beret + tiny gold crown)
  drawBeret(ctx, hy);
  // face with expressions (happy / surprised / angry / sad)
  drawAurynFaceEx(ctx, hy, v);
  ctx.restore();

  // power aura
  if (v.power) {
    for (let i = 0; i < 3; i++) {
      const a = v.t * 3 + (i * Math.PI * 2) / 3;
      star(ctx, px + Math.cos(a) * 20, py - 24 + Math.sin(a) * 24, 3.4, 1.7, 5, 'rgba(255,225,120,0.9)', '', a);
    }
  }
}

function drawBackHair(ctx: Ctx, sw: number, bob: number): void {
  ctx.save();
  ctx.rotate(sw * 0.02);
  ctx.fillStyle = '#f584c6';
  ctx.strokeStyle = '#d868ae';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(2, -56 + bob * 0.6);
  ctx.quadraticCurveTo(-17, -52 + bob * 0.6, -18, -34);
  ctx.quadraticCurveTo(-20, -20, -16 + sw * 0.4, -10);
  // wavy tips
  ctx.quadraticCurveTo(-13 + sw * 0.4, -3, -10 + sw * 0.5, -9);
  ctx.quadraticCurveTo(-8 + sw * 0.3, -1, -5 + sw * 0.25, -8);
  ctx.quadraticCurveTo(-2, -2, 0, -9 + bob * 0.2);
  ctx.quadraticCurveTo(2, -16, 0.5, -28);
  ctx.quadraticCurveTo(-0.5, -42, 2, -56 + bob * 0.6);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  // highlight strand
  ctx.strokeStyle = 'rgba(255,196,232,0.85)';
  ctx.lineWidth = 2.2;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-9, -47);
  ctx.quadraticCurveTo(-14, -32, -11 + sw * 0.3, -15);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-5, -44);
  ctx.quadraticCurveTo(-8, -32, -6 + sw * 0.2, -18);
  ctx.stroke();
  ctx.restore();
}

function drawFrontLock(ctx: Ctx, ox: number, oy: number, sw: number): void {
  ctx.save();
  ctx.translate(ox, oy);
  ctx.rotate(sw * 0.04);
  ctx.fillStyle = '#ff9fd4';
  ctx.strokeStyle = '#d868ae';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(-1, -7);
  ctx.quadraticCurveTo(6, 2, 4, 13);
  ctx.quadraticCurveTo(2.5, 19, -1, 15);
  ctx.quadraticCurveTo(-4, 6, -4, -3);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

function drawBeret(ctx: Ctx, hy: number): void {
  ctx.save();
  ctx.translate(-2, hy - 9);
  ctx.rotate(-0.16);
  // beret body
  ctx.fillStyle = '#ff6fb6';
  ctx.strokeStyle = '#d84f96';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.ellipse(0, 0, 13.5, 6, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // band
  ctx.fillStyle = '#e85fb0';
  ctx.beginPath();
  ctx.ellipse(0, 3.5, 12.5, 3.2, 0, 0, Math.PI * 2);
  ctx.fill();
  // stem nub
  ctx.fillStyle = '#ff8fc7';
  ctx.beginPath();
  ctx.arc(-1, -6, 2, 0, Math.PI * 2);
  ctx.fill();
  // tiny gold crown
  ctx.save();
  ctx.translate(5, -6.5);
  ctx.rotate(0.12);
  ctx.fillStyle = '#ffd75e';
  ctx.strokeStyle = '#c9921f';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(-5, 2.5);
  ctx.lineTo(-5.5, -3);
  ctx.lineTo(-2.5, -0.5);
  ctx.lineTo(0, -4.5);
  ctx.lineTo(2.5, -0.5);
  ctx.lineTo(5.5, -3);
  ctx.lineTo(5, 2.5);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#ff4f8b';
  ctx.beginPath();
  ctx.arc(0, 0.6, 1.1, 0, 7);
  ctx.fill();
  ctx.restore();
  ctx.restore();
}

// expressions: happy / surprised / angry(attack) / sad(hurt) / dead(X eyes)
function drawAurynFaceEx(ctx: Ctx, hy: number, v: AurynVis): void {
  const angry = v.attackT > 0;
  const sad = v.hurtT > 0;
  const dead = !!v.dead;
  const surprised = !angry && !sad && !dead && !v.onGround && v.vy > 430;
  const blink = !angry && !sad && !dead && !surprised && Math.sin(v.t * 1.1) > 0.985;

  // brows
  ctx.strokeStyle = '#c25a8a';
  ctx.lineWidth = 1.3;
  ctx.lineCap = 'round';
  ctx.beginPath();
  if (angry) {
    ctx.moveTo(1.6, hy - 3.6); ctx.lineTo(4.6, hy - 2.2);
    ctx.moveTo(9.2, hy - 3.6); ctx.lineTo(6.2, hy - 2.2);
  } else if (sad) {
    ctx.moveTo(1.6, hy - 2.2); ctx.lineTo(4.6, hy - 3.4);
    ctx.moveTo(9.2, hy - 2.2); ctx.lineTo(6.2, hy - 3.4);
  } else {
    ctx.moveTo(1.8, hy - 3.4); ctx.lineTo(4.6, hy - 3.9);
    ctx.moveTo(9, hy - 3.4); ctx.lineTo(6.2, hy - 3.9);
  }
  ctx.stroke();

  if (dead) {
    // X X eyes
    ctx.strokeStyle = '#5a2440';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(1.6, hy + 0.4); ctx.lineTo(4.8, hy + 3.6);
    ctx.moveTo(4.8, hy + 0.4); ctx.lineTo(1.6, hy + 3.6);
    ctx.moveTo(6, hy + 0.4); ctx.lineTo(9.2, hy + 3.6);
    ctx.moveTo(9.2, hy + 0.4); ctx.lineTo(6, hy + 3.6);
    ctx.stroke();
  } else if (sad) {
    // teary closed eyes
    ctx.strokeStyle = '#5a2440';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(3.2, hy + 2.6, 1.9, Math.PI * 1.08, Math.PI * 1.92);
    ctx.arc(7.6, hy + 2.6, 1.9, Math.PI * 1.08, Math.PI * 1.92);
    ctx.stroke();
    ctx.fillStyle = 'rgba(130,200,255,0.9)';
    ctx.beginPath();
    ctx.ellipse(1.2, hy + 5.4, 0.9, 1.4, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (blink) {
    ctx.strokeStyle = '#5a2440';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(1.4, hy + 2); ctx.lineTo(5, hy + 2);
    ctx.moveTo(5.8, hy + 2); ctx.lineTo(9.4, hy + 2);
    ctx.stroke();
  } else {
    // big sparkling eyes
    const ew = surprised ? 3 : 2.7;
    const eh = surprised ? 3.9 : 3.5;
    for (const ex of [3.2, 7.6]) {
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.ellipse(ex, hy + 2, ew, eh, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#e8589f';
      ctx.beginPath();
      ctx.ellipse(ex + (surprised ? 0.1 : 0.35), hy + 2.3, surprised ? 1.5 : 2.05, surprised ? 2 : 2.7, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#8a4bb8';
      ctx.beginPath();
      ctx.ellipse(ex + 0.35, hy + 3.3, surprised ? 1.1 : 1.5, surprised ? 1 : 1.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#472b3f';
      ctx.beginPath();
      ctx.arc(ex + 0.45, hy + 2.7, surprised ? 0.8 : 1.05, 0, 7);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(ex - 0.6, hy + 0.9, 0.9, 0, 7);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(ex + 0.9, hy + 4.1, 0.5, 0, 7);
      ctx.fill();
    }
  }

  // blush
  ctx.fillStyle = 'rgba(255,120,170,0.55)';
  ctx.beginPath();
  ctx.ellipse(0.6, hy + 5.6, 2.3, 1.4, 0, 0, Math.PI * 2);
  ctx.ellipse(10.2, hy + 5.6, 2.1, 1.3, 0, 0, Math.PI * 2);
  ctx.fill();

  // mouth
  ctx.strokeStyle = '#a84a6f';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  if (dead || sad) {
    ctx.moveTo(3.4, hy + 7);
    ctx.quadraticCurveTo(5, hy + 5.9, 6.8, hy + 7.2);
    ctx.stroke();
  } else if (surprised) {
    ctx.fillStyle = '#8a3a55';
    ctx.beginPath();
    ctx.arc(5.2, hy + 6.4, 1.3, 0, Math.PI * 2);
    ctx.fill();
  } else if (angry) {
    ctx.fillStyle = '#8a3a55';
    ctx.beginPath();
    ctx.moveTo(3.8, hy + 5.8);
    ctx.lineTo(6.8, hy + 5.8);
    ctx.lineTo(5.3, hy + 8);
    ctx.closePath();
    ctx.fill();
  } else if (v.win || v.power) {
    ctx.arc(5, hy + 5.4, 2.3, 0.1, Math.PI - 0.4);
    ctx.stroke();
  } else {
    ctx.arc(5.2, hy + 5.2, 1.9, 0.15, Math.PI - 0.5);
    ctx.stroke();
  }
}

function drawLeg(ctx: Ctx, ox: number, swing: number): void {
  ctx.save();
  ctx.translate(ox, -18);
  ctx.rotate(swing * 0.03);
  ctx.strokeStyle = SKIN;
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, 9);
  ctx.stroke();
  // boot
  ctx.fillStyle = '#ff5fa8';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 1.8;
  rr(ctx, -4.5, 8, 9, 9, 3);
  ctx.fill();
  ctx.stroke();
  heart(ctx, 0.5, 12, 3, '#fff', '');
  ctx.restore();
}

function drawArm(ctx: Ctx, ox: number, oy: number, swing: number, sleeve: string, v: AurynVis): void {
  ctx.save();
  ctx.translate(ox, oy);
  const ang = v.attackT > 0 && ox > 0 ? -1.35 : swing * 0.16 + (v.win && ox > 0 ? -2.6 : v.win ? 2.6 : 0);
  ctx.rotate(ang);
  ctx.fillStyle = sleeve;
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.arc(0, 0, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = SKIN;
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 2);
  ctx.lineTo(0, 11);
  ctx.stroke();
  if (v.attackT > 0 && ox > 0) {
    star(ctx, 1, -14, 5.5, 2.8, 5, '#ffe14d', '#ff5fa8', v.t * 6);
  }
  ctx.restore();
}

// ---------------- DANDY ----------------
export interface DandyVis {
  facing: number;
  run: number;
  moving: boolean;
  onGround: boolean;
  vy: number;
  mode: 'walk' | 'chase' | 'throw' | 'taunt' | 'hurt' | 'defeat' | 'boss' | 'float';
  throwT: number;
  t: number;
  scale: number;
  expr?: 'normal' | 'grin' | 'angry' | 'shock';
  aura?: number;
}

export function drawDandy(ctx: Ctx, px: number, py: number, v: DandyVis): void {
  const floating = v.mode === 'float';
  const expr = v.expr ?? (v.mode === 'taunt' || v.mode === 'defeat' ? 'grin' : v.mode === 'hurt' ? 'shock' : 'normal');
  ctx.save();
  ctx.translate(px, py);
  ctx.scale(v.scale, v.scale);
  if (v.mode === 'defeat') {
    ctx.rotate(Math.sin(v.t * 10) * 0.12);
  }
  ctx.scale(v.facing, 1);
  const runA = v.moving && v.onGround ? Math.sin(v.run) : 0;
  const bob = floating ? Math.sin(v.t * 2.6) * 3 : v.moving && v.onGround ? Math.abs(Math.cos(v.run)) * 2 : Math.sin(v.t * 2.2) * 0.8;
  const taunt = v.mode === 'taunt';
  const airUp = !v.onGround && v.vy < -40;
  const airDown = !v.onGround && v.vy > 40;
  const legF = floating ? -4 : airUp ? -6 : airDown ? 7 : runA * 7;
  const legB = floating ? 3 : airUp ? 5 : airDown ? -4 : -runA * 7;
  const armF = v.throwT > 0 ? -2.9 : taunt ? -2.7 : airUp ? -2 : runA * 4.5;
  const armB = taunt ? -2.6 : airUp ? 1.5 : -runA * 4.5;

  // ---- dark vampire aura (phase 2/3) ----
  const aura = v.aura ?? 0;
  if (aura > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 6; i++) {
      const a = v.t * (2.1 + i * 0.35) + i * 1.7;
      const rx = Math.cos(a) * 24;
      const ry = -6 - ((v.t * 34 + i * 26) % 52);
      const s = (6 + (i % 3) * 4) * (0.5 + aura * 0.5);
      ctx.globalAlpha = 0.14 * aura * (0.4 + 0.6 * Math.abs(Math.sin(a * 2)));
      ctx.fillStyle = i % 2 ? '#ff2e4d' : '#8a1030';
      ctx.beginPath();
      ctx.ellipse(rx, ry + 20, s * 0.7, s, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  // ---- VAMPIRE CAPE (behind): dark outer + crimson lining + high collar ----
  const fl = Math.sin(v.t * 3.1) * 4;
  const fl2 = Math.sin(v.t * 3.1 + 1.2) * 3;
  const spread = floating ? 12 : 0;
  const capeLift = airUp ? 10 : airDown ? -6 : 0;
  ctx.save();
  // outer cape
  ctx.fillStyle = '#2e0a16';
  ctx.strokeStyle = '#160410';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-2, -42 + bob);
  ctx.quadraticCurveTo(-30 - spread - fl, -34, -26 - spread * 1.4 - fl2, -8 + capeLift);
  ctx.quadraticCurveTo(-22 - spread, -2 + capeLift, -10, -5);
  ctx.lineTo(-2, -14);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  // crimson lining
  ctx.fillStyle = '#c81e3c';
  ctx.beginPath();
  ctx.moveTo(-4, -40 + bob);
  ctx.quadraticCurveTo(-24 - spread - fl, -30, -21 - spread * 1.4 - fl2, -10 + capeLift);
  ctx.quadraticCurveTo(-16 - spread, -6, -9, -9);
  ctx.closePath();
  ctx.fill();
  // high collar wings
  ctx.fillStyle = '#2e0a16';
  ctx.strokeStyle = '#160410';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(-3, -41 + bob); ctx.lineTo(-13 - fl2 * 0.4, -56 + bob); ctx.lineTo(-1, -47 + bob); ctx.closePath();
  ctx.fill(); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(3, -41 + bob); ctx.lineTo(11 + fl * 0.3, -55 + bob); ctx.lineTo(2, -47 + bob); ctx.closePath();
  ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#c81e3c';
  ctx.beginPath();
  ctx.moveTo(-3.5, -43 + bob); ctx.lineTo(-11, -53.5 + bob); ctx.lineTo(-1.5, -46.5 + bob); ctx.closePath();
  ctx.fill();
  ctx.restore();

  // back arm
  drawDArm(ctx, -5, -34 + bob, armB, false, v);
  // legs
  drawDLeg(ctx, -5, legB, floating);
  drawDLeg(ctx, 5, legF, floating);

  // ---- torso: black tailcoat + crimson trim + cravat + gem ----
  const ty = -38 + bob;
  // coat tail behind legs
  ctx.fillStyle = '#1c1020';
  ctx.strokeStyle = '#0c0510';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(-8, ty + 12);
  ctx.quadraticCurveTo(-15 - fl2 * 0.5, ty + 20, -13 - fl2 * 0.6, ty + 28);
  ctx.lineTo(-4, ty + 18);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  // main coat
  ctx.fillStyle = '#241428';
  rr(ctx, -9, ty, 18, 17, 4);
  ctx.fill();
  ctx.strokeStyle = '#0c0510';
  ctx.lineWidth = 2;
  ctx.stroke();
  // crimson edge trim
  ctx.strokeStyle = '#c81e3c';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-9, ty + 2); ctx.lineTo(-9, ty + 14);
  ctx.moveTo(9, ty + 2); ctx.lineTo(9, ty + 14);
  ctx.stroke();
  // white shirt V
  ctx.fillStyle = '#f6f2ec';
  ctx.beginPath();
  ctx.moveTo(-4.5, ty + 1);
  ctx.lineTo(4.5, ty + 1);
  ctx.lineTo(0, ty + 9);
  ctx.closePath();
  ctx.fill();
  // cravat puff
  ctx.beginPath();
  ctx.arc(0, ty + 3.5, 3.4, 0, Math.PI * 2);
  ctx.arc(-2.6, ty + 5.5, 2.4, 0, Math.PI * 2);
  ctx.arc(2.6, ty + 5.5, 2.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#c9c2bb';
  ctx.lineWidth = 0.8;
  ctx.beginPath(); ctx.moveTo(0, ty + 1); ctx.lineTo(0, ty + 7); ctx.stroke();
  // red gem medallion
  ctx.fillStyle = '#ff2e4d';
  ctx.beginPath(); ctx.arc(0, ty + 11.5, 2.6, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#ffb9c4';
  ctx.beginPath(); ctx.arc(-0.8, ty + 10.6, 0.9, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = '#d99a00'; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.arc(0, ty + 11.5, 3.2, 0, Math.PI * 2); ctx.stroke();

  // front arm
  drawDArm(ctx, 5, -34 + bob, armF, true, v);
  // head — vampire pale
  const hy = -45 + bob;
  ctx.fillStyle = '#f8e8de';
  ctx.strokeStyle = '#2a1420';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, hy, 10.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // swept-back black hair with widow's peak
  ctx.fillStyle = '#160f1c';
  ctx.beginPath();
  ctx.moveTo(-11.5, hy + 1);
  ctx.quadraticCurveTo(-13, hy - 12, -4, hy - 13.5);
  ctx.quadraticCurveTo(6, hy - 15, 11.5, hy - 8);
  ctx.quadraticCurveTo(13, hy - 4, 11.5, hy + 0.5);
  ctx.quadraticCurveTo(9, hy - 5, 5.5, hy - 7);
  ctx.quadraticCurveTo(3, hy - 8.5, 1.5, hy - 7.5);
  ctx.quadraticCurveTo(-2, hy - 9.5, -6, hy - 8);
  ctx.quadraticCurveTo(-10, hy - 6, -11.5, hy + 1);
  ctx.closePath();
  ctx.fill();
  // back spikes
  ctx.beginPath();
  ctx.moveTo(-11, hy - 4);
  ctx.lineTo(-16, hy - 9);
  ctx.lineTo(-10.5, hy - 8.5);
  ctx.lineTo(-14, hy - 13);
  ctx.lineTo(-8.5, hy - 11);
  ctx.closePath();
  ctx.fill();
  // red streaks
  ctx.strokeStyle = '#e33b4e';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(2, hy - 13.5);
  ctx.quadraticCurveTo(6, hy - 11, 8.5, hy - 6.5);
  ctx.moveTo(-8, hy - 11);
  ctx.quadraticCurveTo(-10, hy - 8, -10.5, hy - 4);
  ctx.stroke();
  // ---- expressions: normal / grin / angry / shock ----
  const eyeY = hy + 2.2;
  if (expr === 'shock' || v.mode === 'hurt') {
    // wide shocked eyes + open mouth
    for (const ex of [3.4, 7.8]) {
      ctx.fillStyle = '#fff';
      ctx.strokeStyle = '#241a20';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.ellipse(ex, eyeY, 2.6, 3, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#ff2e4d';
      ctx.beginPath();
      ctx.arc(ex, eyeY + 0.4, 1.1, 0, 7);
      ctx.fill();
    }
    ctx.fillStyle = '#5c1626';
    ctx.beginPath();
    ctx.ellipse(5.2, hy + 6.4, 1.7, 2.1, 0, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // glowing red eyes
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const ex of [3.4, 7.8]) {
      const glow = ctx.createRadialGradient(ex, eyeY, 0.5, ex, eyeY, 5.5);
      glow.addColorStop(0, `rgba(255,46,77,${expr === 'angry' ? 0.75 : 0.5})`);
      glow.addColorStop(1, 'rgba(255,46,77,0)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(ex, eyeY, 5.5, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
    for (const ex of [3.4, 7.8]) {
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.ellipse(ex, eyeY, 2.2, expr === 'grin' ? 1.9 : 2.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = expr === 'angry' ? '#ff2340' : '#e02a48';
      ctx.beginPath();
      ctx.arc(ex + 0.2, eyeY + 0.2, 1.5, 0, 7);
      ctx.fill();
      ctx.fillStyle = '#ffd6dd';
      ctx.beginPath();
      ctx.arc(ex + 0.2, eyeY + 0.2, 0.7, 0, 7);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(ex - 0.5, eyeY - 0.9, 0.6, 0, 7);
      ctx.fill();
    }
    // brows
    ctx.strokeStyle = '#160f1c';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    if (expr === 'angry') {
      ctx.moveTo(1.6, eyeY - 3.6); ctx.lineTo(5, eyeY - 1.8);
      ctx.moveTo(9.6, eyeY - 3.4); ctx.lineTo(6.4, eyeY - 1.7);
    } else {
      ctx.moveTo(1.8, eyeY - 3.4); ctx.lineTo(5, eyeY - 3.8);
      ctx.moveTo(6.4, eyeY - 3.8); ctx.lineTo(9.6, eyeY - 3.3);
    }
    ctx.stroke();
  }
  // mouth per expression
  if (expr === 'grin' && v.mode !== 'hurt') {
    // evil grin with fangs
    ctx.fillStyle = '#5c1626';
    ctx.beginPath();
    ctx.moveTo(2, hy + 4.6);
    ctx.quadraticCurveTo(5.5, hy + 7.6, 9, hy + 4.2);
    ctx.quadraticCurveTo(5.5, hy + 6.4, 2, hy + 4.6);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.moveTo(3.4, hy + 5.1); ctx.lineTo(4.3, hy + 7.2); ctx.lineTo(5, hy + 5.3);
    ctx.closePath();
    ctx.moveTo(6.8, hy + 5.5); ctx.lineTo(7.5, hy + 7.4); ctx.lineTo(8.2, hy + 5);
    ctx.closePath();
    ctx.fill();
  } else if (expr === 'angry') {
    // gritted teeth
    ctx.strokeStyle = '#5c1626';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(2.4, hy + 5);
    ctx.lineTo(8.6, hy + 4.6);
    ctx.stroke();
    ctx.beginPath();
    for (const tx of [3.2, 4.8, 6.4, 8]) {
      ctx.moveTo(tx, hy + 4.4 + (tx - 2.4) * -0.05);
      ctx.lineTo(tx, hy + 5.4 + (tx - 2.4) * -0.05);
    }
    ctx.stroke();
  } else if (expr !== 'shock') {
    // confident smirk
    ctx.strokeStyle = '#7c2740';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(3, hy + 4.6);
    ctx.quadraticCurveTo(6, hy + 3.8, 8, hy + 5.4);
    ctx.stroke();
  }
  ctx.restore();

  if (v.mode === 'defeat') {
    for (let i = 0; i < 3; i++) {
      const a = v.t * 4 + (i * Math.PI * 2) / 3;
      star(ctx, px + Math.cos(a) * 16, py - 52 * v.scale + Math.sin(a) * 8, 4, 1.8, 5, '#ffe14d', '#d99a00', a);
    }
  }
}

function drawDLeg(ctx: Ctx, ox: number, swing: number, floating: boolean): void {
  ctx.save();
  ctx.translate(ox, -18);
  ctx.rotate(swing * 0.03 + (floating ? (ox < 0 ? 0.14 : -0.09) : 0));
  ctx.strokeStyle = '#180f1e';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, 9);
  ctx.stroke();
  // boot with crimson top trim
  ctx.fillStyle = '#120a16';
  ctx.strokeStyle = '#000';
  ctx.lineWidth = 1.5;
  rr(ctx, -4.5, 8, 10, 9, 2.5);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#c81e3c';
  ctx.fillRect(-4.5, 8, 9.8, 1.8);
  ctx.fillStyle = 'rgba(255,255,255,0.14)';
  ctx.fillRect(-3.5, 10.6, 7, 1.2);
  ctx.restore();
}

function drawDArm(ctx: Ctx, ox: number, oy: number, swing: number, front: boolean, v: DandyVis): void {
  ctx.save();
  ctx.translate(ox, oy);
  const ang = v.throwT > 0 && front ? -1.5 : swing * 0.16 + (v.mode === 'taunt' ? (front ? -2.7 : -2.7) : 0);
  ctx.rotate(ang);
  // black sleeve
  ctx.strokeStyle = front ? '#2c1a30' : '#1c1020';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, 9);
  ctx.stroke();
  // white cuff
  ctx.strokeStyle = '#f6f2ec';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-2.2, 8.5);
  ctx.lineTo(2.2, 8.5);
  ctx.stroke();
  // pale hand
  ctx.fillStyle = '#f8e8de';
  ctx.strokeStyle = '#2a1420';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.arc(0, 12, 2.8, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  if (v.throwT > 0 && front) {
    // blood magic gathering
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const glow = ctx.createRadialGradient(1, -13, 1, 1, -13, 9);
    glow.addColorStop(0, 'rgba(255,120,140,0.95)');
    glow.addColorStop(0.5, 'rgba(230,39,77,0.6)');
    glow.addColorStop(1, 'rgba(230,39,77,0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(1, -13, 9, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    ctx.fillStyle = '#ff4d6d';
    ctx.beginPath();
    ctx.arc(1, -13, 3.4, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

// ---------------- BAT MINION (Dandy's familiar) ----------------
export function drawBat(ctx: Ctx, x: number, y: number, t: number, facing: number): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(facing, 1);
  const flap = Math.sin(t * 13);
  // wings (red-black membrane)
  ctx.fillStyle = '#33101f';
  ctx.strokeStyle = '#160409';
  ctx.lineWidth = 1.4;
  for (const side of [-1, 1]) {
    ctx.save();
    ctx.scale(side, 1);
    const wy = -flap * 6;
    ctx.beginPath();
    ctx.moveTo(-2, -2);
    ctx.quadraticCurveTo(-10, -8 + wy, -16, -4 + wy);
    ctx.lineTo(-13, 1 + flap * 3);
    ctx.quadraticCurveTo(-9, -1 + flap * 2, -7, 3 + flap * 2);
    ctx.quadraticCurveTo(-4, 0, -2, 3);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // membrane vein
    ctx.strokeStyle = 'rgba(200,30,60,0.5)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-3, -2);
    ctx.lineTo(-12, -3 + wy);
    ctx.stroke();
    ctx.restore();
  }
  // body
  ctx.fillStyle = '#3a1424';
  ctx.strokeStyle = '#160409';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.ellipse(0, 0, 5.5, 7, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // ears
  ctx.beginPath();
  ctx.moveTo(-4, -6); ctx.lineTo(-3.5, -11); ctx.lineTo(-1, -6.5);
  ctx.closePath();
  ctx.moveTo(4, -6); ctx.lineTo(3.5, -11); ctx.lineTo(1, -6.5);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  // glowing eyes
  ctx.fillStyle = '#ff2e4d';
  ctx.beginPath();
  ctx.arc(-2, -2.5, 1.2, 0, 7);
  ctx.arc(2, -2.5, 1.2, 0, 7);
  ctx.fill();
  // fangs
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.moveTo(-1.8, 2.6); ctx.lineTo(-1.1, 4.4); ctx.lineTo(-0.4, 2.6);
  ctx.closePath();
  ctx.moveTo(1.8, 2.6); ctx.lineTo(1.1, 4.4); ctx.lineTo(0.4, 2.6);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

// ---------------- ENEMIES ----------------
export function drawGrumblit(ctx: Ctx, x: number, y: number, t: number, facing: number, squashed: boolean): void {
  // y = feet center
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(facing, 1);
  if (squashed) {
    ctx.scale(1.25, 0.35);
  }
  const waddle = Math.sin(t * 9) * 1.5;
  // feet
  ctx.fillStyle = '#6e4a26';
  ctx.beginPath();
  ctx.ellipse(-6, -2, 5, 3, 0, 0, Math.PI * 2);
  ctx.ellipse(6, -2, 5, 3, 0, 0, Math.PI * 2);
  ctx.fill();
  // body
  ctx.fillStyle = '#e8c17e';
  ctx.strokeStyle = '#8a5a2b';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(0, -14 + waddle * 0.2, 13, 12, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // mushroom cap
  ctx.fillStyle = '#c96f4a';
  ctx.beginPath();
  ctx.arc(0, -20 + waddle * 0.2, 15, Math.PI * 1.02, Math.PI * 1.98);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#fff0dd';
  ctx.beginPath();
  ctx.arc(-6, -27, 3, 0, 7);
  ctx.arc(5, -30, 2.4, 0, 7);
  ctx.fill();
  // angry eyes
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(-4.5, -15, 3.4, 0, 7);
  ctx.arc(4.5, -15, 3.4, 0, 7);
  ctx.fill();
  ctx.fillStyle = '#2a1a10';
  ctx.beginPath();
  ctx.arc(-3.4, -14.6, 1.7, 0, 7);
  ctx.arc(5.6, -14.6, 1.7, 0, 7);
  ctx.fill();
  ctx.strokeStyle = '#5a3018';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-8, -19.5); ctx.lineTo(-1.5, -17.5);
  ctx.moveTo(8, -19.5); ctx.lineTo(1.5, -17.5);
  ctx.stroke();
  // frown
  ctx.beginPath();
  ctx.arc(0, -8.5, 3, Math.PI * 1.15, Math.PI * 1.85);
  ctx.stroke();
  ctx.restore();
}

export function drawSpikeling(ctx: Ctx, x: number, y: number, t: number, facing: number, squashed: boolean): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(facing, 1);
  if (squashed) ctx.scale(1.2, 0.4);
  const roll = t * 4;
  // spikes (rotating slightly)
  ctx.save();
  ctx.rotate(Math.sin(roll) * 0.15);
  ctx.fillStyle = '#4a3a6b';
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(Math.cos(a - 0.18) * 11, -14 + Math.sin(a - 0.18) * 11);
    ctx.lineTo(Math.cos(a) * 18, -14 + Math.sin(a) * 18);
    ctx.lineTo(Math.cos(a + 0.18) * 11, -14 + Math.sin(a + 0.18) * 11);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
  // body
  ctx.fillStyle = '#6b5590';
  ctx.strokeStyle = '#3a2c55';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, -14, 12, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,0.25)';
  ctx.beginPath();
  ctx.arc(-4, -19, 4, 0, 7);
  ctx.fill();
  // eyes
  ctx.fillStyle = '#ffe14d';
  ctx.beginPath();
  ctx.arc(-4, -15, 3, 0, 7);
  ctx.arc(4.5, -15, 3, 0, 7);
  ctx.fill();
  ctx.fillStyle = '#1a1024';
  ctx.beginPath();
  ctx.arc(-3.2, -15, 1.5, 0, 7);
  ctx.arc(5.3, -15, 1.5, 0, 7);
  ctx.fill();
  // grin
  ctx.strokeStyle = '#241a38';
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(-4, -8.5);
  ctx.quadraticCurveTo(0, -6, 4.5, -8.5);
  ctx.stroke();
  ctx.restore();
}

export function drawFlapper(ctx: Ctx, x: number, y: number, t: number, facing: number, squashed: boolean): void {
  ctx.save();
  ctx.translate(x, y);
  if (squashed) ctx.scale(1.3, 0.35);
  ctx.scale(facing, 1);
  const flap = Math.sin(t * 14) * 0.8;
  // wings
  ctx.fillStyle = '#8a5fc9';
  for (const dir of [-1, 1]) {
    ctx.save();
    ctx.rotate(dir * flap * 0.5);
    ctx.beginPath();
    ctx.moveTo(dir * 6, -16);
    ctx.quadraticCurveTo(dir * 24, -26 - flap * 6, dir * 30, -12);
    ctx.quadraticCurveTo(dir * 20, -10, dir * 8, -10);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  // body
  ctx.fillStyle = '#a678e0';
  ctx.strokeStyle = '#5d3a8f';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(0, -15, 10, 11, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // ears
  ctx.fillStyle = '#a678e0';
  ctx.beginPath();
  ctx.moveTo(-8, -22); ctx.lineTo(-10, -31); ctx.lineTo(-3, -24);
  ctx.moveTo(8, -22); ctx.lineTo(10, -31); ctx.lineTo(3, -24);
  ctx.fill();
  // eyes + fang
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(-3.5, -16, 3, 0, 7);
  ctx.arc(4, -16, 3, 0, 7);
  ctx.fill();
  ctx.fillStyle = '#2a1a3a';
  ctx.beginPath();
  ctx.arc(-2.6, -16, 1.5, 0, 7);
  ctx.arc(4.9, -16, 1.5, 0, 7);
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.moveTo(1, -9);
  ctx.lineTo(3, -5);
  ctx.lineTo(4.5, -9);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

// ---------------- SHELLBY (turtle) ----------------
export function drawShellby(
  ctx: Ctx, x: number, y: number, t: number, facing: number,
  mode: 'walk' | 'shell' | 'slide', shellT = 0
): void {
  ctx.save();
  ctx.translate(x, y);
  if (mode === 'shell' && shellT < 2.2) ctx.rotate(Math.sin(t * 22) * 0.09); // wake-up wobble
  if (mode === 'slide') ctx.rotate(t * 14 % (Math.PI * 2) * 0); // no full spin: keep readable
  ctx.scale(facing, 1);
  if (mode === 'walk') {
    const waddle = Math.sin(t * 9) * 1.4;
    // feet
    ctx.fillStyle = '#e8b84d';
    ctx.strokeStyle = '#9a7423';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.ellipse(-5.5, -2.5, 4.6, 2.8, 0, 0, Math.PI * 2);
    ctx.ellipse(5.5, -2.5 - Math.max(0, Math.sin(t * 9)) * 2, 4.6, 2.8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    // tail
    ctx.fillStyle = '#bfe89a';
    ctx.beginPath();
    ctx.moveTo(-12, -8);
    ctx.lineTo(-17, -5);
    ctx.lineTo(-12, -3.5);
    ctx.closePath();
    ctx.fill();
    // shell dome
    ctx.fillStyle = '#43b25f';
    ctx.strokeStyle = '#1f7a3c';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, -11 + waddle * 0.2, 13, Math.PI, Math.PI * 2);
    ctx.quadraticCurveTo(13, -3, 9, -2.5);
    ctx.lineTo(-9, -2.5);
    ctx.quadraticCurveTo(-13, -3, -13, -11 + waddle * 0.2);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // rim band
    ctx.fillStyle = '#d9f2c0';
    rr(ctx, -12.5, -5.5, 25, 4.5, 2.2);
    ctx.fill();
    ctx.strokeStyle = '#1f7a3c';
    ctx.lineWidth = 1.4;
    ctx.stroke();
    // shell spots
    ctx.fillStyle = '#2f8f4c';
    ctx.beginPath();
    ctx.arc(-5, -13, 2.4, 0, 7);
    ctx.arc(4, -15, 2, 0, 7);
    ctx.arc(0, -9.5, 1.8, 0, 7);
    ctx.fill();
    // head
    ctx.fillStyle = '#9ade5f';
    ctx.strokeStyle = '#4f9430';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.ellipse(11, -12 + waddle * 0.3, 6.2, 5.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(13, -13.5, 2.1, 0, 7);
    ctx.fill();
    ctx.fillStyle = '#233';
    ctx.beginPath();
    ctx.arc(13.6, -13.5, 1.05, 0, 7);
    ctx.fill();
    ctx.strokeStyle = '#4f9430';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(13.5, -9.8, 1.7, 0.2, Math.PI - 0.6);
    ctx.stroke();
  } else {
    // shell only
    if (mode === 'slide') {
      ctx.strokeStyle = 'rgba(255,255,255,0.65)';
      ctx.lineWidth = 2.4;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(-18, -16); ctx.lineTo(-26, -16);
      ctx.moveTo(-16, -10); ctx.lineTo(-25, -10);
      ctx.moveTo(-18, -4); ctx.lineTo(-24, -4);
      ctx.stroke();
    }
    ctx.fillStyle = '#43b25f';
    ctx.strokeStyle = '#1f7a3c';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, -13, 14, Math.PI, Math.PI * 2);
    ctx.quadraticCurveTo(14, -1, 10, 0);
    ctx.lineTo(-10, 0);
    ctx.quadraticCurveTo(-14, -1, -14, -13);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#d9f2c0';
    rr(ctx, -13.5, -4.5, 27, 5, 2.4);
    ctx.fill();
    ctx.strokeStyle = '#1f7a3c';
    ctx.lineWidth = 1.4;
    ctx.stroke();
    ctx.fillStyle = '#2f8f4c';
    ctx.beginPath();
    ctx.arc(-5, -15, 2.6, 0, 7);
    ctx.arc(5, -16, 2.2, 0, 7);
    ctx.arc(0, -10, 2, 0, 7);
    ctx.fill();
  }
  ctx.restore();
}

// ---------------- SNAP BLOOM (piranha plant) ----------------
export function drawSnapBloom(ctx: Ctx, x: number, baseY: number, out: number, t: number): void {
  if (out <= 0.02) return;
  const h = 46 * out;
  ctx.save();
  ctx.translate(x, baseY);
  const sway = Math.sin(t * 3) * 2.5 * out;
  // stem
  ctx.strokeStyle = '#3f9e4f';
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 2);
  ctx.quadraticCurveTo(sway, -h * 0.5, sway * 0.6, -h + 8);
  ctx.stroke();
  // leaves
  ctx.fillStyle = '#5fc46a';
  ctx.strokeStyle = '#2f7a3c';
  ctx.lineWidth = 1.5;
  for (const dir of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(dir * 2, -h * 0.42);
    ctx.quadraticCurveTo(dir * 12, -h * 0.42 - 7, dir * 16, -h * 0.42 + 2);
    ctx.quadraticCurveTo(dir * 10, -h * 0.42 + 5, dir * 2, -h * 0.42 + 3);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  // head
  ctx.translate(sway * 0.6, -h + 4);
  // back petals
  ctx.fillStyle = '#c93a4f';
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2 + t * 0.6;
    ctx.beginPath();
    ctx.ellipse(Math.cos(a) * 9, Math.sin(a) * 9 - 2, 4.6, 4.6, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  // head ball
  ctx.fillStyle = '#e8484f';
  ctx.strokeStyle = '#9a2436';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, -2, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // white spots
  ctx.fillStyle = '#fff0e0';
  ctx.beginPath();
  ctx.arc(-4.5, -7, 2, 0, 7);
  ctx.arc(4, -8.5, 1.7, 0, 7);
  ctx.arc(6.5, -3, 1.5, 0, 7);
  ctx.fill();
  // lips
  ctx.fillStyle = '#fff';
  ctx.strokeStyle = '#c9b8a8';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.ellipse(0, 5.5, 8.5, 4.2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // mouth + teeth
  ctx.fillStyle = '#6b1d2c';
  ctx.beginPath();
  ctx.ellipse(0, 5.5, 5.5, 2.4, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#fff';
  for (const dx of [-3, 0, 3]) {
    ctx.beginPath();
    ctx.moveTo(dx - 1.2, 3.6);
    ctx.lineTo(dx + 1.2, 3.6);
    ctx.lineTo(dx, 6);
    ctx.closePath();
    ctx.fill();
  }
  // angry eyes
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.ellipse(-3.6, -4.5, 2.4, 2.8, 0, 0, Math.PI * 2);
  ctx.ellipse(3.6, -4.5, 2.4, 2.8, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#472b3f';
  ctx.beginPath();
  ctx.arc(-3.1, -4.1, 1.15, 0, 7);
  ctx.arc(4.1, -4.1, 1.15, 0, 7);
  ctx.fill();
  ctx.strokeStyle = '#9a2436';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(-6.4, -8); ctx.lineTo(-1.6, -6.4);
  ctx.moveTo(6.4, -8); ctx.lineTo(1.6, -6.4);
  ctx.stroke();
  ctx.restore();
}

// ---------------- PROJECTILES / PARTICLES ----------------
export function drawMagicBolt(ctx: Ctx, x: number, y: number, t: number, big: boolean): void {
  const s = big ? 1.35 : 1;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(t * 12);
  ctx.globalAlpha = 0.35;
  ctx.fillStyle = '#ff9ad5';
  ctx.beginPath();
  ctx.arc(0, 0, 12 * s, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
  star(ctx, 0, 0, 9 * s, 4.2 * s, 5, '#ff5fa8', '#ffe14d', 0);
  heart(ctx, 0, 0, 4 * s, '#fff', '');
  ctx.restore();
}

export function drawOrb(ctx: Ctx, x: number, y: number, t: number): void {
  // BLOOD ORB — Dandy's blood magic (per reference sheet asset)
  ctx.save();
  ctx.translate(x, y);
  const p = 0.7 + 0.3 * Math.sin(t * 20);
  ctx.globalAlpha = 0.38 * p;
  ctx.fillStyle = '#ff2e4d';
  ctx.beginPath();
  ctx.arc(0, 0, 13, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
  ctx.fillStyle = '#c8103a';
  ctx.beginPath();
  ctx.arc(0, 0, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ff8095';
  ctx.beginPath();
  ctx.arc(-2, -2, 3, 0, Math.PI * 2);
  ctx.fill();
  // rotating sparkle cross
  ctx.save();
  ctx.rotate(t * 3);
  ctx.strokeStyle = 'rgba(255,200,210,0.85)';
  ctx.lineWidth = 1.4;
  const r = 4.5 + Math.sin(t * 14) * 1.2;
  ctx.beginPath();
  ctx.moveTo(-r, 0); ctx.lineTo(r, 0);
  ctx.moveTo(0, -r); ctx.lineTo(0, r);
  ctx.stroke();
  ctx.restore();
  ctx.restore();
}

export function drawShockwave(ctx: Ctx, x: number, y: number, t: number): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = 'rgba(255,90,140,0.75)';
  const h = 20 + Math.sin(t * 18) * 4;
  ctx.beginPath();
  ctx.moveTo(-12, 0);
  ctx.quadraticCurveTo(-6, -h, 0, -h * 0.6);
  ctx.quadraticCurveTo(8, -h * 1.1, 14, 0);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#ffe14d';
  ctx.beginPath();
  ctx.arc(0, -h * 0.55, 3.5, 0, 7);
  ctx.fill();
  ctx.restore();
}

export type ParticleKind = 'heart' | 'star' | 'spark' | 'puff' | 'confetti' | 'note' | 'bat';

export function drawParticle(
  ctx: Ctx, kind: ParticleKind, x: number, y: number, size: number, color: string, rot: number, alpha: number
): void {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(x, y);
  ctx.rotate(rot);
  switch (kind) {
    case 'heart': heart(ctx, 0, 0, size, color, ''); break;
    case 'star': star(ctx, 0, 0, size, size * 0.45, 5, color, '', 0); break;
    case 'spark':
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(0, 0, size * 0.5, 0, Math.PI * 2);
      ctx.fill();
      break;
    case 'puff':
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(0, 0, size, 0, Math.PI * 2);
      ctx.arc(size * 0.8, size * 0.2, size * 0.7, 0, Math.PI * 2);
      ctx.arc(-size * 0.8, size * 0.2, size * 0.7, 0, Math.PI * 2);
      ctx.fill();
      break;
    case 'confetti':
      ctx.fillStyle = color;
      ctx.fillRect(-size / 2, -size / 4, size, size / 2);
      break;
    case 'note':
      text(ctx, '♪', 0, 0, size * 2.4, color, {});
      break;
    case 'bat':
      ctx.rotate(-rot); // bats glide, they don't tumble
      ctx.scale(size / 8, size / 8);
      drawBat(ctx, 0, 0, rot * 5 + 0.4, 1);
      break;
  }
  ctx.restore();
}

// mini portrait for HUD
export function drawAurynFace(ctx: Ctx, x: number, y: number, s: number): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  // long hair behind
  ctx.fillStyle = '#f584c6';
  ctx.strokeStyle = '#d868ae';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(-9, -6);
  ctx.quadraticCurveTo(-13, 4, -10, 12);
  ctx.quadraticCurveTo(-7, 16, -5, 11);
  ctx.quadraticCurveTo(-4, 4, -5, -4);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(10.5, 4, 4, 8, -0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // face
  ctx.fillStyle = SKIN;
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // bangs
  ctx.fillStyle = '#ffb3dd';
  ctx.beginPath();
  ctx.arc(0, -3, 10.4, Math.PI * 0.9, Math.PI * 2.1);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-10, -1);
  ctx.quadraticCurveTo(-11, -12, 0, -11.5);
  ctx.quadraticCurveTo(11, -12, 10, -1);
  ctx.quadraticCurveTo(5, -7, 0, -4);
  ctx.quadraticCurveTo(-5, -7, -10, -1);
  ctx.fill();
  // beret + crown
  ctx.save();
  ctx.translate(-2, -11);
  ctx.rotate(-0.16);
  ctx.fillStyle = '#ff6fb6';
  ctx.strokeStyle = '#d84f96';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.ellipse(0, 0, 12.5, 5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.translate(5, -5.5);
  ctx.rotate(0.12);
  ctx.fillStyle = '#ffd75e';
  ctx.strokeStyle = '#c9921f';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-4.5, 2.2);
  ctx.lineTo(-5, -2.6);
  ctx.lineTo(-2.2, -0.4);
  ctx.lineTo(0, -4);
  ctx.lineTo(2.2, -0.4);
  ctx.lineTo(5, -2.6);
  ctx.lineTo(4.5, 2.2);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
  // eyes
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.ellipse(-3, 2, 2.5, 3.2, 0, 0, 7);
  ctx.ellipse(4, 2, 2.5, 3.2, 0, 0, 7);
  ctx.fill();
  ctx.fillStyle = '#e8589f';
  ctx.beginPath();
  ctx.arc(-2.7, 2.4, 1.8, 0, 7);
  ctx.arc(4.3, 2.4, 1.8, 0, 7);
  ctx.fill();
  ctx.fillStyle = '#472b3f';
  ctx.beginPath();
  ctx.arc(-2.6, 2.6, 0.9, 0, 7);
  ctx.arc(4.4, 2.6, 0.9, 0, 7);
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.arc(-3.6, 1.2, 0.8, 0, 7);
  ctx.arc(3.4, 1.2, 0.8, 0, 7);
  ctx.fill();
  // blush + smile
  ctx.fillStyle = 'rgba(255,120,170,0.5)';
  ctx.beginPath();
  ctx.arc(-6.5, 6, 1.8, 0, 7);
  ctx.arc(7.5, 6, 1.8, 0, 7);
  ctx.fill();
  ctx.strokeStyle = '#a84a6f';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.arc(1, 6.5, 2.2, 0.2, Math.PI - 0.5);
  ctx.stroke();
  ctx.restore();
}

export function drawDandyFace(ctx: Ctx, x: number, y: number, s: number): void {
  // DANDY the Vampire Lord — circular avatar (boss bar / UI icon)
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  // dark backdrop
  ctx.fillStyle = '#2b0d1a';
  ctx.beginPath();
  ctx.arc(0, 0, 11.5, 0, Math.PI * 2);
  ctx.fill();
  // pale face
  ctx.fillStyle = '#f8e8de';
  ctx.beginPath();
  ctx.arc(0, 1.5, 8.5, 0, Math.PI * 2);
  ctx.fill();
  // swept black hair
  ctx.fillStyle = '#160f1c';
  ctx.beginPath();
  ctx.moveTo(-9.5, 2);
  ctx.quadraticCurveTo(-11, -8, -2, -10);
  ctx.quadraticCurveTo(7, -11.5, 10, -5);
  ctx.quadraticCurveTo(11, -2, 9.5, 1);
  ctx.quadraticCurveTo(7.5, -4.5, 3.5, -5.5);
  ctx.quadraticCurveTo(0, -6.3, -3, -5);
  ctx.quadraticCurveTo(-8, -3.5, -9.5, 2);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = '#e33b4e';
  ctx.lineWidth = 1.1;
  ctx.beginPath();
  ctx.moveTo(1.5, -9.5);
  ctx.quadraticCurveTo(5.5, -7.5, 7.5, -3.5);
  ctx.stroke();
  // glowing red eyes
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const ex of [-3, 3.2]) {
    const glow = ctx.createRadialGradient(ex, 2.5, 0.4, ex, 2.5, 4);
    glow.addColorStop(0, 'rgba(255,46,77,0.7)');
    glow.addColorStop(1, 'rgba(255,46,77,0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(ex, 2.5, 4, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
  for (const ex of [-3, 3.2]) {
    ctx.fillStyle = '#e02a48';
    ctx.beginPath();
    ctx.arc(ex, 2.5, 1.6, 0, 7);
    ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(ex - 0.5, 1.9, 0.6, 0, 7);
    ctx.fill();
  }
  // evil grin + fang
  ctx.strokeStyle = '#7c2740';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(-3, 6);
  ctx.quadraticCurveTo(0.5, 8.2, 4.4, 5.6);
  ctx.stroke();
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.moveTo(1.4, 6.4); ctx.lineTo(2.1, 8.4); ctx.lineTo(2.9, 6.3);
  ctx.closePath();
  ctx.fill();
  // cape collar hint
  ctx.fillStyle = '#2e0a16';
  ctx.beginPath();
  ctx.moveTo(-11, 11.5);
  ctx.quadraticCurveTo(0, 5.5, 11, 11.5);
  ctx.lineTo(11, 12.5);
  ctx.lineTo(-11, 12.5);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}
