// Entities: player, enemies, Dandy AI, items, projectiles, particles
import type { Game } from './game';
import {
  TILE, clamp, randRange, chance,
} from './types';
import {
  drawCheckpoint, drawCoin, drawFlagpole, drawGate,
  drawPickup, rr,
} from './draw';
import {
  ParticleKind, drawAuryn, drawBat, drawDandy, drawFlapper, drawGrumblit,
  drawMagicBolt, drawOrb, drawShockwave, drawSpikeling, drawShellby, drawSnapBloom,
} from './chars';

type Ctx = CanvasRenderingContext2D;

export class Entity {
  x: number; // center x
  y: number; // feet y
  w: number;
  h: number;
  vx = 0;
  vy = 0;
  onGround = false;
  remove = false;
  constructor(x: number, y: number, w: number, h: number) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }
  get left(): number { return this.x - this.w / 2; }
  get right(): number { return this.x + this.w / 2; }
  get top(): number { return this.y - this.h; }
  overlaps(o: Entity): boolean {
    return this.left < o.right && this.right > o.left && this.top < o.y && this.y > o.top;
  }
}

// ---------------- PLAYER: AURYN ----------------
export class Player extends Entity {
  hp = 3;
  maxHp = 5;
  power = false;
  starT = 0;
  magicLvl = 0;
  invulnT = 0;
  attackCd = 0;
  attackT = 0;
  hurtT = 0;
  facing = 1;
  runPhase = 0;
  moving = false;
  crouch = false;
  coyote = 0;
  jumpBuf = 0;
  deadT = 0;
  win = false;
  nameT = 2.6;
  standingPlat: MovingPlat | null = null;
  warpT = 0;

  constructor(x: number, y: number) {
    super(x, y, 26, 44);
  }

  update(dt: number, g: Game): void {
    const inp = g.input;
    this.nameT = Math.max(0, this.nameT - dt);
    this.attackCd -= dt;
    this.attackT = Math.max(0, this.attackT - dt);
    this.hurtT = Math.max(0, this.hurtT - dt);
    this.invulnT = Math.max(0, this.invulnT - dt);
    this.starT = Math.max(0, this.starT - dt);
    if (this.starT > 0 && chance(dt * 24)) {
      g.burst('star', this.x + randRange(-12, 12), this.y - randRange(6, 40), 1, { vx: randRange(-40, 40), vy: randRange(-60, -10), ttl: 0.5, size: 4, color: ['#ffe14d', '#ff9ad5', '#7fe38a'][Math.floor(Math.random() * 3)] });
    }

    if (this.warpT > 0) {
      this.warpT -= dt;
      this.y += 52 * dt;
      if (this.warpT <= 0) g.finishWarp();
      return;
    }

    const maxSpd = 300 * (this.power ? 1.15 : 1);
    const acc = 2600;
    this.moving = false;
    this.crouch = !!(inp.down && this.onGround) && this.warpT <= 0;
    if (this.crouch) {
      // crouching: stop sliding
      const fr = 3200 * dt;
      if (Math.abs(this.vx) <= fr) this.vx = 0;
      else this.vx -= Math.sign(this.vx) * fr;
    } else if (inp.left && !inp.right) {
      this.vx -= acc * dt;
      this.facing = -1;
      this.moving = true;
    } else if (inp.right && !inp.left) {
      this.vx += acc * dt;
      this.facing = 1;
      this.moving = true;
    } else {
      const fr = 2400 * dt;
      if (Math.abs(this.vx) <= fr) this.vx = 0;
      else this.vx -= Math.sign(this.vx) * fr;
    }
    this.vx = clamp(this.vx, -maxSpd, maxSpd);

    // jumping (coyote + buffer + variable height)
    if (g.pressed('jump')) this.jumpBuf = 0.12;
    this.jumpBuf = Math.max(0, this.jumpBuf - dt);
    this.coyote = Math.max(0, this.coyote - dt);
    if (this.jumpBuf > 0 && (this.onGround || this.coyote > 0)) {
      this.vy = -(960 * (this.power ? 1.1 : 1));
      this.onGround = false;
      this.coyote = 0;
      this.jumpBuf = 0;
      g.sfx('jump');
      g.burst('heart', this.x, this.y, 4, { vx: randRange(-70, 70), vy: randRange(-140, -40), ttl: 0.5, size: 6, color: '#ff9ad5', grav: 300 });
    }
    // pipe entry
    if (inp.down && this.onGround) g.tryPipeEnter(this);

    // magic attack
    if (g.pressed('attack') && this.attackCd <= 0) {
      const big = this.magicLvl >= 2;
      g.shots.push(new MagicBolt(this.x + this.facing * 16, this.y - 26, this.facing * (560 + 90 * this.magicLvl), 1 + (this.magicLvl >= 1 ? 1 : 0), big));
      this.attackCd = this.magicLvl >= 2 ? 0.3 : 0.45;
      this.attackT = 0.22;
      g.sfx('magic');
    }

    // physics
    if (this.standingPlat) {
      this.x += this.standingPlat.dxF;
      this.y += this.standingPlat.dyF;
    }
    this.standingPlat = null;
    const f = g.moveAndCollide(this, dt, true, inp.jump);
    if (f.down) { this.onGround = true; this.coyote = 0.09; } else { this.onGround = false; }
    if (f.up) g.bumpTile(f.bumpTx, f.bumpTy);
    if ((f.left || f.right) && Math.abs(this.vx) < 40) this.vx = 0;
    if (this.onGround) this.runPhase += Math.abs(this.vx) * dt * 0.06;

    // hazards
    if (g.touchingHazard(this)) this.hurt(1, this.x + randRange(-1, 1), g);

    // fell off the world
    if (this.y > g.levelH * TILE + 60) g.killPlayer(false);
  }

  hurt(dmg: number, fromX: number, g: Game): void {
    if (this.invulnT > 0 || this.starT > 0 || this.deadT > 0 || this.warpT > 0) return;
    if (this.power) {
      this.power = false;
      this.invulnT = 1.6;
      this.hurtT = 0.5;
      g.sfx('hurt');
      g.burst('star', this.x, this.y - 30, 6, { vx: randRange(-120, 120), vy: randRange(-160, -40), ttl: 0.6, size: 5, color: '#ffe14d' });
      return;
    }
    this.hp -= dmg;
    this.hurtT = 0.5;
    if (this.hp <= 0) {
      g.killPlayer(true);
      return;
    }
    this.invulnT = 1.6;
    this.vx = (this.x < fromX ? -1 : 1) * 240;
    this.vy = -360;
    g.sfx('hurt');
  }

  autoWalk(dt: number, g: Game): void {
    // finish walk into the castle
    this.vx = 160;
    this.facing = 1;
    this.moving = true;
    this.runPhase += Math.abs(this.vx) * dt * 0.06;
    const f = g.moveAndCollide(this, dt, true, true);
    this.onGround = f.down;
  }

  draw(ctx: Ctx, g: Game): void {
    if (this.warpT > 0) {
      ctx.save();
      ctx.globalAlpha = Math.max(0.15, this.warpT / 0.55);
      drawAuryn(ctx, this.x, this.y, {
        facing: this.facing, run: this.runPhase, moving: false, onGround: true, vy: 0,
        attackT: 0, hurtT: 0, power: this.power, invuln: false, win: false, crouch: false, t: g.t,
      });
      ctx.restore();
      return;
    }
    drawAuryn(ctx, this.x, this.y, {
      facing: this.facing,
      run: this.runPhase,
      moving: this.moving,
      onGround: this.onGround,
      vy: this.vy,
      attackT: this.attackT,
      hurtT: this.hurtT,
      power: this.power,
      invuln: this.invulnT > 0,
      win: this.win,
      crouch: this.crouch,
      dead: this.deadT > 0,
      t: g.t,
    });
    if (this.nameT > 0) {
      ctx.save();
      ctx.globalAlpha = Math.min(1, this.nameT);
      ctx.font = '900 13px "Arial Black", Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.lineWidth = 4;
      ctx.strokeStyle = 'rgba(90,20,60,0.85)';
      ctx.strokeText('AURYN', this.x, this.y - 62);
      ctx.fillStyle = '#ffd7ec';
      ctx.fillText('AURYN', this.x, this.y - 62);
      ctx.restore();
    }
  }
}

// ---------------- ENEMIES ----------------
export abstract class Enemy extends Entity {
  hp = 1;
  stompable = true;
  scoreVal = 200;
  squashT = 0;
  facing = -1;
  t = Math.random() * 10;
  flash = 0;
  constructor(x: number, y: number, w: number, h: number) {
    super(x, y, w, h);
  }
  update(dt: number, g: Game): void {
    this.t += dt;
    this.flash = Math.max(0, this.flash - dt);
    if (this.y > g.levelH * TILE + 100) {
      this.remove = true;
      return;
    }
    if (this.squashT > 0) {
      this.squashT -= dt;
      if (this.squashT <= 0) this.remove = true;
      return;
    }
    this.ai(dt, g);
  }
  protected abstract ai(dt: number, g: Game): void;
  abstract draw(ctx: Ctx, t: number): void;
  stomp(g: Game): void {
    this.squashT = 0.45;
    g.addScore(this.scoreVal, this.x, this.top);
    g.sfx('stomp');
    g.burst('puff', this.x, this.y - 10, 4, { vx: randRange(-60, 60), vy: randRange(-80, -20), ttl: 0.5, size: 8, color: 'rgba(255,255,255,0.85)' });
  }
  magicHit(dmg: number, g: Game): void {
    this.hp -= dmg;
    this.flash = 0.18;
    if (this.hp <= 0) {
      this.remove = true;
      g.addScore(this.scoreVal, this.x, this.top);
      g.sfx('enemyDie');
      g.burst('puff', this.x, this.y - 14, 6, { vx: randRange(-90, 90), vy: randRange(-120, -20), ttl: 0.55, size: 9, color: 'rgba(255,255,255,0.85)' });
    } else {
      g.sfx('dandyHit');
    }
  }
  drawFlash(ctx: Ctx, fn: () => void): void {
    if (this.flash > 0 && Math.floor(this.flash * 40) % 2 === 0) {
      ctx.save();
      ctx.globalAlpha = 0.5;
      fn();
      ctx.restore();
    } else fn();
  }
}

export class Grumblit extends Enemy {
  speed: number;
  constructor(x: number, y: number, world: number) {
    super(x, y, 32, 28);
    this.hp = 1;
    this.scoreVal = 200;
    this.speed = world <= 2 ? 55 : 95;
  }
  protected ai(dt: number, g: Game): void {
    this.vx = this.facing * this.speed;
    const f = g.moveAndCollide(this, dt, true, true);
    this.onGround = f.down;
    if (f.left) this.facing = 1;
    if (f.right) this.facing = -1;
    if (f.down && this.speed <= 60) {
      const aheadX = this.x + this.facing * (this.w / 2 + 4);
      if (!g.solidBelow(aheadX, this.y)) this.facing *= -1;
    }
  }
  draw(ctx: Ctx, t: number): void {
    this.drawFlash(ctx, () => drawGrumblit(ctx, this.x, this.y, t, this.facing, this.squashT > 0));
  }
}

export class Spikeling extends Enemy {
  constructor(x: number, y: number) {
    super(x, y, 32, 30);
    this.hp = 1;
    this.stompable = false;
    this.scoreVal = 300;
  }
  protected ai(dt: number, g: Game): void {
    this.vx = this.facing * 75;
    const f = g.moveAndCollide(this, dt, true, true);
    this.onGround = f.down;
    if (f.left) this.facing = 1;
    if (f.right) this.facing = -1;
    if (f.down) {
      const aheadX = this.x + this.facing * (this.w / 2 + 4);
      if (!g.solidBelow(aheadX, this.y)) this.facing *= -1;
    }
  }
  draw(ctx: Ctx, t: number): void {
    this.drawFlash(ctx, () => drawSpikeling(ctx, this.x, this.y, t, this.facing, this.squashT > 0));
  }
}

export class Flapper extends Enemy {
  ax: number;
  ay: number;
  constructor(x: number, y: number) {
    super(x, y, 32, 26);
    this.ax = x;
    this.ay = y;
    this.hp = 1;
    this.scoreVal = 300;
  }
  protected ai(dt: number, g: Game): void {
    void g;
    this.x = this.ax + Math.sin(this.t * 0.9) * 90;
    this.y = this.ay + Math.sin(this.t * 2.3) * 34;
    this.facing = Math.cos(this.t * 0.9) > 0 ? 1 : -1;
    this.vx = Math.cos(this.t * 0.9) * 80;
  }
  draw(ctx: Ctx, t: number): void {
    this.drawFlash(ctx, () => drawFlapper(ctx, this.x, this.y, t, this.facing, this.squashT > 0));
  }
}

// ---------------- SNAP BLOOM (piranha plant in pipes) ----------------
export class SnapBloom extends Enemy {
  baseY: number;
  out = 0;
  phase: 'wait' | 'rise' | 'chomp' | 'retract' = 'wait';
  timer = randRange(0.6, 1.6);
  constructor(x: number, y: number) {
    super(x, y, 26, 40);
    this.baseY = y;
    this.stompable = false;
    this.hp = 1;
    this.scoreVal = 300;
  }
  protected ai(dt: number, g: Game): void {
    this.vx = 0;
    const p = g.player;
    // stay hidden while the player stands right on the pipe
    const near = Math.abs(p.x - this.x) < 54 && Math.abs(p.y - this.baseY) < 100;
    this.timer -= dt;
    switch (this.phase) {
      case 'wait':
        this.out = 0;
        this.y = this.baseY;
        if (this.timer <= 0) {
          if (near) this.timer = 0.4;
          else { this.phase = 'rise'; this.timer = 0.55; }
        }
        break;
      case 'rise':
        this.out = clamp(1 - this.timer / 0.55, 0, 1);
        this.y = this.baseY - this.out * 44;
        if (this.timer <= 0) { this.phase = 'chomp'; this.timer = 1.5; this.out = 1; }
        break;
      case 'chomp':
        if (this.timer <= 0) { this.phase = 'retract'; this.timer = 0.45; }
        break;
      case 'retract':
        this.out = Math.max(0, this.timer / 0.45);
        this.y = this.baseY - this.out * 44;
        if (this.timer <= 0) {
          this.phase = 'wait';
          this.timer = randRange(1.2, 2.2);
          this.out = 0;
          this.y = this.baseY;
        }
        break;
    }
  }
  draw(ctx: Ctx, t: number): void {
    this.drawFlash(ctx, () => drawSnapBloom(ctx, this.x, this.baseY, this.out, t));
  }
}

// ---------------- SHELLBY (turtle) ----------------
export class Shellby extends Enemy {
  mode: 'walk' | 'shell' | 'slide' = 'walk';
  shellT = 0;
  kickCd = 0;
  slideDir = 1;
  constructor(x: number, y: number) {
    super(x, y, 30, 27);
    this.hp = 1;
    this.scoreVal = 300;
  }
  protected ai(dt: number, g: Game): void {
    this.kickCd = Math.max(0, this.kickCd - dt);
    if (this.mode === 'walk') {
      this.vx = this.facing * 68;
      const f = g.moveAndCollide(this, dt, true, true);
      this.onGround = f.down;
      if (f.left) this.facing = 1;
      if (f.right) this.facing = -1;
      if (f.down) {
        const aheadX = this.x + this.facing * (this.w / 2 + 4);
        if (!g.solidBelow(aheadX, this.y)) this.facing *= -1;
      }
    } else if (this.mode === 'shell') {
      this.vx = 0;
      this.shellT -= dt;
      const f = g.moveAndCollide(this, dt, true, true);
      this.onGround = f.down;
      if (this.shellT <= 0) {
        this.mode = 'walk';
        this.facing = g.player.x > this.x ? -1 : 1;
        g.sfx('bump');
      }
    } else {
      // sliding shell — bounces off walls, wipes out other enemies
      this.vx = this.slideDir * 430;
      const f = g.moveAndCollide(this, dt, true, true);
      this.onGround = f.down;
      if (f.left) { this.slideDir = 1; g.sfx('bump'); g.shake(1.5); }
      if (f.right) { this.slideDir = -1; g.sfx('bump'); g.shake(1.5); }
      if (chance(dt * 26)) {
        g.burst('spark', this.x, this.y - 10, 1, { ttl: 0.25, size: 3, color: '#d9f2c0' });
      }
      for (const o of g.enemies) {
        if (o === this || o.remove || o.squashT > 0) continue;
        if (o instanceof DandyRival) continue;
        if (this.overlaps(o)) o.magicHit(3, g);
      }
    }
  }
  override stomp(g: Game): void {
    if (this.mode === 'walk') {
      this.mode = 'shell';
      this.shellT = 8;
      this.vx = 0;
      g.addScore(this.scoreVal, this.x, this.top);
      g.sfx('stomp');
      g.burst('puff', this.x, this.y - 10, 4, { vx: randRange(-60, 60), vy: randRange(-80, -20), ttl: 0.5, size: 8, color: 'rgba(255,255,255,0.85)' });
    } else if (this.mode === 'slide') {
      this.stopSlide(g);
    } else {
      this.kick(g.player.x < this.x ? 1 : -1, g);
    }
  }
  kick(dir: number, g: Game): void {
    this.mode = 'slide';
    this.slideDir = dir;
    this.kickCd = 0.3;
    this.shellT = 0;
    g.sfx('kick');
    g.addScore(100, this.x, this.top);
  }
  stopSlide(g: Game): void {
    this.mode = 'shell';
    this.shellT = 8;
    this.vx = 0;
    g.sfx('stomp');
    g.addScore(100, this.x, this.top);
  }
  override magicHit(dmg: number, g: Game): void {
    this.hp -= dmg;
    this.flash = 0.18;
    if (this.hp <= 0) {
      this.remove = true;
      g.addScore(this.scoreVal, this.x, this.top);
      g.sfx('enemyDie');
      g.burst('puff', this.x, this.y - 14, 6, { vx: randRange(-90, 90), vy: randRange(-120, -20), ttl: 0.55, size: 9, color: 'rgba(255,255,255,0.85)' });
    } else {
      g.sfx('dandyHit');
    }
  }
  draw(ctx: Ctx, t: number): void {
    this.drawFlash(ctx, () => drawShellby(ctx, this.x, this.y, t, this.facing, this.mode, this.shellT));
  }
}

// ---------------- BAT MINION (summoned by Dandy) ----------------
export class BatMinion extends Enemy {
  wob = Math.random() * 6;
  constructor(x: number, y: number) {
    super(x, y, 30, 24);
    this.hp = 1;
    this.scoreVal = 150;
  }
  protected ai(dt: number, g: Game): void {
    // homing flight toward Auryn (no tile collision — floats like a specter)
    const p = g.player;
    this.wob += dt;
    const dx = p.x - this.x;
    const dy = p.y - 20 - this.y;
    const d = Math.max(1, Math.hypot(dx, dy));
    const sp = 122;
    this.vx += ((dx / d) * sp - this.vx) * Math.min(1, dt * 1.8);
    this.vy += ((dy / d) * sp - this.vy) * Math.min(1, dt * 1.8) + Math.sin(this.wob * 6) * 30 * dt;
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.facing = dx > 0 ? 1 : -1;
  }
  draw(ctx: Ctx, t: number): void {
    this.drawFlash(ctx, () => drawBat(ctx, this.x, this.y, t + this.wob * 2, this.facing));
  }
}

// ---------------- DANDY (rival) ----------------
export class DandyRival extends Enemy {
  mode: 'patrol' | 'chase' | 'throw' | 'taunt' | 'hurt' | 'defeat' = 'patrol';
  minX: number;
  maxX: number;
  hp: number;
  throwCd = 2;
  tauntT = 0;
  stateT = 0;
  throwT = 0;
  nameT = 0;
  defeatT = 0;
  runPhase = 0;
  world: number;
  constructor(x: number, y: number, world: number) {
    super(x, y, 36, 46);
    this.world = world;
    this.hp = 2 + world; // 3..6
    this.scoreVal = 5000;
    this.minX = x - 280;
    this.maxX = x + 280;
    this.nameT = 0.01; // activates on first sight
  }
  protected ai(dt: number, g: Game): void {
    const p = g.player;
    this.throwT = Math.max(0, this.throwT - dt);
    this.tauntT = Math.max(0, this.tauntT - dt);
    this.stateT -= dt;
    this.nameT = Math.max(0, this.nameT - dt);
    const dx = p.x - this.x;
    const dy = Math.abs(p.y - this.y);
    const dist = Math.abs(dx);

    if (this.mode === 'defeat') {
      this.defeatT -= dt;
      this.vx *= 0.9;
      const f = g.moveAndCollide(this, dt, true, false);
      this.onGround = f.down;
      if (this.defeatT <= 0) {
        this.remove = true;
        g.burst('puff', this.x, this.y - 20, 8, { vx: randRange(-100, 100), vy: randRange(-140, -20), ttl: 0.6, size: 10, color: 'rgba(190,120,255,0.8)' });
      }
      return;
    }
    if (this.mode === 'hurt') {
      if (this.stateT <= 0) this.mode = 'chase';
      this.vx *= 0.8;
      const f = g.moveAndCollide(this, dt, true, true);
      this.onGround = f.down;
      return;
    }
    if (this.mode === 'taunt') {
      this.vx = 0;
      if (this.stateT <= 0) this.mode = 'chase';
      const f = g.moveAndCollide(this, dt, true, true);
      this.onGround = f.down;
      return;
    }

    // sight → activate name tag
    if (this.nameT <= 0 && dist < 460) this.nameT = 3.2;

    const canSee = dist < 360 && dy < 140;
    if (canSee && this.mode === 'patrol') this.mode = 'chase';
    if (!canSee && this.mode === 'chase' && dist > 480) this.mode = 'patrol';

    const spd = this.world >= 3 ? 262 : 235;
    if (this.mode === 'chase') {
      this.facing = dx > 0 ? 1 : -1;
      this.vx = this.facing * spd;
      this.throwCd -= dt;
      if (this.world >= 2 && this.throwCd <= 0 && dist < 430 && this.stateT <= 0) {
        this.mode = 'throw';
        this.stateT = 0.34;
        this.throwT = 0.3;
        g.shots.push(new PurpleOrb(this.x + this.facing * 20, this.y - 28, this.facing * 330, -50));
        g.sfx('shoot');
        this.throwCd = this.world >= 3 ? randRange(1.3, 2) : randRange(1.7, 2.6);
        return;
      }
    } else {
      // patrol
      this.vx = this.facing * 70;
      if (this.x < this.minX) this.facing = 1;
      if (this.x > this.maxX) this.facing = -1;
    }
    // jump obstacles / gaps / player above
    if (this.onGround && this.mode === 'chase') {
      const aheadX = this.x + this.facing * (this.w / 2 + 6);
      const wall = g.solidAt(aheadX, this.y - 20);
      const gap = !g.solidBelow(aheadX, this.y);
      const above = p.y < this.y - 70;
      if (wall || gap || above || (dy < 140 && chance(dt * 0.8))) {
        this.vy = -700;
        this.onGround = false;
      }
    }
    const f = g.moveAndCollide(this, dt, true, true);
    this.onGround = f.down;
    if (f.left) this.facing = 1;
    if (f.right) this.facing = -1;
    if (Math.abs(this.vx) > 10) this.runPhase += Math.abs(this.vx) * dt * 0.055;
  }

  onPlayerHurt(g: Game): void {
    if (this.mode !== 'defeat' && Math.abs(g.player.x - this.x) < 340) {
      this.mode = 'taunt';
      this.stateT = 1;
    }
  }
  override stomp(g: Game): void {
    this.takeHit(1, g);
  }
  override magicHit(dmg: number, g: Game): void {
    this.takeHit(dmg, g);
  }
  takeHit(dmg: number, g: Game): void {
    if (this.mode === 'defeat') return;
    this.hp -= dmg;
    this.flash = 0.2;
    g.sfx('dandyHit');
    if (this.hp <= 0) {
      this.mode = 'defeat';
      this.defeatT = 1.8;
      this.vy = -520;
      this.vx = -this.facing * 140;
      g.addScore(5000, this.x, this.top - 10);
      g.sfx('dandyDefeat');
      g.coinBurst(this.x, this.y - 30, 5);
      g.burst('star', this.x, this.y - 30, 8, { vx: randRange(-160, 160), vy: randRange(-200, -40), ttl: 0.8, size: 6, color: '#ffe14d' });
    } else {
      this.mode = 'hurt';
      this.stateT = 0.32;
      if (this.hp <= Math.ceil((2 + this.world) / 2) && chance(0.6)) {
        this.mode = 'taunt';
        this.stateT = 0.9;
      }
    }
  }
  draw(ctx: Ctx, t: number): void {
    const modeVis: DandyRival['mode'] = this.mode;
    const expr = modeVis === 'taunt' ? 'grin' : modeVis === 'hurt' || modeVis === 'defeat' ? 'shock' : this.hp <= 2 ? 'angry' : 'normal';
    const drawFn = (): void => {
      drawDandy(ctx, this.x, this.y, {
        facing: this.facing,
        run: this.runPhase,
        moving: Math.abs(this.vx) > 20,
        onGround: this.onGround,
        vy: this.vy,
        mode: modeVis === 'throw' ? 'throw' : modeVis === 'taunt' ? 'taunt' : modeVis === 'hurt' ? 'hurt' : modeVis === 'defeat' ? 'defeat' : modeVis === 'chase' ? 'chase' : 'walk',
        throwT: this.throwT,
        t: this.t,
        scale: 1,
        expr,
        aura: this.hp <= 1 ? 0.5 : 0,
      });
    };
    if (this.flash > 0 && Math.floor(this.flash * 40) % 2 === 0) {
      ctx.save();
      ctx.globalAlpha = 0.5;
      drawFn();
      ctx.restore();
    } else drawFn();
    if (this.nameT > 0 && this.mode !== 'defeat') {
      ctx.save();
      ctx.globalAlpha = Math.min(1, this.nameT);
      ctx.font = '900 14px "Arial Black", Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.lineWidth = 4;
      ctx.strokeStyle = 'rgba(20,10,30,0.9)';
      ctx.strokeText('DANDY', this.x, this.y - 64);
      ctx.fillStyle = '#ff6b6b';
      ctx.fillText('DANDY', this.x, this.y - 64);
      ctx.restore();
    }
  }
}

// ---------------- BOSS DANDY — THE VAMPIRE LORD ----------------
export class DandyBoss extends Enemy {
  hp = 15;
  maxHp = 15;
  mode: 'idle' | 'charge' | 'volley' | 'slam' | 'blink' | 'bats' | 'spiral' | 'defeat' = 'idle';
  restT = 1.2;
  stateT = 0;
  volleyN = 0;
  volleyT = 0;
  phase = 1;
  expr: 'normal' | 'grin' | 'angry' | 'shock' = 'normal';
  hurtExprT = 0;
  alpha = 1;
  defeatT = 0;
  runPhase = 0;
  cycle = 0;
  stompCd = 0;
  teleported = false;
  hoverY = 0;
  batPuffT = 0;
  constructor(x: number, y: number) {
    super(x, y, 76, 100);
    this.scoreVal = 10000;
  }
  protected ai(dt: number, g: Game): void {
    const p = g.player;
    const arena = g.level.boss;
    if (!arena) return;
    this.hurtExprT = Math.max(0, this.hurtExprT - dt);
    if (this.mode === 'defeat') {
      // vampire defeat: staggers, then dissolves into a swarm of bats
      this.defeatT -= dt;
      this.vx *= 0.85;
      this.batPuffT -= dt;
      if (this.batPuffT <= 0) {
        this.batPuffT = 0.14;
        g.parts.push(new Particle('bat', this.x + randRange(-28, 28), this.y - randRange(10, 95), {
          vx: randRange(-90, 90), vy: randRange(-230, -70), ttl: 0.9, size: 7, color: '#33101f', grav: -50,
        }));
      }
      this.alpha = clamp(this.defeatT / 1.2, 0, 1);
      const f = g.moveAndCollide(this, dt, true, true);
      this.onGround = f.down;
      if (this.defeatT <= 0) {
        this.remove = true;
        for (let i = 0; i < 14; i++) {
          g.parts.push(new Particle('bat', this.x + randRange(-36, 36), this.y - randRange(0, 105), {
            vx: randRange(-250, 250), vy: randRange(-340, -90), ttl: 1.3, size: 8, color: '#33101f', grav: -70,
          }));
        }
        g.burst('confetti', this.x, this.y - 40, 26, { vx: randRange(-260, 260), vy: randRange(-360, -60), ttl: 1.4, size: 7, color: ['#ff5fa8', '#ffe14d', '#7fe38a', '#7fd4ff'][Math.floor(Math.random() * 4)] });
      }
      return;
    }
    this.stompCd = Math.max(0, this.stompCd - dt);
    switch (this.mode) {
      case 'idle': {
        this.vx = 0;
        this.facing = p.x > this.x ? 1 : -1;
        this.restT -= dt;
        if (this.restT <= 0) {
          this.cycle++;
          const opts = ['charge', 'volley', 'slam'];
          if (this.phase >= 2) opts.push('bats');
          if (this.cycle % 3 === 2) opts.push('blink');
          if (this.phase === 3) opts.push('spiral', 'bats');
          this.mode = opts[Math.floor(Math.random() * opts.length)] as DandyBoss['mode'];
          this.stateT = 0;
          this.volleyN = 0;
          this.volleyT = 0;
          this.teleported = false;
          if (this.mode === 'charge') {
            this.facing = p.x > this.x ? 1 : -1;
            this.stateT = 1.7;
          } else if (this.mode === 'volley') {
            this.stateT = 1.5;
            this.hoverY = Math.max(120, this.y - 130);
          } else if (this.mode === 'slam') {
            this.vy = -1020;
            this.vx = clamp(p.x - this.x, -220, 220) * 1.2;
          } else if (this.mode === 'blink') {
            this.stateT = 0.5;
          } else if (this.mode === 'bats') {
            this.stateT = 2;
            this.hoverY = Math.max(120, this.y - 130);
          } else if (this.mode === 'spiral') {
            this.stateT = 2.4;
            this.hoverY = Math.max(130, this.y - 150);
            this.facing = p.x > this.x ? 1 : -1;
          }
        }
        break;
      }
      case 'charge': {
        this.vx = this.facing * (this.phase === 2 ? 440 : this.phase === 3 ? 480 : 380);
        this.stateT -= dt;
        if (this.x <= arena.left + 40 || this.x >= arena.right - 40 || this.stateT <= 0) {
          this.vx = 0;
          this.toRest();
        }
        break;
      }
      case 'volley': {
        // hovers mid-air casting blood magic (per reference sheet)
        this.hoverFloat(dt, arena);
        this.facing = p.x > this.x ? 1 : -1;
        this.volleyT -= dt;
        const need = this.phase >= 2 ? 4 : 3;
        if (this.volleyT <= 0 && this.volleyN < need) {
          const dy = p.y - 24 - (this.y - 44);
          const dxv = p.x - this.x;
          const len = Math.max(60, Math.hypot(dxv, dy));
          g.shots.push(new PurpleOrb(this.x + this.facing * 22, this.y - 44, (dxv / len) * 350, (dy / len) * 350 - 40));
          g.sfx('shoot');
          this.volleyN++;
          this.volleyT = 0.26;
        }
        this.stateT -= dt;
        if (this.stateT <= 0 && this.volleyN >= need) this.toRest();
        break;
      }
      case 'slam': {
        const f = g.moveAndCollide(this, dt, true, true);
        this.onGround = f.down;
        this.x = clamp(this.x, arena.left + 30, arena.right - 30);
        if (f.down) {
          if (this.stateT < 0) {
            // just landed → shockwaves
            g.shake(7);
            g.sfx('stomp');
            g.shots.push(new Shockwave(this.x - 20, this.y, -280));
            g.shots.push(new Shockwave(this.x + 20, this.y, 280));
            this.stateT = 0.35; // brief pause on the ground
          } else {
            this.stateT -= dt;
            if (this.stateT <= 0) this.toRest();
          }
        } else {
          this.stateT = -1; // airborne marker
        }
        return;
      }
      case 'blink': {
        this.stateT -= dt;
        if (this.stateT > 0 && !this.teleported) {
          // fade out into mist
          this.alpha = Math.max(0, 1 - (0.5 - this.stateT) * 4);
          this.vx = 0;
        } else if (!this.teleported) {
          // bat-teleport near the player
          this.teleported = true;
          this.alpha = 0;
          const side = chance(0.5) ? 1 : -1;
          this.x = clamp(p.x + side * 150, arena.left + 40, arena.right - 40);
          this.y = p.y;
          this.vy = 0;
          this.facing = p.x > this.x ? 1 : -1;
          this.vx = this.facing * 330;
          this.stateT = 0.55;
          g.burst('spark', this.x, this.y - 60, 8, { vx: randRange(-150, 150), vy: randRange(-160, 40), ttl: 0.5, size: 5, color: '#c81e3c' });
        } else {
          this.alpha = Math.min(1, this.alpha + dt * 5);
          this.vx *= 0.96;
          if (this.stateT <= 0) {
            this.teleported = false;
            this.toRest();
          }
        }
        const f = g.moveAndCollide(this, dt, true, true);
        this.onGround = f.down;
        this.x = clamp(this.x, arena.left + 30, arena.right - 30);
        return;
      }
      case 'bats': {
        // KELELAWAR — summons bat familiars that home in on Auryn
        this.hoverFloat(dt, arena);
        this.facing = p.x > this.x ? 1 : -1;
        this.volleyT -= dt;
        const need = this.phase === 3 ? 3 : 2;
        const bats = g.enemies.filter((e) => e instanceof BatMinion && !e.remove).length;
        if (this.volleyT <= 0 && this.volleyN < need && bats < 5) {
          g.enemies.push(new BatMinion(this.x + randRange(-130, 130), this.y - 34));
          g.sfx('bat');
          g.burst('spark', this.x, this.y - 40, 6, { vx: randRange(-120, 120), vy: randRange(-150, -20), ttl: 0.5, size: 4, color: '#ff4d6d' });
          this.volleyN++;
          this.volleyT = 0.55;
        }
        this.stateT -= dt;
        if (this.stateT <= 0 && this.volleyN >= need) this.toRest();
        break;
      }
      case 'spiral': {
        // SIHIR DARAH — radial blood orb ring (phase 3)
        this.hoverFloat(dt, arena);
        this.volleyT -= dt;
        if (this.volleyT <= 0 && this.volleyN < 2) {
          const n = 9;
          for (let i = 0; i < n; i++) {
            const a = (Math.PI * 2 * i) / n + this.volleyN * 0.35;
            g.shots.push(new PurpleOrb(this.x, this.y - 48, Math.cos(a) * 235, Math.sin(a) * 235, 60));
          }
          g.sfx('shoot');
          g.shake(3);
          this.volleyN++;
          this.volleyT = 0.8;
        }
        this.stateT -= dt;
        if (this.volleyN >= 2 && this.stateT <= 0) this.toRest();
        break;
      }
    }
    const f = g.moveAndCollide(this, dt, true, true);
    this.onGround = f.down;
    this.x = clamp(this.x, arena.left + 30, arena.right - 30);
    if (Math.abs(this.vx) > 20) this.runPhase += Math.abs(this.vx) * dt * 0.05;
  }
  private hoverFloat(dt: number, arena: { left: number; right: number }): void {
    // gentle hover toward hoverY — no gravity while casting
    this.y += (this.hoverY - this.y) * Math.min(1, dt * 3.2);
    this.x = clamp(this.x + this.vx * dt, arena.left + 30, arena.right - 30);
  }
  private toRest(): void {
    this.mode = 'idle';
    this.restT = this.phase === 2 ? 0.55 : this.phase === 3 ? 0.4 : 0.95;
    this.vx = 0;
    this.vy = Math.min(this.vy, 0);
  }
  override stomp(g: Game): void {
    if (this.stompCd > 0 || this.mode === 'defeat') return;
    this.stompCd = 0.4;
    this.takeHit(1, g);
  }
  override magicHit(dmg: number, g: Game): void {
    if (this.mode === 'defeat') return;
    this.takeHit(dmg, g);
  }
  private takeHit(dmg: number, g: Game): void {
    this.hp -= dmg;
    this.flash = 0.22;
    this.hurtExprT = 0.5;
    g.sfx('bossHit');
    g.shake(4);
    // phase transitions change his expression + taunt (per reference sheet)
    const ph = this.hp > (this.maxHp * 2) / 3 ? 1 : this.hp > this.maxHp / 3 ? 2 : 3;
    if (ph !== this.phase) {
      this.phase = ph;
      this.expr = ph === 2 ? 'grin' : 'angry';
      if (ph === 2) {
        g.bossSay('Kau pikir ini sudah akhir? Justru ini baru permulaan...');
        g.sfx('roar');
        g.shake(6);
      } else if (ph === 3) {
        g.bossSay('Cukup! Rasakan kekuatan vampirku!');
        g.sfx('roar');
        g.shake(8);
      }
    }
    if (this.hp <= 0) {
      this.hp = 0;
      this.mode = 'defeat';
      this.expr = 'shock';
      this.defeatT = 2.4;
      this.batPuffT = 0;
      this.vy = -560;
      g.addScore(10000, this.x, this.top - 10);
      g.sfx('dandyDefeat');
      g.bossSay('Imposibel... dikalahkan gadis kecil berbaju pink...');
      g.onBossDefeated();
    }
  }
  draw(ctx: Ctx, t: number): void {
    ctx.save();
    ctx.globalAlpha = this.alpha;
    const expr: 'normal' | 'grin' | 'angry' | 'shock' = this.mode === 'defeat' || this.hurtExprT > 0 ? 'shock' : this.expr;
    const drawFn = (): void => {
      drawDandy(ctx, this.x, this.y, {
        facing: this.facing,
        run: this.runPhase,
        moving: Math.abs(this.vx) > 20,
        onGround: this.onGround,
        vy: this.vy,
        mode: this.mode === 'defeat' ? 'defeat' : this.mode === 'volley' || this.mode === 'bats' || this.mode === 'spiral' ? 'float' : this.mode === 'idle' ? 'walk' : 'boss',
        throwT: this.mode === 'volley' || this.mode === 'spiral' ? 0.3 : this.mode === 'bats' ? 0.25 : 0,
        t: this.t,
        scale: 1.6,
        expr,
        aura: this.phase >= 3 ? 1 : this.phase === 2 ? 0.55 : 0,
      });
    };
    if (this.flash > 0 && Math.floor(this.flash * 40) % 2 === 0) {
      ctx.globalAlpha *= 0.55;
    }
    drawFn();
    ctx.restore();
  }
}

// ---------------- PROJECTILES ----------------
export class MagicBolt extends Entity {
  ttl = 0.85;
  dmg: number;
  big: boolean;
  t = 0;
  constructor(x: number, y: number, vx: number, dmg: number, big: boolean) {
    super(x, y, big ? 22 : 16, big ? 22 : 16);
    this.vx = vx;
    this.dmg = dmg;
    this.big = big;
  }
  update(dt: number, g: Game): void {
    this.t += dt;
    this.x += this.vx * dt;
    this.ttl -= dt;
    if (this.ttl <= 0) {
      this.remove = true;
      g.burst('spark', this.x, this.y, 4, { vx: randRange(-60, 60), vy: randRange(-60, 60), ttl: 0.3, size: 3, color: '#ff9ad5' });
      return;
    }
    // wall → pop (+break bricks)
    const front = this.x + Math.sign(this.vx) * 8;
    const tx = Math.floor(front / TILE);
    const ty = Math.floor(this.y / TILE);
    const c = g.tileChar(tx, ty);
    if (c === 'B') {
      g.breakBrick(tx, ty);
      this.remove = true;
      return;
    }
    if (isSolidC(c)) {
      this.remove = true;
      g.burst('spark', this.x, this.y, 5, { vx: randRange(-70, 70), vy: randRange(-70, 70), ttl: 0.3, size: 3, color: '#ffd7ec' });
    }
  }
  draw(ctx: Ctx, t: number): void {
    drawMagicBolt(ctx, this.x, this.y, t + this.t, this.big);
  }
}

export class PurpleOrb extends Entity {
  ttl = 3.2;
  t = 0;
  grav = 260;
  constructor(x: number, y: number, vx: number, vy: number, grav = 260) {
    super(x, y, 16, 16);
    this.vx = vx;
    this.vy = vy;
    this.grav = grav;
  }
  update(dt: number, g: Game): void {
    this.t += dt;
    this.vy += this.grav * dt;
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.ttl -= dt;
    if (this.ttl <= 0) {
      this.remove = true;
      return;
    }
    if (isSolidC(g.tileChar(Math.floor(this.x / TILE), Math.floor(this.y / TILE)))) {
      this.remove = true;
      g.burst('spark', this.x, this.y, 5, { vx: randRange(-70, 70), vy: randRange(-70, 70), ttl: 0.3, size: 3, color: '#b45fff' });
    }
  }
  draw(ctx: Ctx, t: number): void {
    drawOrb(ctx, this.x, this.y, t + this.t);
  }
}

export class Shockwave extends Entity {
  ttl = 2.4;
  constructor(x: number, y: number, vx: number) {
    super(x, y, 22, 26);
    this.vx = vx;
  }
  update(dt: number, g: Game): void {
    this.x += this.vx * dt;
    this.ttl -= dt;
    if (this.ttl <= 0) {
      this.remove = true;
      return;
    }
    if (isSolidC(g.tileChar(Math.floor((this.x + Math.sign(this.vx) * 12) / TILE), Math.floor((this.y - 8) / TILE)))) {
      this.remove = true;
    }
  }
  draw(ctx: Ctx, t: number): void {
    drawShockwave(ctx, this.x, this.y, t);
  }
}

// ---------------- ITEMS ----------------
export class CoinPop extends Entity {
  life = 0.75;
  constructor(x: number, y: number) {
    super(x, y, 12, 12);
    this.vy = -460;
  }
  update(dt: number, g: Game): void {
    this.vy += 1500 * dt;
    this.y += this.vy * dt;
    this.x += this.vx * dt;
    this.life -= dt;
    if (this.life <= 0) {
      this.remove = true;
      g.collectCoin(this.x, this.y);
    }
  }
  draw(ctx: Ctx, t: number): void {
    drawCoin(ctx, this.x, this.y, t * 2, 1.1);
  }
}

export class Pickup extends Entity {
  kind: string;
  riseT = 0;
  t = Math.random() * 5;
  dir = 1;
  constructor(x: number, y: number, kind: string, rise: boolean) {
    super(x, y, 24, 26);
    this.kind = kind;
    if (rise) this.riseT = 0.5;
    this.dir = chance(0.5) ? 1 : -1;
  }
  update(dt: number, g: Game): void {
    this.t += dt;
    if (this.riseT > 0) {
      this.riseT -= dt;
      this.y -= (TILE / 0.5) * dt;
      return;
    }
    if (this.kind === 'mushroom') {
      this.vx = this.dir * 90;
      const f = g.moveAndCollide(this, dt, true, true);
      this.onGround = f.down;
      if (f.left) this.dir = 1;
      if (f.right) this.dir = -1;
    } else {
      this.vx = 0;
      const f = g.moveAndCollide(this, dt, true, true);
      this.onGround = f.down;
    }
  }
  apply(g: Game): void {
    const p = g.player;
    g.addScore(500, this.x, this.top);
    if (this.kind === 'mushroom') {
      p.power = true;
      g.sfx('powerup');
      g.burst('heart', this.x, this.y - 14, 8, { vx: randRange(-120, 120), vy: randRange(-180, -40), ttl: 0.7, size: 7, color: '#ff9ad5', grav: 320 });
    } else if (this.kind === 'star') {
      p.starT = 8;
      g.sfx('star');
      g.burst('star', this.x, this.y - 14, 10, { vx: randRange(-160, 160), vy: randRange(-220, -60), ttl: 0.8, size: 6, color: '#ffe14d' });
    } else if (this.kind === 'crystal') {
      p.magicLvl = Math.min(3, p.magicLvl + 1);
      g.sfx('crystal');
      g.burst('spark', this.x, this.y - 14, 12, { vx: randRange(-140, 140), vy: randRange(-200, -60), ttl: 0.7, size: 5, color: '#ff7ad9' });
    } else if (this.kind === 'heart') {
      p.hp = Math.min(p.maxHp, p.hp + 1);
      g.sfx('heart');
      g.burst('heart', this.x, this.y - 14, 8, { vx: randRange(-120, 120), vy: randRange(-180, -60), ttl: 0.7, size: 7, color: '#ff5f9e' });
    }
    this.remove = true;
  }
  draw(ctx: Ctx, t: number): void {
    drawPickup(ctx, this.kind, this.x, this.y - 14, t + this.t);
  }
}

export class CheckpointEnt extends Entity {
  active = false;
  constructor(x: number, y: number) {
    super(x, y, 30, 40);
  }
  update(dt: number, g: Game): void {
    void dt;
    if (!this.active && g.player.overlaps(this)) {
      this.active = true;
      g.setCheckpoint(this.x, this.y);
      g.sfx('checkpoint');
      g.burst('heart', this.x, this.y - 70, 8, { vx: randRange(-100, 100), vy: randRange(-200, -60), ttl: 0.8, size: 7, color: '#ff9ad5' });
    }
  }
  draw(ctx: Ctx, t: number): void {
    drawCheckpoint(ctx, this.x, this.y, this.active, t);
  }
}

export class FlagEnt extends Entity {
  constructor(x: number, y: number) {
    super(x, y, 20, 40);
  }
  update(dt: number, g: Game): void {
    void dt;
    // trigger only when crossing the pole itself (not far beyond it, e.g. secret rooms)
    if (g.state === 'play' && g.player.x > this.x - 6 && g.player.x < this.x + 90) {
      g.startLevelEnd();
    }
  }
  draw(ctx: Ctx, t: number): void {
    drawFlagpole(ctx, this.x, this.y, t);
  }
}

export class GateEnt extends Entity {
  open = false;
  constructor(x: number, y: number) {
    super(x, y, 90, 40);
  }
  update(dt: number, g: Game): void {
    void dt;
    if (this.open && g.state === 'play' && g.player.overlaps(this)) g.startVictory();
  }
  draw(ctx: Ctx, t: number): void {
    drawGate(ctx, this.x, this.y, this.open, t);
  }
}

export class MovingPlat {
  ox: number; oy: number;
  x: number; y: number;
  w: number;
  dx: number; dy: number;
  range: number; speed: number;
  dir = 1;
  prevX: number; prevY: number;
  dxF = 0; dyF = 0;
  constructor(d: { x: number; y: number; w: number; dx: number; dy: number; range: number; speed: number }) {
    this.ox = d.x;
    this.oy = d.y;
    this.x = d.x;
    this.y = d.y;
    this.w = d.w;
    this.dx = d.dx;
    this.dy = d.dy;
    this.range = d.range;
    this.speed = d.speed;
    this.prevX = d.x;
    this.prevY = d.y;
  }
  get left(): number { return this.x; }
  get top(): number { return this.y; }
  update(dt: number): void {
    this.prevX = this.x;
    this.prevY = this.y;
    const len = Math.hypot(this.dx, this.dy) || 1;
    const ux = this.dx / len;
    const uy = this.dy / len;
    this.x += ux * this.speed * dt * this.dir;
    this.y += uy * this.speed * dt * this.dir;
    const travelled = Math.hypot(this.x - this.ox, this.y - this.oy);
    if (travelled >= this.range) {
      // clamp back onto the line
      this.x = this.ox + ux * this.range * this.dir;
      this.y = this.oy + uy * this.range * this.dir;
      this.dir *= -1;
    }
    this.dxF = this.x - this.prevX;
    this.dyF = this.y - this.prevY;
  }
  draw(ctx: Ctx, theme: string): void {
    // stone platform with rivets
    const skyish = theme === 'sky';
    ctx.fillStyle = skyish ? '#ffffff' : '#8f99ad';
    rr(ctx, this.x, this.y, this.w, 16, 7);
    ctx.fill();
    ctx.fillStyle = skyish ? '#d6f0ff' : 'rgba(0,0,0,0.2)';
    rr(ctx, this.x, this.y + 9, this.w, 7, 5);
    ctx.fill();
    ctx.fillStyle = skyish ? '#b9dff2' : '#c3cad6';
    for (let i = 0; i < Math.floor(this.w / 40); i++) {
      ctx.beginPath();
      ctx.arc(this.x + 12 + i * 40, this.y + 8, 2.4, 0, 7);
      ctx.fill();
    }
  }
}

// ---------------- PARTICLES ----------------
export class Particle {
  kind: ParticleKind;
  x: number; y: number;
  vx: number; vy: number;
  ttl: number; life: number;
  size: number; color: string;
  rot: number; vr: number;
  grav: number;
  constructor(kind: ParticleKind, x: number, y: number, o: { vx?: number; vy?: number; ttl?: number; size?: number; color?: string; grav?: number }) {
    this.kind = kind;
    this.x = x;
    this.y = y;
    this.vx = o.vx ?? 0;
    this.vy = o.vy ?? 0;
    this.ttl = o.ttl ?? 0.6;
    this.life = this.ttl;
    this.size = o.size ?? 5;
    this.color = o.color ?? '#fff';
    this.rot = Math.random() * Math.PI * 2;
    this.vr = randRange(-6, 6);
    this.grav = o.grav ?? 60;
  }
  update(dt: number): void {
    this.vy += this.grav * dt;
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.rot += this.vr * dt;
    this.ttl -= dt;
  }
  draw(ctx: Ctx): void {
    drawParticleP(ctx, this);
  }
}

function drawParticleP(ctx: Ctx, p: Particle): void {
  const alpha = clamp(p.ttl / p.life, 0, 1);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(p.x, p.y);
  ctx.rotate(p.rot);
  if (p.kind === 'heart') {
    ctx.scale(p.size / 10, p.size / 10);
    ctx.beginPath();
    ctx.moveTo(0, 3);
    ctx.bezierCurveTo(-10, -6, -5, -12, 0, -6);
    ctx.bezierCurveTo(5, -12, 10, -6, 0, 3);
    ctx.closePath();
    ctx.fillStyle = p.color;
    ctx.fill();
  } else if (p.kind === 'star') {
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const r = i % 2 === 0 ? p.size : p.size * 0.45;
      const a = (i / 10) * Math.PI * 2 - Math.PI / 2;
      if (i === 0) ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
      else ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
    }
    ctx.closePath();
    ctx.fillStyle = p.color;
    ctx.fill();
  } else if (p.kind === 'spark') {
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(0, 0, p.size * 0.5, 0, Math.PI * 2);
    ctx.fill();
  } else if (p.kind === 'puff') {
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(0, 0, p.size, 0, Math.PI * 2);
    ctx.arc(p.size * 0.8, p.size * 0.2, p.size * 0.7, 0, Math.PI * 2);
    ctx.arc(-p.size * 0.8, p.size * 0.2, p.size * 0.7, 0, Math.PI * 2);
    ctx.fill();
  } else if (p.kind === 'confetti') {
    ctx.fillStyle = p.color;
    ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
  } else if (p.kind === 'note') {
    ctx.fillStyle = p.color;
    ctx.font = `${p.size * 2.4}px Arial`;
    ctx.textAlign = 'center';
    ctx.fillText('♪', 0, 0);
  } else if (p.kind === 'bat') {
    ctx.rotate(-p.rot); // bats glide, they don't tumble
    ctx.scale(p.size / 8, p.size / 8);
    drawBat(ctx, 0, 0, (p.life - p.ttl) * 9, p.vx >= 0 ? 1 : -1);
  }
  ctx.restore();
}

// local helpers
function isSolidC(c: string): boolean {
  return c !== '.' && c !== 'C' && c !== 'i' && c !== 'm' && c !== 'v' && c !== '*' && c !== 'F' && c !== 'E' &&
    c !== '1' && c !== '2' && c !== '3' && c !== '4' && c !== '^';
}
