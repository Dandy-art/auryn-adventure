// Main game class: loop, states, physics, camera, collisions, flow
import { AudioEngine } from './audio';
import { LEVELS, worldMusic } from './levels';
import {
  InputKey, InputMap, LevelDef, ROWS, SaveData, TILE, VIEW_H, VIEW_W,
  clamp, emptyInput, isSolidChar, lerp, randRange,
} from './types';
import { drawBackground, drawBarrier, drawCandelabra, drawCastle, drawTile, rr, text } from './draw';
import {
  CheckpointEnt, CoinPop, DandyBoss, DandyRival, Enemy, Entity, FlagEnt, Flapper,
  GateEnt, Grumblit, MagicBolt, MovingPlat, Particle, Pickup,
  Player, PurpleOrb, Shockwave, Shellby, SnapBloom, Spikeling,
} from './entities';
import type { ParticleKind } from './chars';
import {
  Btn, drawGameOver, drawHUD, drawHowTo, drawLevelEnd, drawMenuScene, drawPause,
  drawSettings, drawTitleCard, drawVictory, drawWorldSelect, gameOverButtons,
  hitTest, howBackBtn, menuButtons, pauseButtons, settingsButtons, victoryButtons,
  worldButtons,
} from './ui';

type GState =
  | 'menu' | 'worlds' | 'howto' | 'settings'
  | 'starting' | 'play' | 'pause' | 'bossintro'
  | 'dying' | 'levelend' | 'gameover' | 'victory';

const SAVE_KEY = 'auryn-save-v1';
const G = 2300;

interface PipeRef { tx: number; ty: number; destX: number; destY: number }

function defaultSave(): SaveData {
  return { unlocked: 1, best: [0, 0, 0, 0, 0], sound: true, music: true };
}

export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private dpr = 1;
  private raf = 0;
  private lastT = 0;
  t = 0;

  private keys: InputMap = emptyInput();
  private prevKeys: InputMap = emptyInput();
  audio = new AudioEngine();
  save: SaveData = defaultSave();

  state: GState = 'menu';
  world = 1;
  level: LevelDef = LEVELS[0];
  grid: string[][] = [];
  levelW = 0;
  levelH = ROWS;
  finishX = 0;

  player: Player = new Player(120, 520);
  enemies: Enemy[] = [];
  items: Pickup[] = [];
  pops: CoinPop[] = [];
  shots: (MagicBolt | PurpleOrb | Shockwave)[] = [];
  parts: Particle[] = [];
  plats: MovingPlat[] = [];
  checkpoints: CheckpointEnt[] = [];
  flag: FlagEnt | null = null;
  gate: GateEnt | null = null;
  dandy: DandyRival | null = null;
  boss: DandyBoss | null = null;
  bossSpawned = false;
  barrierOn = false;
  bossIntroT = 0;
  bossQuote: { text: string; t: number } | null = null;

  cam = { x: 0, y: 0, shake: 0 };
  coins = 0;
  score = 0;
  lives = 3;
  elapsed = 0;
  kills = 0;
  private checkpointPos: { x: number; y: number } | null = null;
  private bumps = new Map<string, number>();
  private warpDest: PipeRef | null = null;

  private fadeT = 1;
  private fadePhase: 0 | 1 | 2 = 2;
  private fadeCb: (() => void) | null = null;

  sel = 0;
  selWorld = 0;
  buttons: Btn[] = menuButtons(true);
  stats = { coins: 0, timeBonus: 0, kills: 0, score: 0 };
  private titleT = 0;
  private endT = 0;
  private endDone = false;

  private cleanupFns: (() => void)[] = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('no 2d context');
    this.ctx = ctx;
    this.loadSave();
    this.audio.setSound(this.save.sound);
    this.audio.setMusic(this.save.music);
    this.buttons = menuButtons(this.save.sound);
    this.bindEvents();
    this.resize();
    this.audio.playMusic('menu');
    this.raf = requestAnimationFrame(this.loop);
  }

  // ---------------- persistence ----------------
  private loadSave(): void {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) {
        const d = JSON.parse(raw) as Partial<SaveData>;
        this.save = {
          unlocked: clamp(d.unlocked ?? 1, 1, 5),
          best: [0, 0, 0, 0, 0].map((_, i) => d.best?.[i] ?? 0),
          sound: d.sound ?? true,
          music: d.music ?? true,
        };
      }
    } catch { /* ignore */ }
  }
  private writeSave(): void {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.save));
    } catch { /* ignore */ }
  }

  // ---------------- input ----------------
  private keyMap: Record<string, InputKey[]> = {
    KeyA: ['left'], ArrowLeft: ['left'],
    KeyD: ['right'], ArrowRight: ['right'],
    KeyS: ['down'], ArrowDown: ['down'],
    KeyW: ['up', 'jump'], ArrowUp: ['up', 'jump'],
    Space: ['jump'],
    KeyX: ['attack'], KeyK: ['attack'],
    Escape: ['pause'], KeyP: ['pause'],
    Enter: ['confirm'],
  };

  private onKeyDown = (e: KeyboardEvent): void => {
    const ks = this.keyMap[e.code];
    if (!ks) return;
    e.preventDefault();
    this.audio.unlock();
    for (const k of ks) this.keys[k] = true;
  };
  private onKeyUp = (e: KeyboardEvent): void => {
    const ks = this.keyMap[e.code];
    if (!ks) return;
    e.preventDefault();
    for (const k of ks) this.keys[k] = false;
  };

  private canvasPoint(e: PointerEvent): { x: number; y: number } {
    const r = this.canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - r.left) / r.width) * VIEW_W,
      y: ((e.clientY - r.top) / r.height) * VIEW_H,
    };
  }
  private onPointerDown = (e: PointerEvent): void => {
    this.audio.unlock();
    const { x, y } = this.canvasPoint(e);
    const btns = this.currentButtons();
    if (!btns) return;
    const i = hitTest(btns, x, y);
    if (i >= 0) {
      this.sel = i;
      this.audio.sfx('uiSelect');
      this.activate(i);
    }
  };
  private onPointerMove = (e: PointerEvent): void => {
    const btns = this.currentButtons();
    if (!btns) return;
    const { x, y } = this.canvasPoint(e);
    const i = hitTest(btns, x, y);
    if (i >= 0 && i !== this.sel) {
      this.sel = i;
      this.audio.sfx('uiMove');
    }
  };

  private onResize = (): void => this.resize();

  private bindEvents(): void {
    window.addEventListener('keydown', this.onKeyDown, { passive: false });
    window.addEventListener('keyup', this.onKeyUp, { passive: false });
    window.addEventListener('resize', this.onResize);
    this.canvas.addEventListener('pointerdown', this.onPointerDown);
    this.canvas.addEventListener('pointermove', this.onPointerMove);
    this.cleanupFns.push(() => {
      window.removeEventListener('keydown', this.onKeyDown);
      window.removeEventListener('keyup', this.onKeyUp);
      window.removeEventListener('resize', this.onResize);
      this.canvas.removeEventListener('pointerdown', this.onPointerDown);
      this.canvas.removeEventListener('pointermove', this.onPointerMove);
    });
  }

  /** Public API for touch buttons */
  setKey(k: InputKey, down: boolean): void {
    this.keys[k] = down;
    if (down) this.audio.unlock();
  }

  private resize(): void {
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const scale = Math.min(vw / VIEW_W, vh / VIEW_H);
    const w = Math.floor(VIEW_W * scale);
    const h = Math.floor(VIEW_H * scale);
    this.canvas.width = Math.floor(VIEW_W * this.dpr);
    this.canvas.height = Math.floor(VIEW_H * this.dpr);
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
  }

  // ---------------- helpers ----------------
  pressed(k: InputKey): boolean {
    return this.keys[k] && !this.prevKeys[k];
  }
  get input(): InputMap {
    return this.keys;
  }
  sfx(name: Parameters<AudioEngine['sfx']>[0]): void {
    this.audio.sfx(name);
  }
  shake(v: number): void {
    this.cam.shake = Math.max(this.cam.shake, v);
  }
  burst(kind: ParticleKind, x: number, y: number, n: number, o: { vx?: number; vy?: number; ttl?: number; size?: number; color?: string | string[]; grav?: number }): void {
    for (let i = 0; i < n; i++) {
      const color = Array.isArray(o.color) ? o.color[Math.floor(Math.random() * o.color.length)] : o.color;
      this.parts.push(new Particle(kind, x + randRange(-6, 6), y + randRange(-6, 6), {
        ...o,
        vx: (o.vx ?? 0) + randRange(-30, 30),
        vy: (o.vy ?? 0) + randRange(-30, 30),
        color,
      }));
    }
  }
  addScore(v: number, x: number, y: number): void {
    this.score += v;
    this.kills++;
    this.parts.push(new Particle('note', x, y - 6, { vy: -70, ttl: 0.8, size: 6, color: '#fff', grav: 0 }));
  }
  collectCoin(x: number, y: number): void {
    this.coins++;
    this.score += 100;
    this.sfx('coin');
    this.burst('spark', x, y, 4, { ttl: 0.35, size: 3, color: '#ffe14d', grav: 0 });
  }
  coinBurst(x: number, y: number, n: number): void {
    for (let i = 0; i < n; i++) {
      const c = new CoinPop(x + randRange(-14, 14), y + randRange(-6, 6));
      c.vx = randRange(-90, 90);
      this.pops.push(c);
    }
  }
  tileChar(tx: number, ty: number): string {
    if (tx < 0 || tx >= this.levelW || ty < 0 || ty >= this.levelH) return '.';
    return this.grid[ty][tx];
  }
  solidAt(px: number, py: number): boolean {
    return isSolidChar(this.tileChar(Math.floor(px / TILE), Math.floor(py / TILE)));
  }
  solidBelow(px: number, py: number): boolean {
    return isSolidChar(this.tileChar(Math.floor(px / TILE), Math.floor((py + 6) / TILE)));
  }
  touchingHazard(e: Entity): boolean {
    const x0 = Math.floor(e.left / TILE);
    const x1 = Math.floor(e.right / TILE);
    const y0 = Math.floor(e.top / TILE);
    const y1 = Math.floor((e.y - 4) / TILE);
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (this.tileChar(tx, ty) === '^') return true;
      }
    }
    return false;
  }

  moveAndCollide(
    e: Entity, dt: number, useGravity = true, jumpHeld = true
  ): { left: boolean; right: boolean; up: boolean; down: boolean; bumpTx: number; bumpTy: number } {
    const res = { left: false, right: false, up: false, down: false, bumpTx: -1, bumpTy: -1 };
    if (useGravity) {
      const gEff = !jumpHeld && e.vy < 0 ? G * 1.7 : G;
      e.vy = Math.min(e.vy + gEff * dt, 1150);
    }
    const half = e.w / 2;
    // X axis
    if (e.vx !== 0) {
      e.x += e.vx * dt;
      const dir = Math.sign(e.vx);
      const edge = e.x + dir * half;
      const tx = Math.floor(edge / TILE);
      for (const fy of [0.15, 0.55, 0.95]) {
        const ty = Math.floor((e.y - e.h * fy) / TILE);
        if (isSolidChar(this.tileChar(tx, ty))) {
          e.x = dir > 0 ? tx * TILE - half - 0.02 : (tx + 1) * TILE + half + 0.02;
          if (dir > 0) res.right = true;
          else res.left = true;
          break;
        }
      }
    }
    // Y axis
    e.y += e.vy * dt;
    e.onGround = false;
    if (e.vy >= 0) {
      const ty = Math.floor(e.y / TILE);
      for (const fx of [0.2, 0.5, 0.8]) {
        const tx = Math.floor((e.x - half + e.w * fx) / TILE);
        if (isSolidChar(this.tileChar(tx, ty))) {
          e.y = ty * TILE - 0.02;
          e.vy = 0;
          res.down = true;
          break;
        }
      }
    } else {
      const ty = Math.floor((e.y - e.h) / TILE);
      let hit = false;
      let bumpTx = -1;
      for (const fx of [0.2, 0.5, 0.8]) {
        const tx = Math.floor((e.x - half + e.w * fx) / TILE);
        if (isSolidChar(this.tileChar(tx, ty))) {
          hit = true;
          if (bumpTx < 0 || Math.abs(tx * TILE + 20 - e.x) < Math.abs(bumpTx * TILE + 20 - e.x)) bumpTx = tx;
        }
      }
      if (hit) {
        e.y = (ty + 1) * TILE + e.h + 0.02;
        e.vy = 0;
        res.up = true;
        res.bumpTx = bumpTx;
        res.bumpTy = ty;
      }
    }
    e.x = clamp(e.x, 10, this.levelW * TILE - 10);
    return res;
  }

  // ---------------- level flow ----------------
  private buildEntities(): void {
    const def = this.level;
    this.grid = def.rows.map((r) => r.split(''));
    this.levelW = this.grid[0].length;
    this.levelH = this.grid.length;
    this.enemies = [];
    this.items = [];
    this.pops = [];
    this.shots = [];
    this.parts = [];
    this.plats = def.platforms.map((d) => new MovingPlat(d));
    this.checkpoints = [];
    this.flag = null;
    this.gate = null;
    this.dandy = null;
    this.boss = null;
    this.bossSpawned = false;
    this.barrierOn = false;
    this.bumps.clear();
    for (let ty = 0; ty < this.levelH; ty++) {
      for (let tx = 0; tx < this.levelW; tx++) {
        const c = this.grid[ty][tx];
        const cx = tx * TILE + TILE / 2;
        const feetY = (ty + 1) * TILE;
        if (c === '1') {
          this.enemies.push(new Grumblit(cx, feetY, this.world));
          this.grid[ty][tx] = '.';
        } else if (c === '2') {
          this.enemies.push(new Spikeling(cx, feetY));
          this.grid[ty][tx] = '.';
        } else if (c === '3') {
          this.enemies.push(new Flapper(cx, ty * TILE + 26));
          this.grid[ty][tx] = '.';
        } else if (c === '5') {
          // piranha plant anchored to the pipe below (marker on the right pipe column)
          this.enemies.push(new SnapBloom(cx + 12, feetY));
          this.grid[ty][tx] = '.';
        } else if (c === '6') {
          this.enemies.push(new Shellby(cx, feetY));
          this.grid[ty][tx] = '.';
        } else if (c === '4') {
          this.dandy = new DandyRival(cx, feetY, this.world);
          this.enemies.push(this.dandy);
          this.grid[ty][tx] = '.';
        } else if (c === '*') {
          this.checkpoints.push(new CheckpointEnt(cx, feetY));
          this.grid[ty][tx] = '.';
        } else if (c === 'F') {
          this.flag = new FlagEnt(cx, feetY);
          this.grid[ty][tx] = '.';
        } else if (c === 'E') {
          this.gate = new GateEnt(cx, feetY);
          this.grid[ty][tx] = '.';
        }
      }
    }
    this.finishX = this.flag ? this.flag.x : this.gate ? this.gate.x : def.castleX || this.levelW * TILE;
  }

  private placePlayer(x: number, y: number): void {
    this.player = new Player(x, y);
    this.cam.x = clamp(x - VIEW_W * 0.42, 0, this.levelW * TILE - VIEW_W);
    this.cam.y = clamp(y - VIEW_H * 0.62, 0, this.levelH * TILE - VIEW_H);
  }

  loadWorld(w: number): void {
    this.world = w;
    this.level = LEVELS[w - 1];
    this.checkpointPos = null;
    this.coins = 0;
    this.elapsed = 0;
    this.kills = 0;
    this.buildEntities();
    this.placePlayer(this.level.startX, this.level.startY);
    this.state = 'starting';
    this.titleT = 0;
    this.fadeT = 1;
    this.fadePhase = 2;
    this.audio.playMusic(worldMusic(w));
  }

  private respawn(): void {
    this.buildEntities();
    const cp = this.checkpointPos;
    this.placePlayer(cp ? cp.x : this.level.startX, cp ? cp.y : this.level.startY);
    this.state = 'play';
    this.fadeT = 1;
    this.fadePhase = 2;
    this.audio.playMusic(worldMusic(this.world));
  }

  private startFade(cb: () => void): void {
    this.fadePhase = 1;
    this.fadeCb = cb;
  }

  private gotoMenu(): void {
    this.state = 'menu';
    this.sel = 0;
    this.buttons = menuButtons(this.save.sound);
    this.audio.playMusic('menu');
    this.fadeT = 1;
    this.fadePhase = 2;
  }

  private newRun(): void {
    this.lives = 3;
    this.score = 0;
    this.checkpointPos = null;
    this.loadWorld(1);
  }

  private currentButtons(): Btn[] | null {
    switch (this.state) {
      case 'menu': return this.buttons;
      case 'worlds': return worldButtons(this.save.unlocked);
      case 'howto': return [howBackBtn];
      case 'settings': return settingsButtons(this.save);
      case 'pause': return pauseButtons();
      case 'gameover': return gameOverButtons();
      case 'victory': return victoryButtons();
      default: return null;
    }
  }

  private activate(i: number): void {
    switch (this.state) {
      case 'menu':
        if (i === 0) this.startFade(() => this.newRun());
        else if (i === 1) { this.state = 'worlds'; this.selWorld = 0; }
        else if (i === 2) { this.state = 'howto'; this.sel = 0; }
        else if (i === 3) { this.state = 'settings'; this.sel = 0; }
        else if (i === 4) {
          this.save.sound = !this.save.sound;
          this.audio.setSound(this.save.sound);
          this.writeSave();
          this.buttons = menuButtons(this.save.sound);
        }
        break;
      case 'worlds': {
        const btns = worldButtons(this.save.unlocked);
        if (i === btns.length - 1) { this.state = 'menu'; this.sel = 0; }
        else if (i < this.save.unlocked) {
          this.lives = 3;
          this.score = 0;
          this.startFade(() => this.loadWorld(i + 1));
        } else {
          this.audio.sfx('bump');
        }
        break;
      }
      case 'howto':
        this.state = 'menu';
        this.sel = 0;
        break;
      case 'settings':
        if (i === 0) {
          this.save.sound = !this.save.sound;
          this.audio.setSound(this.save.sound);
          this.writeSave();
        } else if (i === 1) {
          this.save.music = !this.save.music;
          this.audio.setMusic(this.save.music);
          this.writeSave();
        } else if (i === 2) {
          this.save.unlocked = 1;
          this.save.best = [0, 0, 0, 0, 0];
          this.writeSave();
          this.audio.sfx('powerup');
        } else {
          this.state = 'menu';
          this.sel = 0;
        }
        break;
      case 'pause':
        if (i === 0) this.state = 'play';
        else if (i === 1) this.startFade(() => { this.checkpointPos = null; this.loadWorld(this.world); });
        else this.startFade(() => this.gotoMenu());
        break;
      case 'gameover':
        if (i === 0) {
          this.lives = 3;
          this.startFade(() => this.loadWorld(this.world));
        } else {
          this.startFade(() => this.gotoMenu());
        }
        break;
      case 'victory':
        if (i === 0) this.startFade(() => this.newRun());
        else this.startFade(() => this.gotoMenu());
        break;
      default:
        break;
    }
  }

  // ---------------- interactions ----------------
  bumpTile(tx: number, ty: number): void {
    if (tx < 0 || tx >= this.levelW || ty < 0 || ty >= this.levelH) return;
    const c = this.grid[ty][tx];
    const key = `${tx},${ty}`;
    if (c === '?') {
      this.grid[ty][tx] = 'U';
      this.bumps.set(key, 0.24);
      this.collectCoin(tx * TILE + TILE / 2, ty * TILE);
      this.coinBurst(tx * TILE + TILE / 2, ty * TILE, 1);
    } else if (c === 'M' || c === 'N' || c === 'K' || c === 'L') {
      this.grid[ty][tx] = 'U';
      this.bumps.set(key, 0.24);
      this.items.push(new Pickup(tx * TILE + TILE / 2, ty * TILE, c === 'M' ? 'mushroom' : c === 'N' ? 'star' : c === 'K' ? 'crystal' : 'heart', true));
      this.sfx('bump');
    } else if (c === 'B' || c === 'U') {
      this.bumps.set(key, 0.18);
      this.sfx('bump');
    }
  }

  breakBrick(tx: number, ty: number): void {
    if (tx < 0 || tx >= this.levelW || ty < 0 || ty >= this.levelH) return;
    if (this.grid[ty][tx] !== 'B') return;
    this.grid[ty][tx] = '.';
    this.score += 50;
    this.sfx('break');
    this.burst('spark', tx * TILE + 20, ty * TILE + 20, 8, { vx: randRange(-140, 140), vy: randRange(-220, -40), ttl: 0.6, size: 5, color: '#c9803f', grav: 700 });
  }

  tryPipeEnter(p: Player): void {
    if (p.warpT > 0 || !this.level.pipes.length) return;
    for (const pipe of this.level.pipes) {
      const topY = pipe.ty * TILE;
      if (Math.abs(p.y - topY) < 8 && p.x > pipe.tx * TILE + 4 && p.x < (pipe.tx + 2) * TILE - 4) {
        p.warpT = 0.55;
        p.vx = 0;
        this.warpDest = pipe;
        this.sfx('pipe');
        return;
      }
    }
  }

  finishWarp(): void {
    const d = this.warpDest;
    this.warpDest = null;
    if (!d) return;
    const p = this.player;
    p.x = d.destX;
    p.y = d.destY;
    p.vx = 0;
    p.vy = 0;
    p.invulnT = 1;
    this.sfx('warp');
    this.burst('heart', p.x, p.y - 30, 8, { vx: randRange(-120, 120), vy: randRange(-180, -40), ttl: 0.7, size: 7, color: '#ff9ad5' });
    this.cam.x = clamp(p.x - VIEW_W * 0.42, 0, this.levelW * TILE - VIEW_W);
    this.cam.y = clamp(p.y - VIEW_H * 0.62, 0, this.levelH * TILE - VIEW_H);
  }

  setCheckpoint(x: number, y: number): void {
    this.checkpointPos = { x, y };
  }

  killPlayer(withAnim: boolean): void {
    if (this.state !== 'play' && this.state !== 'bossintro') return;
    this.sfx('death');
    this.state = 'dying';
    this.player.deadT = 0;
    if (withAnim) {
      this.player.vy = -640;
      this.player.vx = 0;
    } else {
      this.player.deadT = 0.6; // already falling into a pit
    }
  }

  startLevelEnd(): void {
    if (this.state !== 'play') return;
    this.state = 'levelend';
    this.endT = 0;
    this.endDone = false;
    this.player.win = true;
    this.player.vx = 0;
    this.sfx('flag');
    this.burst('confetti', this.player.x, this.player.y - 60, 16, { vx: randRange(-160, 160), vy: randRange(-260, -80), ttl: 1.2, size: 6, color: ['#ff5fa8', '#ffe14d', '#7fe38a', '#7fd4ff'] });
  }

  private finishLevelTally(): void {
    const timeBonus = Math.max(0, 260 - Math.floor(this.elapsed)) * 10;
    this.stats = {
      coins: this.coins,
      timeBonus,
      kills: this.kills,
      score: this.score + timeBonus,
    };
    this.score += timeBonus;
    if (this.world < 5) {
      this.save.unlocked = Math.max(this.save.unlocked, Math.min(5, this.world + 1));
    }
    this.save.best[this.world - 1] = Math.max(this.save.best[this.world - 1] ?? 0, this.score);
    this.writeSave();
  }

  spawnBoss(): void {
    const arena = this.level.boss;
    if (!arena) return;
    this.bossSpawned = true;
    this.boss = new DandyBoss(arena.bossX, 520);
    this.barrierOn = true;
    this.state = 'bossintro';
    this.bossIntroT = 2.2;
    this.sfx('roar');
    this.audio.playMusic('boss');
    this.player.nameT = 2.5;
    this.shake(6);
  }

  bossSay(text: string): void {
    this.bossQuote = { text, t: 3.4 };
  }

  onBossDefeated(): void {
    this.barrierOn = false;
    if (this.gate) this.gate.open = true;
    this.audio.playMusic(worldMusic(this.world));
    this.sfx('gate');
    this.shake(8);
    this.burst('confetti', this.player.x, this.player.y - 80, 20, { vx: randRange(-220, 220), vy: randRange(-320, -100), ttl: 1.4, size: 7, color: ['#ff5fa8', '#ffe14d', '#7fe38a', '#7fd4ff'] });
  }

  startVictory(): void {
    this.state = 'victory';
    this.sel = 0;
    this.stats = { coins: this.coins, timeBonus: Math.max(0, 260 - Math.floor(this.elapsed)) * 10, kills: this.kills, score: this.score };
    this.save.unlocked = 5;
    this.save.best[4] = Math.max(this.save.best[4] ?? 0, this.score);
    this.writeSave();
    this.audio.playMusic('victory');
    this.sfx('victory');
  }

  // ---------------- update ----------------
  private loop = (ts: number): void => {
    this.raf = requestAnimationFrame(this.loop);
    if (!this.lastT) this.lastT = ts;
    const dt = clamp((ts - this.lastT) / 1000, 0, 0.033);
    this.lastT = ts;
    this.t += dt;
    this.update(dt);
    this.render();
    this.prevKeys = { ...this.keys };
  };

  private updateFade(dt: number): void {
    if (this.fadePhase === 1) {
      this.fadeT = Math.min(1, this.fadeT + dt * 3);
      if (this.fadeT >= 1) {
        this.fadeCb?.();
        this.fadeCb = null;
        this.fadePhase = 2;
      }
    } else if (this.fadePhase === 2) {
      this.fadeT = Math.max(0, this.fadeT - dt * 2.2);
      if (this.fadeT <= 0) this.fadePhase = 0;
    }
  }

  private menuNav(n: number, horizontal = false): void {
    const up = this.pressed('up') || (!horizontal && this.pressed('left'));
    const down = this.pressed('down') || (!horizontal && this.pressed('right'));
    const left = this.pressed('left');
    const right = this.pressed('right');
    let moved = false;
    if (horizontal) {
      if (left) { this.sel = (this.sel + n - 1) % n; moved = true; }
      if (right) { this.sel = (this.sel + 1) % n; moved = true; }
      if (this.pressed('up')) { this.sel = (this.sel + n - 1) % n; moved = true; }
      if (this.pressed('down')) { this.sel = (this.sel + 1) % n; moved = true; }
    } else {
      if (up) { this.sel = (this.sel + n - 1) % n; moved = true; }
      if (down) { this.sel = (this.sel + 1) % n; moved = true; }
    }
    if (moved) this.audio.sfx('uiMove');
  }

  private confirmPressed(): boolean {
    return this.pressed('confirm') || this.pressed('jump');
  }

  private update(dt: number): void {
    this.updateFade(dt);
    const st = this.state;
    if (st === 'menu') {
      this.menuNav(this.buttons.length);
      if (this.confirmPressed()) {
        this.audio.sfx('uiSelect');
        this.activate(this.sel);
      }
      if (this.pressed('pause')) { this.state = 'menu'; }
      return;
    }
    if (st === 'worlds') {
      this.menuNav(6, true);
      if (this.confirmPressed()) {
        this.audio.sfx('uiSelect');
        this.activate(this.sel);
      }
      if (this.pressed('pause')) { this.state = 'menu'; this.sel = 0; }
      return;
    }
    if (st === 'howto') {
      if (this.confirmPressed() || this.pressed('pause')) {
        this.audio.sfx('uiSelect');
        this.state = 'menu';
        this.sel = 0;
      }
      return;
    }
    if (st === 'settings') {
      this.menuNav(4);
      if (this.confirmPressed()) {
        this.audio.sfx('uiSelect');
        this.activate(this.sel);
      }
      if (this.pressed('pause')) { this.state = 'menu'; this.sel = 0; }
      return;
    }
    if (st === 'starting') {
      this.titleT += dt;
      this.updateCommon(dt, true);
      if (this.titleT >= 1.8) this.state = 'play';
      return;
    }
    if (st === 'pause') {
      this.menuNav(3);
      if (this.confirmPressed()) {
        this.audio.sfx('uiSelect');
        this.activate(this.sel);
      }
      if (this.pressed('pause')) this.state = 'play';
      return;
    }
    if (st === 'gameover') {
      this.menuNav(2);
      if (this.confirmPressed()) {
        this.audio.sfx('uiSelect');
        this.activate(this.sel);
      }
      return;
    }
    if (st === 'victory') {
      this.menuNav(2);
      if (chanceVs(dt, 8)) {
        this.parts.push(new Particle('confetti', randRange(0, VIEW_W), -10, {
          vx: randRange(-40, 40), vy: randRange(60, 140), ttl: 3, size: 7,
          color: ['#ff5fa8', '#ffe14d', '#7fe38a', '#7fd4ff', '#fff'][Math.floor(Math.random() * 5)], grav: 30,
        }));
      }
      this.updateParts(dt);
      if (this.confirmPressed()) {
        this.audio.sfx('uiSelect');
        this.activate(this.sel);
      }
      return;
    }
    if (st === 'bossintro') {
      this.bossIntroT -= dt;
      this.updateCommon(dt, true);
      if (this.bossIntroT <= 0) this.state = 'play';
      return;
    }
    if (st === 'dying') {
      const p = this.player;
      p.deadT += dt;
      if (p.deadT > 0.55) {
        p.vy += 1700 * dt;
        p.y += p.vy * dt;
      }
      this.updateParts(dt);
      if (p.deadT >= 1.6) {
        this.lives--;
        if (this.lives <= 0) {
          this.state = 'gameover';
          this.sel = 0;
          this.audio.stopMusic();
          this.sfx('gameover');
        } else {
          this.respawn();
        }
      }
      return;
    }
    if (st === 'levelend') {
      this.endT += dt;
      const doorX = this.level.castleX > 0 ? this.level.castleX + 150 : this.player.x + 60;
      if (this.player.x < doorX - 4) {
        this.player.autoWalk(dt, this);
      } else {
        this.player.moving = false;
        this.player.vx = 0;
      }
      if (this.endT > 1.1 && !this.endDone) {
        this.finishLevelTally();
        this.endDone = true;
      }
      this.updateCommon(dt, true);
      if (this.endDone && this.endT > 2 && (this.confirmPressed())) {
        this.audio.sfx('uiSelect');
        if (this.world < 5) {
          this.startFade(() => this.loadWorld(this.world + 1));
        }
      }
      return;
    }
    if (st === 'play') {
      if (this.pressed('pause')) {
        this.state = 'pause';
        this.sel = 0;
        this.audio.sfx('uiSelect');
        return;
      }
      this.gameplay(dt);
    }
  }

  private updateParts(dt: number): void {
    for (const p of this.parts) p.update(dt);
    this.parts = this.parts.filter((p) => p.ttl > 0);
  }

  private updateCommon(dt: number, freezeEnemies: boolean): void {
    if (!freezeEnemies) return;
    // platforms & particles still animate
    for (const pl of this.plats) pl.update(dt);
    this.updateParts(dt);
    for (const [k, v] of this.bumps) {
      const nv = v - dt;
      if (nv <= 0) this.bumps.delete(k);
      else this.bumps.set(k, nv);
    }
  }

  private gameplay(dt: number): void {
    this.elapsed += dt;
    const p = this.player;

    // platforms
    for (const pl of this.plats) pl.update(dt);

    // player
    p.update(dt, this);
    if (this.state !== 'play') { this.updateParts(dt); return; } // death/level-end may trigger inside

    // collect floating coin tiles the player touches
    {
      const cx0 = Math.floor(p.left / TILE);
      const cx1 = Math.floor(p.right / TILE);
      const cy0 = Math.floor(p.top / TILE);
      const cy1 = Math.floor((p.y - 2) / TILE);
      for (let ty = cy0; ty <= cy1; ty++) {
        for (let tx = cx0; tx <= cx1; tx++) {
          if (this.tileChar(tx, ty) === 'C') {
            this.grid[ty][tx] = '.';
            this.collectCoin(tx * TILE + TILE / 2, ty * TILE + TILE / 2);
          }
        }
      }
    }

    // moving platform landing
    for (const pl of this.plats) {
      if (p.x > pl.x - 8 && p.x < pl.x + pl.w + 8 && p.y >= pl.y - 6 && p.y <= pl.y + 14 && p.vy >= 0) {
        p.y = pl.y;
        p.vy = 0;
        p.onGround = true;
        p.standingPlat = pl;
      }
    }

    // enemies
    for (const e of this.enemies) {
      if (e.remove) continue;
      e.update(dt, this);
    }
    if (this.boss && !this.boss.remove) this.boss.update(dt, this);
    if (this.bossQuote) {
      this.bossQuote.t -= dt;
      if (this.bossQuote.t <= 0) this.bossQuote = null;
    }

    // boss trigger
    const arena = this.level.boss;
    if (arena && !this.bossSpawned && p.x > arena.triggerX) this.spawnBoss();

    // items
    for (const it of this.items) {
      if (it.remove) continue;
      it.update(dt, this);
      if (!it.remove && it.riseT <= 0 && p.overlaps(it)) it.apply(this);
    }

    // coin pops
    for (const c of this.pops) c.update(dt, this);

    // shots
    for (const s of this.shots) {
      if (s.remove) continue;
      s.update(dt, this);
      if (s instanceof MagicBolt) {
        for (const e of this.enemies) {
          if (e.remove || e.squashT > 0) continue;
          if (e instanceof SnapBloom && e.out < 0.4) continue;
          if (s.overlaps(e)) {
            e.magicHit(s.dmg, this);
            s.remove = true;
            break;
          }
        }
        if (!s.remove && this.boss && !this.boss.remove && s.overlaps(this.boss)) {
          this.boss.magicHit(s.dmg, this);
          s.remove = true;
        }
      } else {
        if (!p.overlaps(s)) continue;
        if (p.starT > 0) {
          s.remove = true;
          this.burst('spark', s.x, s.y, 5, { ttl: 0.3, size: 3, color: '#ffe14d' });
          continue;
        }
        p.hurt(1, s.x, this);
        s.remove = true;
      }
    }

    // enemy ↔ player contact
    for (const e of this.enemies) {
      if (e.remove || e.squashT > 0) continue;
      if (!p.overlaps(e)) continue;
      if (e instanceof SnapBloom && e.out < 0.4) continue;
      if (p.starT > 0) {
        e.magicHit(3, this);
        continue;
      }
      if (e instanceof Shellby) {
        if (e.mode === 'shell') {
          // idle shell: kick it!
          e.kick(p.x < e.x ? 1 : -1, this);
          continue;
        }
        if (e.mode === 'slide') {
          if (e.kickCd > 0) continue;
          const aboveShell = p.vy > 100 && p.y < e.y - e.h * 0.45;
          if (aboveShell) {
            e.stopSlide(this);
            p.vy = this.keys.jump ? -700 : -480;
            p.onGround = false;
          } else {
            p.hurt(1, e.x, this);
          }
          continue;
        }
      }
      const fromAbove = p.vy > 100 && p.y < e.y - e.h * 0.45;
      if (fromAbove && e.stompable) {
        e.stomp(this);
        p.vy = this.keys.jump ? -700 : -480;
        p.onGround = false;
      } else {
        p.hurt(1, e.x, this);
        if (this.dandy === e) this.dandy.onPlayerHurt(this);
      }
    }
    // boss contact
    const b = this.boss;
    if (b && !b.remove && p.overlaps(b)) {
      if (p.starT > 0) {
        b.magicHit(2, this);
      } else {
        const fromAbove = p.vy > 100 && p.y < b.y - b.h * 0.55;
        if (fromAbove) {
          b.stomp(this);
          p.vy = this.keys.jump ? -720 : -500;
          p.onGround = false;
        } else {
          p.hurt(1, b.x, this);
        }
      }
    }

    // checkpoints / flag / gate
    for (const cp of this.checkpoints) cp.update(dt, this);
    if (this.flag) this.flag.update(dt, this);
    if (this.gate) this.gate.update(dt, this);
    if (this.state !== 'play') { this.updateParts(dt); return; }

    // camera
    const targetX = p.x - VIEW_W * 0.42 + p.facing * 46;
    this.cam.x = lerp(this.cam.x, targetX, 1 - Math.exp(-8 * dt));
    let minX = 0;
    let maxX = this.levelW * TILE - VIEW_W;
    if (this.barrierOn && arena) {
      minX = Math.max(minX, arena.left - 30);
      maxX = Math.min(maxX, arena.right + 30 - VIEW_W);
    }
    this.cam.x = clamp(this.cam.x, minX, Math.max(minX, maxX));
    const targetY = clamp(p.y - VIEW_H * 0.62, 0, this.levelH * TILE - VIEW_H);
    this.cam.y = lerp(this.cam.y, targetY, 1 - Math.exp(-8 * dt));
    this.cam.shake *= Math.exp(-6 * dt);

    // decay bumps
    for (const [k, v] of this.bumps) {
      const nv = v - dt;
      if (nv <= 0) this.bumps.delete(k);
      else this.bumps.set(k, nv);
    }
    this.updateParts(dt);

    // cleanup
    this.enemies = this.enemies.filter((e) => !e.remove);
    this.items = this.items.filter((i) => !i.remove);
    this.pops = this.pops.filter((c) => !c.remove);
    this.shots = this.shots.filter((s) => !s.remove);
  }

  // ---------------- render ----------------
  private render(): void {
    const ctx = this.ctx;
    ctx.save();
    ctx.scale(this.dpr, this.dpr);
    ctx.clearRect(0, 0, VIEW_W, VIEW_H);
    const st = this.state;
    if (st === 'menu') {
      drawMenuScene(ctx, this.t, this.sel, this.buttons, this.save.sound);
    } else if (st === 'worlds') {
      drawWorldSelect(ctx, this.t, this.sel, this.save.unlocked, this.save.best);
    } else if (st === 'howto') {
      drawHowTo(ctx, this.t, this.sel);
    } else if (st === 'settings') {
      drawSettings(ctx, this.t, this.sel, this.save);
    } else if (st === 'gameover') {
      drawGameOver(ctx, this.t, this.sel);
    } else if (st === 'victory') {
      drawVictory(ctx, this.t, this.sel, this.stats);
      this.renderParts(ctx, true);
    } else {
      this.renderWorld(ctx);
      if (st === 'pause') drawPause(ctx, this.t, this.sel);
      if (st === 'starting') drawTitleCard(ctx, this.world, this.level.name, this.titleT, this.lives);
      if (st === 'bossintro') {
        const a = clamp(this.bossIntroT / 2.2, 0, 1);
        ctx.fillStyle = `rgba(30,4,14,${0.5 * a})`;
        ctx.fillRect(0, 0, VIEW_W, VIEW_H);
        const rise = (1 - a) * 24;
        text(ctx, 'DANDY', VIEW_W / 2, 190 + rise, 66, '#ff2e4d', { stroke: '#2a0812', strokeW: 12 });
        text(ctx, 'THE VAMPIRE LORD', VIEW_W / 2, 258 + rise, 26, '#ffb0c0', { stroke: '#2a0812', strokeW: 6 });
        // bat swarm accent
        for (let i = 0; i < 6; i++) {
          const ba = this.t * 2.2 + i * 1.05;
          const bx = VIEW_W / 2 + Math.cos(ba) * (240 + (i % 3) * 55);
          const by = 140 + Math.sin(ba * 1.4) * 60 + i * 14;
          drawBgBatRef(ctx, bx, by, this.t * 3 + i);
        }
      }
      if (st === 'levelend') {
        drawLevelEnd(ctx, this.endT, this.stats, this.endDone);
      }
    }
    // fade
    if (this.fadeT > 0) {
      ctx.fillStyle = `rgba(10,4,12,${this.fadeT})`;
      ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    }
    ctx.restore();
  }

  private renderParts(ctx: CanvasRenderingContext2D, screenSpace = false): void {
    if (screenSpace) {
      for (const p of this.parts) p.draw(ctx);
      return;
    }
    ctx.save();
    ctx.translate(-Math.round(this.cam.x), -Math.round(this.cam.y));
    for (const p of this.parts) p.draw(ctx);
    ctx.restore();
  }

  private renderWorld(ctx: CanvasRenderingContext2D): void {
    const shakeX = this.cam.shake > 0.2 ? randRange(-this.cam.shake, this.cam.shake) : 0;
    const shakeY = this.cam.shake > 0.2 ? randRange(-this.cam.shake, this.cam.shake) : 0;
    const camX = Math.round(clamp(this.cam.x + shakeX, 0, this.levelW * TILE - VIEW_W));
    const camY = Math.round(clamp(this.cam.y + shakeY, 0, Math.max(0, this.levelH * TILE - VIEW_H)));
    drawBackground(ctx, this.level.theme, camX, this.t);

    ctx.save();
    ctx.translate(-camX, -camY);

    // castle behind tiles
    if (this.level.castleX > 0) {
      drawCastle(ctx, this.level.castleX + 150, 520, this.t);
    }
    // candelabra floor decor (castle realm)
    if (this.level.theme === 'castle') {
      const gx0 = Math.floor(camX / TILE) - 2;
      const gx1 = Math.floor((camX + VIEW_W) / TILE) + 2;
      for (let gx = gx0 - (gx0 % 9); gx <= gx1; gx += 9) {
        if (gx < 0) continue;
        drawCandelabra(ctx, gx * TILE + TILE, 520, this.t);
      }
    }
    // piranha plants render behind the pipes
    for (const e of this.enemies) {
      if (e instanceof SnapBloom) e.draw(ctx, this.t);
    }
    // tiles
    const tx0 = Math.max(0, Math.floor(camX / TILE) - 1);
    const tx1 = Math.min(this.levelW - 1, Math.floor((camX + VIEW_W) / TILE) + 1);
    for (let ty = 0; ty < this.levelH; ty++) {
      for (let tx = tx0; tx <= tx1; tx++) {
        const c = this.grid[ty][tx];
        if (c === '.') continue;
        const above = ty === 0 ? '.' : this.grid[ty - 1][tx];
        const grassTop = !isSolidChar(above);
        const bump = this.bumps.get(`${tx},${ty}`) ?? 0;
        const off = bump > 0 ? Math.sin((1 - bump / 0.24) * Math.PI) * 7 : 0;
        drawTile(ctx, c, tx, ty, this.level.theme, this.t, grassTop, off);
      }
    }
    // structures
    for (const cp of this.checkpoints) cp.draw(ctx, this.t);
    if (this.flag) this.flag.draw(ctx, this.t);
    if (this.gate) this.gate.draw(ctx, this.t);
    // barrier during boss
    const arena = this.level.boss;
    if (this.barrierOn && arena) {
      drawBarrier(ctx, arena.left, 0, 520, this.t);
      drawBarrier(ctx, arena.right, 0, 520, this.t);
    }
    // moving platforms
    for (const pl of this.plats) pl.draw(ctx, this.level.theme);
    // items & pops
    for (const it of this.items) it.draw(ctx, this.t);
    for (const c of this.pops) c.draw(ctx, this.t);
    // enemies
    for (const e of this.enemies) {
      if (e.remove || e instanceof SnapBloom) continue;
      e.draw(ctx, this.t);
    }
    if (this.boss && !this.boss.remove) this.boss.draw(ctx, this.t);
    // boss taunt bubble
    if (this.bossQuote && this.boss && !this.boss.remove) {
      const qbx = clamp(this.boss.x, camX + 160, camX + VIEW_W - 160);
      drawBossQuote(ctx, qbx, this.boss.top - 78, this.bossQuote.text, Math.min(1, this.bossQuote.t * 3));
    }
    // player
    if (!(this.state === 'dying' && this.player.deadT > 0.6 && this.player.y > this.levelH * TILE)) {
      this.player.draw(ctx, this);
    }
    // shots
    for (const s of this.shots) s.draw(ctx, this.t);
    ctx.restore();

    // particles (world space)
    ctx.save();
    ctx.translate(-camX, -camY);
    for (const p of this.parts) p.draw(ctx);
    ctx.restore();

    // HUD
    const prog = clamp((this.player.x - this.level.startX) / Math.max(1, this.finishX - this.level.startX), 0, 1);
    drawHUD(ctx, this.t, {
      lives: this.lives,
      hp: this.player.hp,
      maxHp: this.player.maxHp,
      coins: this.coins,
      score: this.score,
      worldLabel: `W${this.world} · ${this.level.name.toUpperCase()}`,
      progress: prog,
      bossHp: this.boss ? this.boss.hp : 0,
      bossMax: this.boss ? this.boss.maxHp : 0,
      showBoss: !!(this.bossSpawned && this.boss && !this.boss.remove && this.state !== 'starting'),
    });
  }

  destroy(): void {
    cancelAnimationFrame(this.raf);
    for (const fn of this.cleanupFns) fn();
    this.cleanupFns = [];
    this.audio.destroy();
  }
}

// tiny local helper
function chanceVs(_dt: number, p: number): boolean {
  return Math.random() < p * _dt;
}

function drawBgBatRef(ctx: CanvasRenderingContext2D, x: number, y: number, t: number): void {
  // bat silhouette accent for the boss splash
  const flap = Math.sin(t * 4);
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = 'rgba(32,8,22,0.9)';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(-7, -5 - flap * 3, -13, -2 - flap * 4);
  ctx.quadraticCurveTo(-7, 1 + flap * 2, 0, 2);
  ctx.quadraticCurveTo(7, 1 + flap * 2, 13, -2 - flap * 4);
  ctx.quadraticCurveTo(7, -5 - flap * 3, 0, 0);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawBossQuote(ctx: CanvasRenderingContext2D, x: number, y: number, quote: string, alpha: number): void {
  // dark speech bubble with crimson trim (Dandy taunts)
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.font = '700 13px Arial, sans-serif';
  const lines: string[] = [];
  let cur = '';
  for (const w of quote.split(' ')) {
    if ((cur + ' ' + w).trim().length > 34) {
      lines.push(cur.trim());
      cur = w;
    } else cur += ' ' + w;
  }
  if (cur.trim()) lines.push(cur.trim());
  const bw = Math.max(...lines.map((l) => ctx.measureText(l).width)) + 28;
  const bh = lines.length * 17 + 16;
  ctx.translate(x, y);
  ctx.fillStyle = 'rgba(20,4,14,0.92)';
  ctx.strokeStyle = '#ff4d6d';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(-bw / 2, -bh, bw, bh, 10);
  ctx.fill();
  ctx.stroke();
  // tail toward the boss
  ctx.beginPath();
  ctx.moveTo(-8, -1);
  ctx.lineTo(2, 12);
  ctx.lineTo(10, -1);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,77,109,0.6)';
  ctx.stroke();
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffd7de';
  lines.forEach((l, i) => ctx.fillText(l, 0, -bh + 26 + i * 17));
  ctx.restore();
}

