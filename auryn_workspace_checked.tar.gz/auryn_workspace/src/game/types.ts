// Core shared types & constants for Auryn's Pink Adventure
export const TILE = 40;
export const VIEW_W = 960;
export const VIEW_H = 540;
export const ROWS = 15;

export function clamp(v: number, a: number, b: number): number {
  return v < a ? a : v > b ? b : v;
}
export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}
export function randRange(a: number, b: number): number {
  return a + Math.random() * (b - a);
}
export function chance(p: number): boolean {
  return Math.random() < p;
}
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
// deterministic per-tile hash for decorations
export function hash2(x: number, y: number): number {
  let h = (x * 374761393 + y * 668265263) | 0;
  h = (h ^ (h >> 13)) * 1274126177;
  return ((h ^ (h >> 16)) >>> 0) / 4294967296;
}

export type Theme = 'hills' | 'sky' | 'forest' | 'cave' | 'castle';

export const SOLID_CHARS = 'GRSBU?MNKLTW[]{}^';
export function isSolidChar(c: string): boolean {
  return SOLID_CHARS.includes(c);
}

export type BlockLoot = 'coin' | 'mushroom' | 'star' | 'crystal' | 'heart';
export const MYSTERY: Record<string, BlockLoot> = {
  '?': 'coin',
  M: 'mushroom',
  N: 'star',
  K: 'crystal',
  L: 'heart',
};

export interface PipeWarp {
  tx: number; // pipe top-left tile x
  ty: number; // pipe top tile y
  destX: number; // px, player feet x after warp
  destY: number; // px, player feet y after warp
}

export interface MovingPlatformDef {
  x: number; // px
  y: number; // px (top surface)
  w: number; // px
  dx: number;
  dy: number;
  range: number; // px travel
  speed: number; // px/s
}

export interface BossArenaDef {
  triggerX: number;
  left: number;
  right: number;
  gateX: number;
  gateY: number;
  bossX: number;
}

export interface LevelDef {
  world: number;
  name: string;
  theme: Theme;
  rows: string[];
  startX: number;
  startY: number; // feet y in px
  pipes: PipeWarp[];
  platforms: MovingPlatformDef[];
  castleX: number; // px position of finish castle (0 = none)
  boss?: BossArenaDef;
}

export interface SaveData {
  unlocked: number; // highest world available (1..5)
  best: number[]; // best score per world
  sound: boolean;
  music: boolean;
}

export type InputKey =
  | 'left'
  | 'right'
  | 'up'
  | 'down'
  | 'jump'
  | 'attack'
  | 'pause'
  | 'confirm';

export type InputMap = Record<InputKey, boolean>;

export function emptyInput(): InputMap {
  return {
    left: false,
    right: false,
    up: false,
    down: false,
    jump: false,
    attack: false,
    pause: false,
    confirm: false,
  };
}
