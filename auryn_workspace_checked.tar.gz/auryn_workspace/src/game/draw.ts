// World rendering: parallax backgrounds, tiles, items, structures
import { Theme, TILE, VIEW_H, VIEW_W, hash2, mulberry32 } from './types';

type Ctx = CanvasRenderingContext2D;

export interface ThemePal {
  sky0: string; sky1: string;
  grass: string; grassDark: string; grassEdge: string;
  dirt: string; dirtDark: string;
  hill1: string; hill2: string;
  stone: string; stoneDark: string;
}

export const PALS: Record<Theme, ThemePal> = {
  hills: { sky0: '#79c7f2', sky1: '#d6f3ff', grass: '#5fbe4c', grassDark: '#3f9636', grassEdge: '#8ade6f', dirt: '#a5673f', dirtDark: '#87512e', hill1: '#93d47c', hill2: '#6dbb5a', stone: '#9aa0a6', stoneDark: '#7c8288' },
  sky: { sky0: '#5fb2ee', sky1: '#c9ecff', grass: '#63cf97', grassDark: '#41a975', grassEdge: '#93e8bb', dirt: '#a87047', dirtDark: '#8a5939', hill1: '#ffffff', hill2: '#e8fbff', stone: '#b9c7d6', stoneDark: '#98a7b8' },
  forest: { sky0: '#6fbfa0', sky1: '#e3f6c8', grass: '#4db054', grassDark: '#34893e', grassEdge: '#7fd877', dirt: '#7d5537', dirtDark: '#654327', hill1: '#3f9e54', hill2: '#2f7d43', stone: '#8a9b7a', stoneDark: '#6d7d5f' },
  cave: { sky0: '#221a3c', sky1: '#453263', grass: '#8a80b8', grassDark: '#6a6196', grassEdge: '#a9a0d4', dirt: '#4e4670', dirtDark: '#3b3556', hill1: '#332a54', hill2: '#271f42', stone: '#6d6494', stoneDark: '#544c78' },
  castle: { sky0: '#5d3f8f', sky1: '#f5aec6', grass: '#8f99ad', grassDark: '#6f798d', grassEdge: '#b4bdcc', dirt: '#565f73', dirtDark: '#454d5e', hill1: '#4a3364', hill2: '#3a2752', stone: '#9aa3b8', stoneDark: '#7d879c' },
};

export function rr(ctx: Ctx, x: number, y: number, w: number, h: number, r: number): void {
  const rad = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rad, y);
  ctx.arcTo(x + w, y, x + w, y + h, rad);
  ctx.arcTo(x + w, y + h, x, y + h, rad);
  ctx.arcTo(x, y + h, x, y, rad);
  ctx.arcTo(x, y, x + w, y, rad);
  ctx.closePath();
}

export function text(
  ctx: Ctx, s: string, x: number, y: number, size: number, color: string,
  opts?: { align?: CanvasTextAlign; stroke?: string; strokeW?: number; weight?: number; italic?: boolean }
): void {
  const w = opts?.weight ?? 900;
  ctx.save();
  ctx.font = `${opts?.italic ? 'italic ' : ''}${w} ${size}px "Arial Black", Arial, sans-serif`;
  ctx.textAlign = opts?.align ?? 'center';
  ctx.textBaseline = 'middle';
  if (opts?.stroke) {
    ctx.lineWidth = opts.strokeW ?? Math.max(2, size * 0.14);
    ctx.strokeStyle = opts.stroke;
    ctx.lineJoin = 'round';
    ctx.strokeText(s, x, y);
  }
  ctx.fillStyle = color;
  ctx.fillText(s, x, y);
  ctx.restore();
}

// ---------- background scenery (deterministic) ----------
interface Cloud { x: number; y: number; s: number; sp: number }
let bgCache: Record<string, { clouds: Cloud[]; hill: number[]; tree: number[] }> = {};

function getBg(theme: Theme) {
  if (!bgCache[theme]) {
    const rng = mulberry32(theme.length * 9173 + 77);
    const clouds: Cloud[] = [];
    for (let i = 0; i < 9; i++) clouds.push({ x: rng() * 2400, y: 30 + rng() * 170, s: 0.6 + rng() * 0.9, sp: 6 + rng() * 10 });
    const hill: number[] = [];
    for (let i = 0; i < 14; i++) hill.push(rng());
    const tree: number[] = [];
    for (let i = 0; i < 18; i++) tree.push(rng());
    bgCache[theme] = { clouds, hill, tree };
  }
  return bgCache[theme];
}

function drawCloud(ctx: Ctx, x: number, y: number, s: number): void {
  ctx.fillStyle = 'rgba(255,255,255,0.95)';
  ctx.beginPath();
  ctx.arc(x, y, 20 * s, 0, Math.PI * 2);
  ctx.arc(x + 22 * s, y - 8 * s, 24 * s, 0, Math.PI * 2);
  ctx.arc(x + 46 * s, y, 18 * s, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(214,236,255,0.9)';
  ctx.beginPath();
  ctx.arc(x + 20 * s, y + 10 * s, 16 * s, 0, Math.PI * 2);
  ctx.fill();
}

function drawTree(ctx: Ctx, x: number, gy: number, s: number, dark: boolean): void {
  const c1 = dark ? '#2f7d43' : '#3f9e54';
  const c2 = dark ? '#256a35' : '#2f7d43';
  ctx.fillStyle = '#6b4b34';
  ctx.fillRect(x - 5 * s, gy - 60 * s, 10 * s, 60 * s);
  ctx.fillStyle = c1;
  ctx.beginPath();
  ctx.arc(x, gy - 72 * s, 26 * s, 0, Math.PI * 2);
  ctx.arc(x - 20 * s, gy - 58 * s, 18 * s, 0, Math.PI * 2);
  ctx.arc(x + 20 * s, gy - 58 * s, 18 * s, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = c2;
  ctx.beginPath();
  ctx.arc(x + 10 * s, gy - 66 * s, 12 * s, 0, Math.PI * 2);
  ctx.fill();
}

function drawHill(ctx: Ctx, x: number, gy: number, w: number, h: number, color: string): void {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x - w / 2, gy);
  ctx.quadraticCurveTo(x, gy - h * 2, x + w / 2, gy);
  ctx.closePath();
  ctx.fill();
}

function drawBgCrystals(ctx: Ctx, x: number, gy: number, s: number, alpha: number): void {
  ctx.save();
  ctx.globalAlpha = alpha;
  const cols = ['#b26bf0', '#ff6bd5', '#59d7ff'];
  for (let i = 0; i < 3; i++) {
    const c = cols[i % 3];
    const xx = x + (i - 1) * 14 * s;
    const hh = (18 + ((i * 13) % 12)) * s;
    ctx.fillStyle = c;
    ctx.beginPath();
    ctx.moveTo(xx, gy);
    ctx.lineTo(xx - 6 * s, gy - hh * 0.45);
    ctx.lineTo(xx, gy - hh);
    ctx.lineTo(xx + 6 * s, gy - hh * 0.45);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

function drawCastleSil(ctx: Ctx, x: number, gy: number, s: number, color: string): void {
  ctx.fillStyle = color;
  ctx.fillRect(x - 60 * s, gy - 90 * s, 120 * s, 90 * s);
  ctx.fillRect(x - 90 * s, gy - 55 * s, 30 * s, 55 * s);
  ctx.fillRect(x + 60 * s, gy - 55 * s, 30 * s, 55 * s);
  ctx.beginPath();
  ctx.moveTo(x - 60 * s, gy - 90 * s);
  ctx.lineTo(x, gy - 135 * s);
  ctx.lineTo(x + 60 * s, gy - 90 * s);
  ctx.closePath();
  ctx.fill();
}

export function drawBackground(ctx: Ctx, theme: Theme, camX: number, t: number): void {
  const pal = PALS[theme];
  const grad = ctx.createLinearGradient(0, 0, 0, VIEW_H);
  grad.addColorStop(0, pal.sky0);
  grad.addColorStop(1, pal.sky1);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  const bg = getBg(theme);

  if (theme === 'cave') {
    // glowing background crystals
    for (let i = 0; i < bg.hill.length; i++) {
      const x = ((i * 260 + bg.hill[i] * 160 - camX * 0.25) % (VIEW_W + 300)) - 150;
      drawBgCrystals(ctx, x, VIEW_H - 40 - bg.hill[i] * 120, 1.6 + bg.hill[i], 0.35);
    }
    ctx.fillStyle = pal.hill1;
    ctx.beginPath();
    ctx.moveTo(0, VIEW_H);
    for (let x = 0; x <= VIEW_W; x += 20) {
      const y = VIEW_H - 90 - Math.sin((x + camX * 0.3) * 0.01) * 34 - Math.cos((x + camX * 0.3) * 0.023) * 22;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(VIEW_W, VIEW_H);
    ctx.closePath();
    ctx.fill();
    return;
  }

  // sun / moon
  if (theme === 'castle') {
    // BLOOD MOON — Dandy's castle realm (per reference screenshot)
    const mx = VIEW_W - 170;
    const my = 108;
    const mr = 82;
    const glow = ctx.createRadialGradient(mx, my, mr * 0.4, mx, my, mr * 2.1);
    glow.addColorStop(0, 'rgba(255,46,77,0.5)');
    glow.addColorStop(0.55, 'rgba(214,40,80,0.2)');
    glow.addColorStop(1, 'rgba(214,40,80,0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(mx, my, mr * 2.1, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ff5a72';
    ctx.beginPath();
    ctx.arc(mx, my, mr, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#e63a58';
    ctx.beginPath();
    ctx.arc(mx + mr * 0.16, my + mr * 0.1, mr * 0.94, 0, Math.PI * 2);
    ctx.fill();
    // craters
    ctx.fillStyle = 'rgba(180,30,58,0.55)';
    ctx.beginPath();
    ctx.arc(mx - 26, my - 22, 13, 0, Math.PI * 2);
    ctx.arc(mx + 20, my + 14, 17, 0, Math.PI * 2);
    ctx.arc(mx - 8, my + 38, 9, 0, Math.PI * 2);
    ctx.arc(mx + 38, my - 30, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,150,165,0.4)';
    ctx.beginPath();
    ctx.arc(mx - 30, my - 26, 5, 0, Math.PI * 2);
    ctx.arc(mx + 14, my + 8, 6, 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.fillStyle = theme === 'forest' ? 'rgba(255,250,205,0.95)' : 'rgba(255,244,180,0.95)';
    ctx.beginPath();
    ctx.arc(120, 86, 40, 0, Math.PI * 2);
    ctx.fill();
  }

  // clouds (slow drift + parallax)
  if (theme !== 'forest') {
    for (const c of bg.clouds) {
      const x = ((c.x + t * c.sp - camX * 0.2) % (VIEW_W + 340)) - 170;
      drawCloud(ctx, x, c.y, c.s);
    }
  } else {
    // forest haze
    for (const c of bg.clouds) {
      const x = ((c.x + t * c.sp * 0.4 - camX * 0.15) % (VIEW_W + 340)) - 170;
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.beginPath();
      ctx.ellipse(x, c.y + 40, 60 * c.s, 14 * c.s, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  if (theme === 'sky') {
    // far floating isles
    for (let i = 0; i < 5; i++) {
      const x = ((i * 480 + bg.hill[i] * 200 - camX * 0.3) % (VIEW_W + 500)) - 250;
      const y = 150 + bg.hill[i] * 120;
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.beginPath();
      ctx.ellipse(x, y, 70, 18, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      ctx.beginPath();
      ctx.moveTo(x - 50, y + 8);
      ctx.quadraticCurveTo(x, y + 40, x + 50, y + 8);
      ctx.fill();
    }
  }

  if (theme === 'castle') {
    for (let i = 0; i < 4; i++) {
      const x = ((i * 640 + bg.hill[i] * 240 - camX * 0.28) % (VIEW_W + 700)) - 350;
      drawCastleSil(ctx, x, VIEW_H - 60, 0.8 + bg.hill[i] * 0.4, i % 2 ? '#3a2752' : '#4a3364');
    }
    // bats circling the blood moon
    for (let i = 0; i < 7; i++) {
      const bx = ((i * 260 + t * (26 + (i % 3) * 16) - camX * 0.35) % (VIEW_W + 300) + (VIEW_W + 300)) % (VIEW_W + 300) - 150;
      const by = 52 + ((i * 53) % 168) + Math.sin(t * 1.8 + i * 2.2) * 16;
      drawBgBat(ctx, bx, by, t * 3 + i, 0.55 + (i % 3) * 0.3);
    }
  }

  // far hills layer
  if (theme === 'hills' || theme === 'forest' || theme === 'sky') {
    for (let i = 0; i < 8; i++) {
      const x = i * 300 + bg.hill[i] * 120 - camX * 0.35;
      drawHill(ctx, ((x % 2600) + 2600) % 2600 - 300, VIEW_H - 70, 380, 90 + bg.hill[i] * 50, pal.hill2);
    }
  }
  // near hills / trunks
  for (let i = 0; i < 7; i++) {
    const x = i * 340 + bg.hill[i + 4] * 160 - camX * 0.55;
    const xx = ((x % 2500) + 2500) % 2500 - 250;
    if (theme === 'forest') {
      drawTree(ctx, xx, VIEW_H - 60, 1.2 + bg.tree[i] * 0.8, true);
    } else if (theme !== 'castle') {
      drawHill(ctx, xx, VIEW_H - 40, 420, 120 + bg.tree[i] * 60, pal.hill1);
    }
  }
  if (theme === 'forest') {
    for (let i = 0; i < 7; i++) {
      const x = i * 340 + bg.tree[i] * 160 - camX * 0.75;
      const xx = ((x % 2500) + 2500) % 2500 - 250;
      drawTree(ctx, xx, VIEW_H - 34, 1.5 + bg.hill[i] * 0.7, false);
    }
    // fireflies
    for (let i = 0; i < 14; i++) {
      const fx = ((bg.tree[i] * 3000 + Math.sin(t * 0.8 + i) * 60 - camX * 0.85) % (VIEW_W + 200)) - 100;
      const fy = 200 + bg.hill[i] * 200 + Math.cos(t * 1.3 + i * 2) * 30;
      ctx.fillStyle = `rgba(255, 214, 130, ${0.4 + 0.4 * Math.sin(t * 3 + i)})`;
      ctx.beginPath();
      ctx.arc(fx, fy, 2.4, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

// ---------- tiles ----------
export function drawTile(ctx: Ctx, c: string, gx: number, gy: number, theme: Theme, t: number, grassTop: boolean, bump: number): void {
  const pal = PALS[theme];
  const x = gx * TILE;
  const y = gy * TILE - bump;
  const h = hash2(gx, gy);
  switch (c) {
    case 'G': {
      ctx.fillStyle = pal.dirt;
      ctx.fillRect(x, y, TILE, TILE);
      ctx.fillStyle = pal.dirtDark;
      for (let i = 0; i < 3; i++) {
        const hx = hash2(gx * 3 + i, gy);
        ctx.beginPath();
        ctx.arc(x + 8 + hx * 24, y + 14 + hash2(gx, gy + i) * 22, 2.4, 0, Math.PI * 2);
        ctx.fill();
      }
      if (grassTop) {
        ctx.fillStyle = pal.grass;
        rr(ctx, x - 0.5, y - 3, TILE + 1, 16, 5);
        ctx.fill();
        ctx.fillStyle = pal.grassEdge;
        rr(ctx, x - 0.5, y - 3, TILE + 1, 7, 4);
        ctx.fill();
        ctx.fillStyle = pal.grass;
        for (let i = 0; i < 3; i++) {
          const bx = x + 6 + i * 13 + h * 4;
          ctx.beginPath();
          ctx.arc(bx, y - 3, 3, Math.PI, 0);
          ctx.fill();
        }
      }
      break;
    }
    case 'R': {
      ctx.fillStyle = pal.dirtDark;
      ctx.fillRect(x, y, TILE, TILE);
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      if (h > 0.4) ctx.fillRect(x + 6 + h * 18, y + 8 + h * 14, 6, 4);
      if (h < 0.5) ctx.fillRect(x + 22 - h * 14, y + 24, 7, 4);
      break;
    }
    case 'S': {
      ctx.fillStyle = pal.stone;
      ctx.fillRect(x, y, TILE, TILE);
      ctx.strokeStyle = pal.stoneDark;
      ctx.lineWidth = 2;
      ctx.strokeRect(x + 2, y + 2, TILE - 4, TILE - 4);
      ctx.fillStyle = 'rgba(255,255,255,0.18)';
      ctx.fillRect(x + 3, y + 3, TILE - 6, 4);
      break;
    }
    case 'B': {
      ctx.fillStyle = theme === 'castle' ? '#8c5a66' : '#c9803f';
      ctx.fillRect(x, y, TILE, TILE);
      ctx.strokeStyle = 'rgba(60,30,10,0.5)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x, y + 20); ctx.lineTo(x + TILE, y + 20);
      ctx.moveTo(x + 20, y); ctx.lineTo(x + 20, y + 20);
      ctx.moveTo(x + 10, y + 20); ctx.lineTo(x + 10, y + TILE);
      ctx.moveTo(x + 30, y + 20); ctx.lineTo(x + 30, y + TILE);
      ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.15)';
      ctx.fillRect(x, y, TILE, 3);
      break;
    }
    case 'U': {
      ctx.fillStyle = '#8d7450';
      ctx.fillRect(x, y, TILE, TILE);
      ctx.strokeStyle = '#6b5638';
      ctx.lineWidth = 2;
      ctx.strokeRect(x + 2, y + 2, TILE - 4, TILE - 4);
      for (const [rx, ry] of [[7, 7], [33, 7], [7, 33], [33, 33]]) {
        ctx.fillStyle = '#6b5638';
        ctx.beginPath();
        ctx.arc(x + rx, y + ry, 2, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    }
    case '?': case 'M': case 'N': case 'K': case 'L': {
      const pulse = 0.5 + 0.5 * Math.sin(t * 4 + gx);
      ctx.fillStyle = '#f4b942';
      rr(ctx, x + 1, y + 1, TILE - 2, TILE - 2, 6);
      ctx.fill();
      ctx.fillStyle = '#ffd97a';
      rr(ctx, x + 4, y + 4, TILE - 8, TILE - 8, 5);
      ctx.fill();
      ctx.fillStyle = '#b57e14';
      for (const [rx, ry] of [[8, 8], [32, 8], [8, 32], [32, 32]]) {
        ctx.beginPath();
        ctx.arc(x + rx, y + ry, 2.2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.save();
      ctx.globalAlpha = 0.85 + pulse * 0.15;
      const cxp = x + 20, cyp = y + 21;
      if (c === '?') {
        text(ctx, '?', cxp, cyp - 1, 22, '#8a5a00', { stroke: '#5d3a00', strokeW: 4, weight: 900 });
      } else if (c === 'M') {
        ctx.fillStyle = '#ff7fbf';
        ctx.beginPath(); ctx.arc(cxp, cyp - 2, 7, Math.PI, 0); ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(cxp - 3, cyp - 5, 1.6, 0, 7); ctx.fill();
        ctx.fillRect(cxp - 2.5, cyp - 2, 5, 6);
      } else if (c === 'N') {
        star(ctx, cxp, cyp, 8, 4.2, 5, '#fff200', '#c79100', 0);
      } else if (c === 'K') {
        gem(ctx, cxp, cyp, 7, '#ff7ad9', '#c13d9d');
      } else {
        heart(ctx, cxp, cyp, 8, '#ff5f9e', '#b02d62');
      }
      ctx.restore();
      break;
    }
    case 'T': {
      if (theme === 'sky') {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(x + 10, y + 26, 14, 0, Math.PI * 2);
        ctx.arc(x + 24, y + 20, 17, 0, Math.PI * 2);
        ctx.arc(x + 34, y + 27, 12, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#d6f0ff';
        ctx.beginPath();
        ctx.ellipse(x + 20, y + 34, 18, 6, 0, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.fillStyle = theme === 'cave' || theme === 'castle' ? PALS[theme].stone : '#8a5a34';
        ctx.fillRect(x + 1, y + 12, TILE - 2, 26);
        ctx.fillStyle = 'rgba(0,0,0,0.18)';
        ctx.fillRect(x + 1, y + 30, TILE - 2, 8);
        ctx.fillStyle = theme === 'cave' || theme === 'castle' ? PALS[theme].grassEdge : pal.grass;
        rr(ctx, x - 1, y + 4, TILE + 2, 14, 5);
        ctx.fill();
        ctx.fillStyle = theme === 'forest' ? '#7fd877' : pal.grassEdge;
        rr(ctx, x - 1, y + 4, TILE + 2, 6, 4);
        ctx.fill();
      }
      break;
    }
    case 'W': {
      ctx.fillStyle = '#a8712f';
      ctx.fillRect(x, y + 8, TILE, 16);
      ctx.strokeStyle = '#7c4d1c';
      ctx.lineWidth = 2;
      ctx.strokeRect(x + 1, y + 9, TILE - 2, 14);
      ctx.fillStyle = '#7c4d1c';
      ctx.beginPath();
      ctx.arc(x + 4, y + 16, 2.5, 0, Math.PI * 2);
      ctx.arc(x + TILE - 4, y + 16, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.2)';
      ctx.fillRect(x + 2, y + 10, TILE - 4, 3);
      break;
    }
    case '[': case ']': {
      const left = c === '[';
      ctx.fillStyle = '#2f9e3e';
      ctx.fillRect(x, y + 4, TILE, TILE - 4);
      ctx.fillStyle = '#3dbb4f';
      ctx.fillRect(x, y, TILE, 10);
      ctx.fillStyle = '#7fe38a';
      if (left) ctx.fillRect(x + 4, y + 4, 6, TILE - 4);
      ctx.fillStyle = '#1f7a2c';
      if (left) ctx.fillRect(x, y, 3, TILE);
      else ctx.fillRect(x + TILE - 3, y, 3, TILE);
      ctx.fillStyle = 'rgba(0,0,0,0.15)';
      ctx.fillRect(x, y + 12, TILE, 2);
      break;
    }
    case '{': case '}': {
      const left = c === '{';
      ctx.fillStyle = '#3dbb4f';
      ctx.fillRect(x + (left ? 2 : 0), y, TILE - 2, TILE);
      ctx.fillStyle = '#7fe38a';
      if (left) ctx.fillRect(x + 6, y, 6, TILE);
      ctx.fillStyle = '#1f7a2c';
      if (left) ctx.fillRect(x + 2, y, 3, TILE);
      else ctx.fillRect(x + TILE - 5, y, 3, TILE);
      break;
    }
    case '^': {
      ctx.fillStyle = '#4a4f5a';
      ctx.fillRect(x, y + 30, TILE, 10);
      ctx.fillStyle = '#c3cad6';
      for (let i = 0; i < 2; i++) {
        ctx.beginPath();
        ctx.moveTo(x + 2 + i * 20, y + 32);
        ctx.lineTo(x + 10 + i * 20, y + 8);
        ctx.lineTo(x + 18 + i * 20, y + 32);
        ctx.closePath();
        ctx.fill();
      }
      ctx.fillStyle = '#8a93a3';
      for (let i = 0; i < 2; i++) {
        ctx.beginPath();
        ctx.moveTo(x + 10 + i * 20, y + 10);
        ctx.lineTo(x + 14 + i * 20, y + 32);
        ctx.lineTo(x + 10 + i * 20, y + 32);
        ctx.closePath();
        ctx.fill();
      }
      break;
    }
    case 'C': {
      drawCoin(ctx, x + TILE / 2, y + TILE / 2, t + gx * 0.35, 1);
      break;
    }
    case 'i': {
      const glow = 0.5 + 0.5 * Math.sin(t * 2.4 + gx * 1.7);
      ctx.save();
      ctx.globalAlpha = 0.25 + glow * 0.25;
      ctx.fillStyle = '#d98bff';
      ctx.beginPath();
      ctx.arc(x + 20, y + 24, 20, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      const hanging = hash2(gx, 7) > 0.5;
      drawBgCrystals(ctx, x + 20, hanging ? y + 6 : y + 34, 1.1, 0.9);
      break;
    }
    case 'm': {
      const glow = theme === 'forest' || theme === 'cave';
      if (glow) {
        ctx.save();
        ctx.globalAlpha = 0.2 + 0.2 * Math.sin(t * 2 + gx);
        ctx.fillStyle = '#ff9ad5';
        ctx.beginPath();
        ctx.arc(x + 20, y + 22, 17, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
      ctx.fillStyle = '#fff3e0';
      ctx.fillRect(x + 15, y + 22, 10, 14);
      ctx.fillStyle = glow ? '#ff7ac8' : '#ff5f6d';
      ctx.beginPath();
      ctx.arc(x + 20, y + 24, 13, Math.PI, 0);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      ctx.beginPath();
      ctx.arc(x + 14, y + 20, 2.6, 0, Math.PI * 2);
      ctx.arc(x + 26, y + 18, 2.2, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case 'v': {
      const col = ['#ff8fc7', '#ffd23f', '#ffffff'][Math.floor(h * 3) % 3];
      ctx.strokeStyle = '#3f9636';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x + 20, y + 36);
      ctx.quadraticCurveTo(x + 18, y + 26, x + 20, y + 20);
      ctx.stroke();
      ctx.fillStyle = col;
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.ellipse(x + 20 + Math.cos((i / 5) * Math.PI * 2) * 5, y + 16 + Math.sin((i / 5) * Math.PI * 2) * 5, 3.4, 3.4, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = '#ffde59';
      ctx.beginPath();
      ctx.arc(x + 20, y + 16, 3, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
  }
}

// ---------- item / shape primitives ----------
export function star(ctx: Ctx, cx: number, cy: number, outer: number, inner: number, points: number, fill: string, stroke: string, rot: number): void {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  ctx.beginPath();
  for (let i = 0; i < points * 2; i++) {
    const r = i % 2 === 0 ? outer : inner;
    const a = (i / (points * 2)) * Math.PI * 2 - Math.PI / 2;
    if (i === 0) ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
    else ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
  }
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.stroke();
  }
  ctx.restore();
}

export function heart(ctx: Ctx, cx: number, cy: number, s: number, fill: string, stroke: string): void {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(s / 10, s / 10);
  ctx.beginPath();
  ctx.moveTo(0, 3);
  ctx.bezierCurveTo(-10, -6, -5, -12, 0, -6);
  ctx.bezierCurveTo(5, -12, 10, -6, 0, 3);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = 2.4;
    ctx.stroke();
  }
  ctx.restore();
}

export function gem(ctx: Ctx, cx: number, cy: number, s: number, fill: string, stroke: string): void {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(s / 10, s / 10);
  ctx.beginPath();
  ctx.moveTo(0, -10);
  ctx.lineTo(8, -3);
  ctx.lineTo(0, 10);
  ctx.lineTo(-8, -3);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  ctx.strokeStyle = stroke;
  ctx.lineWidth = 2.4;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-3, -6);
  ctx.lineTo(0, 2);
  ctx.lineTo(3, -6);
  ctx.strokeStyle = 'rgba(255,255,255,0.85)';
  ctx.lineWidth = 1.6;
  ctx.stroke();
  ctx.restore();
}

export function drawCoin(ctx: Ctx, cx: number, cy: number, t: number, scale: number): void {
  const sq = Math.abs(Math.cos(t * 5));
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(Math.max(0.18, sq), 1);
  ctx.scale(scale, scale);
  ctx.beginPath();
  ctx.arc(0, 0, 11, 0, Math.PI * 2);
  ctx.fillStyle = '#ffd23f';
  ctx.fill();
  ctx.strokeStyle = '#e09a1f';
  ctx.lineWidth = 2.5;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, 6.5, 0, Math.PI * 2);
  ctx.strokeStyle = '#e09a1f';
  ctx.lineWidth = 1.8;
  ctx.stroke();
  ctx.restore();
}

// pickup items
export function drawPickup(ctx: Ctx, kind: string, cx: number, cy: number, t: number): void {
  const bob = Math.sin(t * 3.4) * 2.5;
  ctx.save();
  ctx.translate(cx, cy + bob);
  if (kind === 'mushroom') {
    ctx.fillStyle = '#fff3e0';
    rr(ctx, -6, -2, 12, 12, 3);
    ctx.fill();
    ctx.strokeStyle = '#c9a97e';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = '#ff7fbf';
    ctx.beginPath();
    ctx.arc(0, -2, 11, Math.PI, 0);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#c13d9d';
    ctx.stroke();
    ctx.fillStyle = '#fff';
    star(ctx, -4, -7, 2.6, 1.3, 5, '#fff', '', 0);
    star(ctx, 4, -5, 2.2, 1.1, 5, '#fff', '', 0);
    ctx.fillStyle = '#5a3a4a';
    ctx.beginPath();
    ctx.arc(-2.5, 3, 1.2, 0, 7);
    ctx.arc(2.5, 3, 1.2, 0, 7);
    ctx.fill();
  } else if (kind === 'star') {
    ctx.rotate(Math.sin(t * 2) * 0.3);
    star(ctx, 0, 0, 13, 6, 5, '#ffe14d', '#d99a00', 0);
    ctx.fillStyle = '#7a5200';
    ctx.beginPath();
    ctx.arc(-3, -1, 1.3, 0, 7);
    ctx.arc(3, -1, 1.3, 0, 7);
    ctx.fill();
  } else if (kind === 'crystal') {
    const glow = 0.5 + 0.5 * Math.sin(t * 4);
    ctx.save();
    ctx.globalAlpha = 0.3 + glow * 0.3;
    ctx.fillStyle = '#ff7ad9';
    ctx.beginPath();
    ctx.arc(0, 0, 16, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    gem(ctx, 0, 0, 13, '#ff7ad9', '#c13d9d');
  } else if (kind === 'heart') {
    const pulse = 1 + 0.1 * Math.sin(t * 6);
    ctx.scale(pulse, pulse);
    heart(ctx, 0, 0, 13, '#ff5f9e', '#b02d62');
  }
  ctx.restore();
}

// ---------- structures ----------
export function drawCheckpoint(ctx: Ctx, x: number, baseY: number, active: boolean, t: number): void {
  ctx.fillStyle = '#7c7f8a';
  ctx.fillRect(x - 2.5, baseY - 96, 5, 96);
  ctx.fillStyle = '#5d6068';
  ctx.beginPath();
  ctx.arc(x, baseY - 98, 5, 0, Math.PI * 2);
  ctx.fill();
  const wave = Math.sin(t * 6) * 3;
  ctx.fillStyle = active ? '#ff5fa8' : '#b9bdc9';
  ctx.beginPath();
  ctx.moveTo(x + 2.5, baseY - 92);
  ctx.quadraticCurveTo(x + 22, baseY - 88 + wave, x + 34, baseY - 78 + wave);
  ctx.lineTo(x + 2.5, baseY - 62);
  ctx.closePath();
  ctx.fill();
  if (active) heart(ctx, x + 15, baseY - 78 + wave * 0.4, 6.5, '#fff', '');
  ctx.fillStyle = '#8d939f';
  ctx.fillRect(x - 10, baseY - 6, 20, 6);
}

export function drawFlagpole(ctx: Ctx, x: number, baseY: number, t: number): void {
  ctx.fillStyle = '#e8e9ee';
  ctx.fillRect(x - 3, baseY - 260, 6, 260);
  ctx.fillStyle = '#b9bdc9';
  ctx.fillRect(x + 1, baseY - 260, 2, 260);
  ctx.fillStyle = '#ffd23f';
  ctx.beginPath();
  ctx.arc(x, baseY - 266, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#c79100';
  ctx.lineWidth = 2;
  ctx.stroke();
  const wave = Math.sin(t * 4) * 4;
  ctx.fillStyle = '#ff5fa8';
  ctx.beginPath();
  ctx.moveTo(x + 3, baseY - 252);
  ctx.quadraticCurveTo(x + 34, baseY - 244 + wave, x + 48, baseY - 228 + wave);
  ctx.lineTo(x + 3, baseY - 208);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = '#c13d9d';
  ctx.lineWidth = 2;
  ctx.stroke();
  star(ctx, x + 20, baseY - 232 + wave * 0.4, 7, 3.4, 5, '#fff', '', 0);
  ctx.fillStyle = '#8d939f';
  rr(ctx, x - 14, baseY - 8, 28, 8, 3);
  ctx.fill();
}

export function drawCastle(ctx: Ctx, x: number, baseY: number, t: number): void {
  const w = 300;
  ctx.save();
  ctx.translate(x, baseY);
  // main keep
  ctx.fillStyle = '#e3b8cc';
  ctx.fillRect(-w / 2, -170, w, 170);
  ctx.fillStyle = '#c995b4';
  ctx.fillRect(-w / 2, -170, w, 16);
  // towers
  for (const tx of [-w / 2 - 20, w / 2 - 50]) {
    ctx.fillStyle = '#eec7d9';
    ctx.fillRect(tx, -230, 70, 230);
    ctx.fillStyle = '#ff8fc7';
    ctx.beginPath();
    ctx.moveTo(tx - 10, -230);
    ctx.lineTo(tx + 35, -286);
    ctx.lineTo(tx + 80, -230);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#5a3a4a';
    ctx.fillRect(tx + 22, -200, 26, 30);
    // banner
    const wave = Math.sin(t * 3 + tx) * 3;
    ctx.fillStyle = '#ff5fa8';
    ctx.beginPath();
    ctx.moveTo(tx + 35, -286);
    ctx.lineTo(tx + 35, -314);
    ctx.lineTo(tx + 35 + 22 + wave, -306);
    ctx.lineTo(tx + 35, -298);
    ctx.closePath();
    ctx.fill();
  }
  // central tower
  ctx.fillStyle = '#f6d7e4';
  ctx.fillRect(-52, -280, 104, 120);
  ctx.fillStyle = '#ff8fc7';
  ctx.beginPath();
  ctx.moveTo(-64, -280);
  ctx.lineTo(0, -342);
  ctx.lineTo(64, -280);
  ctx.closePath();
  ctx.fill();
  heart(ctx, 0, -300, 10, '#ff5fa8', '#c13d9d');
  // door
  ctx.fillStyle = '#6b3a56';
  rr(ctx, -34, -74, 68, 74, 30);
  ctx.fill();
  ctx.fillStyle = '#8d4f71';
  rr(ctx, -26, -66, 52, 66, 24);
  ctx.fill();
  heart(ctx, 0, -34, 8, '#ffb3d9', '');
  // windows
  ctx.fillStyle = '#6b3a56';
  for (const wx of [-110, 110]) {
    rr(ctx, wx - 10, -140, 20, 30, 10);
    ctx.fill();
  }
  ctx.restore();
}

export function drawGate(ctx: Ctx, x: number, baseY: number, open: boolean, t: number): void {
  ctx.save();
  ctx.translate(x, baseY);
  ctx.fillStyle = '#c9a13f';
  ctx.fillRect(-52, -150, 104, 150);
  ctx.fillStyle = '#e3c565';
  ctx.fillRect(-46, -144, 92, 144);
  if (open) {
    const glow = 0.5 + 0.5 * Math.sin(t * 3);
    ctx.save();
    ctx.globalAlpha = 0.5 + glow * 0.3;
    const g = ctx.createLinearGradient(0, -144, 0, 0);
    g.addColorStop(0, '#ffe9a8');
    g.addColorStop(1, '#ff9ad5');
    ctx.fillStyle = g;
    ctx.fillRect(-40, -138, 80, 138);
    ctx.restore();
    for (let i = 0; i < 5; i++) {
      const yy = -130 + ((t * 90 + i * 30) % 140);
      star(ctx, -20 + i * 10, yy, 4, 2, 5, '#fff', '', t + i);
    }
  } else {
    ctx.strokeStyle = '#8a6a1d';
    ctx.lineWidth = 5;
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(-32 + i * 21, -138);
      ctx.lineTo(-32 + i * 21, 0);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.moveTo(-40, -70);
    ctx.lineTo(40, -70);
    ctx.stroke();
    heart(ctx, 0, -100, 9, '#ff5fa8', '#8a2a5e');
  }
  ctx.restore();
}

export function drawBarrier(ctx: Ctx, x: number, y0: number, y1: number, t: number): void {
  const pulse = 0.5 + 0.5 * Math.sin(t * 6);
  ctx.save();
  ctx.globalAlpha = 0.55 + pulse * 0.3;
  const g = ctx.createLinearGradient(x - 8, 0, x + 8, 0);
  g.addColorStop(0, 'rgba(255,90,60,0.1)');
  g.addColorStop(0.5, '#ff4d6d');
  g.addColorStop(1, 'rgba(255,90,60,0.1)');
  ctx.fillStyle = g;
  ctx.fillRect(x - 8, y0, 16, y1 - y0);
  ctx.globalAlpha = 0.9;
  ctx.fillStyle = '#ff8fa0';
  for (let i = 0; i < 4; i++) {
    const yy = y0 + ((t * 160 + i * 45) % (y1 - y0));
    ctx.beginPath();
    ctx.arc(x, yy, 3.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

// ---------- castle boss-realm decor ----------
function drawBgBat(ctx: Ctx, x: number, y: number, t: number, s: number): void {
  // distant bat silhouette circling the blood moon
  const flap = Math.sin(t * 4);
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.fillStyle = 'rgba(32,8,22,0.85)';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(-7, -5 - flap * 3, -13, -2 - flap * 4);
  ctx.quadraticCurveTo(-7, 1 + flap * 2, 0, 2);
  ctx.quadraticCurveTo(7, 1 + flap * 2, 13, -2 - flap * 4);
  ctx.quadraticCurveTo(7, -5 - flap * 3, 0, 0);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

export function drawCandelabra(ctx: Ctx, x: number, y: number, t: number): void {
  // gold candelabra with flickering flames (castle arena floor decor)
  ctx.save();
  ctx.translate(x, y);
  const g = ctx.createRadialGradient(0, -40, 4, 0, -40, 52);
  g.addColorStop(0, 'rgba(255,190,90,0.35)');
  g.addColorStop(1, 'rgba(255,190,90,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, -40, 52, 0, Math.PI * 2);
  ctx.fill();
  // stem + base
  ctx.strokeStyle = '#b98a3a';
  ctx.lineWidth = 3.5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, -26);
  ctx.stroke();
  ctx.fillStyle = '#8a6426';
  ctx.beginPath();
  ctx.ellipse(0, -1, 9, 3, 0, 0, Math.PI * 2);
  ctx.fill();
  // arms + candles + flames
  ctx.strokeStyle = '#b98a3a';
  ctx.lineWidth = 2.5;
  for (const dx of [-10, 0, 10]) {
    ctx.beginPath();
    ctx.moveTo(0, -26);
    ctx.quadraticCurveTo(dx * 0.6, -30, dx, -34);
    ctx.stroke();
    ctx.fillStyle = '#f3e6c8';
    ctx.fillRect(dx - 2, -44, 4, 10);
    const fw = Math.sin(t * 9 + dx * 3) * 1.2;
    const fg = ctx.createRadialGradient(dx, -48, 0.5, dx, -48, 7);
    fg.addColorStop(0, 'rgba(255,230,150,0.9)');
    fg.addColorStop(1, 'rgba(255,150,50,0)');
    ctx.fillStyle = fg;
    ctx.beginPath();
    ctx.arc(dx, -48, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffca55';
    ctx.beginPath();
    ctx.ellipse(dx + fw * 0.4, -49, 1.8, 3.4 + fw * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#fff3c4';
    ctx.beginPath();
    ctx.ellipse(dx + fw * 0.3, -48.4, 0.9, 1.7, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}
