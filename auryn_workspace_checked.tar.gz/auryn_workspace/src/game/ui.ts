// UI: menus, HUD, overlays
import { PALS, drawBackground, drawCastle, rr, text, heart, star, drawCoin, drawPickup } from './draw';
import { drawAuryn, drawBat, drawDandy, drawDandyFace, drawAurynFace, drawGrumblit, drawSpikeling, drawFlapper, drawShellby, drawSnapBloom } from './chars';
import { SaveData, VIEW_H, VIEW_W } from './types';

type Ctx = CanvasRenderingContext2D;

export interface Btn {
  x: number;
  y: number;
  w: number;
  h: number;
  label: string;
}

export function hitTest(btns: Btn[], mx: number, my: number): number {
  for (let i = 0; i < btns.length; i++) {
    const b = btns[i];
    if (mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h) return i;
  }
  return -1;
}

// ---------- shared widgets ----------
export function drawBtn(ctx: Ctx, b: Btn, selected: boolean, t: number): void {
  const pulse = selected ? 1 + Math.sin(t * 6) * 0.03 : 1;
  const cx = b.x + b.w / 2;
  const cy = b.y + b.h / 2;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(pulse, pulse);
  ctx.translate(-cx, -cy);
  const g = ctx.createLinearGradient(0, b.y, 0, b.y + b.h);
  if (selected) {
    g.addColorStop(0, '#ffa5d4');
    g.addColorStop(1, '#ff4f9e');
  } else {
    g.addColorStop(0, '#f2b9d9');
    g.addColorStop(1, '#d97bb1');
  }
  ctx.fillStyle = g;
  rr(ctx, b.x, b.y, b.w, b.h, 16);
  ctx.fill();
  ctx.strokeStyle = selected ? '#fff' : '#a2487c';
  ctx.lineWidth = selected ? 3.5 : 2.5;
  ctx.stroke();
  text(ctx, b.label, cx, cy + 1, selected ? 19 : 17, '#fff', { stroke: '#7a2b56', strokeW: 4 });
  if (selected) star(ctx, b.x - 14, cy + Math.sin(t * 5) * 3, 8, 3.8, 5, '#ffe14d', '#d99a00', t * 3);
  ctx.restore();
}

function panel(ctx: Ctx, x: number, y: number, w: number, h: number, alpha = 0.82): void {
  ctx.fillStyle = `rgba(40, 16, 40, ${alpha})`;
  rr(ctx, x, y, w, h, 18);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,143,199,0.85)';
  ctx.lineWidth = 3;
  ctx.stroke();
}

function starsDecor(ctx: Ctx, t: number): void {
  for (let i = 0; i < 6; i++) {
    const a = t * 0.9 + i * 1.05;
    const x = VIEW_W / 2 + Math.cos(a) * (250 + (i % 3) * 60);
    const y = 120 + Math.sin(a * 1.4) * 46 + i * 8;
    star(ctx, x, y, 5 + (i % 3), 2.4, 5, i % 2 ? '#ffe14d' : '#ff9ad5', '', a);
  }
}

// ---------- MAIN MENU ----------
export function menuButtons(soundOn: boolean): Btn[] {
  const labels = [
    'PLAY GAME',
    'WORLD SELECT',
    'HOW TO PLAY',
    'SETTINGS',
    soundOn ? 'SOUND: ON' : 'SOUND: OFF',
  ];
  const w = 300;
  const x = VIEW_W / 2 - w / 2;
  return labels.map((label, i) => ({ x, y: 268 + i * 54, w, h: 44, label }));
}

export function drawMenuScene(ctx: Ctx, t: number, sel: number, btns: Btn[], soundOn: boolean): void {
  drawBackground(ctx, 'hills', 40, t);
  // ground strip
  const pal = PALS.hills;
  ctx.fillStyle = pal.dirt;
  ctx.fillRect(0, 500, VIEW_W, 40);
  ctx.fillStyle = pal.grass;
  rr(ctx, -10, 492, VIEW_W + 20, 18, 8);
  ctx.fill();
  drawCastle(ctx, 800, 500, t);
  // characters
  drawAuryn(ctx, 150, 500, { facing: 1, run: 0, moving: false, onGround: true, vy: 0, attackT: 0, hurtT: 0, power: Math.sin(t) > 0.6, invuln: false, win: false, crouch: false, t });
  drawDandy(ctx, 810, 500, { facing: -1, run: 0, moving: false, onGround: true, vy: 0, mode: 'walk', throwT: 0, t, scale: 1.15 });
  text(ctx, 'AURYN', 150, 452, 15, '#ffd7ec', { stroke: '#7a2b56', strokeW: 4 });
  text(ctx, 'DANDY', 810, 452, 15, '#ffb0b0', { stroke: '#4a1030', strokeW: 4 });

  // title
  ctx.save();
  ctx.translate(VIEW_W / 2, 92);
  ctx.rotate(Math.sin(t * 1.4) * 0.012);
  text(ctx, "AURYN'S", 0, 0, 58, '#ff8fc7', { stroke: '#fff', strokeW: 9 });
  text(ctx, "AURYN'S", 0, 0, 58, '#ff5fa8', { stroke: '#8a2a5e', strokeW: 2.5 });
  text(ctx, 'PINK ADVENTURE', 0, 52, 34, '#fff', { stroke: '#ff5fa8', strokeW: 7 });
  ctx.restore();
  starsDecor(ctx, t);

  // floating hearts
  for (let i = 0; i < 5; i++) {
    const yy = 560 - ((t * 30 + i * 90) % 520);
    ctx.save();
    ctx.globalAlpha = 0.5;
    heart(ctx, 60 + i * 200 + Math.sin(t + i) * 14, yy, 8, 'rgba(255,143,199,0.8)', '');
    ctx.restore();
  }

  btns.forEach((b, i) => drawBtn(ctx, b, i === sel, t));
  text(ctx, 'v1.0 — a fantasy platformer', VIEW_W / 2, 532, 11, 'rgba(255,255,255,0.75)', {});
  void soundOn;
}

// ---------- WORLD SELECT ----------
export function worldButtons(unlocked: number): Btn[] {
  const btns: Btn[] = [];
  const names = ['Green Mushroom Hills', 'Blue Sky Kingdom', 'Enchanted Forest', 'Crystal Underground', 'Royal Fantasy Castle'];
  for (let i = 0; i < 5; i++) {
    const col = i % 3;
    const row = Math.floor(i / 3);
    btns.push({
      x: 105 + col * 265,
      y: 150 + row * 160,
      w: 235,
      h: 130,
      label: `WORLD ${i + 1} — ${names[i]}${i >= unlocked ? ' (LOCKED)' : ''}`,
    });
  }
  btns.push({ x: VIEW_W / 2 - 110, y: 480, w: 220, h: 44, label: 'BACK' });
  void unlocked;
  return btns;
}

export function drawWorldSelect(ctx: Ctx, t: number, sel: number, unlocked: number, best: number[]): void {
  drawBackground(ctx, 'hills', 0, t);
  ctx.fillStyle = 'rgba(30,10,35,0.55)';
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  text(ctx, 'WORLD SELECT', VIEW_W / 2, 62, 40, '#fff', { stroke: '#ff5fa8', strokeW: 8 });
  const btns = worldButtons(unlocked);
  const names = ['Green Mushroom Hills', 'Blue Sky Kingdom', 'Enchanted Forest', 'Crystal Underground', 'Royal Fantasy Castle'];
  const icons = ['hills', 'sky', 'forest', 'cave', 'castle'];
  for (let i = 0; i < 5; i++) {
    const b = btns[i];
    const locked = i >= unlocked;
    ctx.save();
    if (i === sel) {
      ctx.shadowColor = '#ff5fa8';
      ctx.shadowBlur = 18;
    }
    panel(ctx, b.x, b.y, b.w, b.h, locked ? 0.6 : 0.85);
    ctx.restore();
    // mini preview
    const px = b.x + 52;
    const py = b.y + 78;
    ctx.save();
    ctx.beginPath();
    rr(ctx, b.x + 14, b.y + 40, 76, 70, 10);
    ctx.clip();
    ctx.translate(b.x + 14, b.y + 40);
    drawBackground(ctx, icons[i] as 'hills', 0, t);
    ctx.translate(-b.x - 14, -b.y - 40);
    ctx.restore();
    if (icons[i] === 'castle') {
      ctx.fillStyle = '#8f99ad';
      ctx.fillRect(px - 30, py + 10, 60, 30);
      ctx.fillStyle = '#ff8fc7';
      ctx.beginPath();
      ctx.moveTo(px - 36, py + 10);
      ctx.lineTo(px, py - 14);
      ctx.lineTo(px + 36, py + 10);
      ctx.closePath();
      ctx.fill();
    } else {
      drawAuryn(ctx, px, py + 36, { facing: 1, run: t * 8, moving: !locked, onGround: true, vy: 0, attackT: 0, hurtT: 0, power: false, invuln: false, win: false, crouch: false, t });
    }
    text(ctx, `WORLD ${i + 1}`, b.x + b.w / 2 + 30, b.y + 34, 17, locked ? '#9a8fa5' : '#ffd7ec', { stroke: '#3a1030', strokeW: 4 });
    text(ctx, names[i], b.x + b.w / 2 + 30, b.y + 62, 12.5, locked ? '#8a7f95' : '#fff', { stroke: '#3a1030', strokeW: 3 });
    if (!locked && best[i] > 0) {
      text(ctx, `BEST ${best[i]}`, b.x + b.w / 2 + 30, b.y + 88, 11.5, '#ffe14d', { stroke: '#3a1030', strokeW: 3 });
    }
    if (locked) {
      text(ctx, 'LOCKED', b.x + b.w / 2 + 30, b.y + 108, 12, '#ffb0c8', { stroke: '#3a1030', strokeW: 3 });
    } else if (i === sel) {
      text(ctx, 'ENTER TO PLAY', b.x + b.w / 2 + 30, b.y + 108, 11.5, '#7fe38a', { stroke: '#3a1030', strokeW: 3 });
    }
  }
  drawBtn(ctx, btns[5], sel === 5, t);
}

// ---------- HOW TO PLAY ----------
export const howBackBtn: Btn = { x: VIEW_W / 2 - 110, y: 486, w: 220, h: 44, label: 'BACK' };

export function drawHowTo(ctx: Ctx, t: number, sel: number): void {
  drawBackground(ctx, 'forest', 30, t);
  ctx.fillStyle = 'rgba(30,10,35,0.62)';
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  text(ctx, 'HOW TO PLAY', VIEW_W / 2, 48, 36, '#fff', { stroke: '#ff5fa8', strokeW: 8 });

  // keyboard panel
  panel(ctx, 60, 84, 400, 250);
  text(ctx, 'KEYBOARD', 260, 110, 17, '#ffd7ec', { stroke: '#7a2b56', strokeW: 4 });
  const keys: [string, string][] = [
    ['A / D  or  ARROWS', 'Move left & right'],
    ['SPACE / W / UP', 'Jump (hold = higher)'],
    ['X  or  K', 'Pink magic attack'],
    ['DOWN on a pipe', 'Enter secret pipes'],
    ['ESC / P', 'Pause menu'],
  ];
  keys.forEach(([k, d], i) => {
    text(ctx, k, 84, 146 + i * 34, 13, '#ffe14d', { align: 'left', stroke: '#3a1030', strokeW: 3 });
    text(ctx, d, 250, 146 + i * 34, 12.5, '#fff', { align: 'left' });
  });

  // touch panel
  panel(ctx, 500, 84, 400, 250);
  text(ctx, 'TOUCH CONTROLS', 700, 110, 17, '#ffd7ec', { stroke: '#7a2b56', strokeW: 4 });
  const touch: [string, string][] = [
    ['LEFT / RIGHT buttons', 'Move Auryn'],
    ['A button (right)', 'Jump'],
    ['B button (right)', 'Magic attack'],
    ['DOWN button', 'Enter pipes'],
    ['II button', 'Pause'],
  ];
  touch.forEach(([k, d], i) => {
    text(ctx, k, 524, 146 + i * 34, 13, '#7fe38a', { align: 'left', stroke: '#3a1030', strokeW: 3 });
    text(ctx, d, 700, 146 + i * 34, 12.5, '#fff', { align: 'left' });
  });

  // items legend
  panel(ctx, 60, 344, 840, 128, 0.8);
  text(ctx, 'ITEMS & CREATURES', 480, 366, 15, '#ffd7ec', { stroke: '#7a2b56', strokeW: 4 });
  const items: [string, string][] = [
    ['coin', 'Coin +100'],
    ['mushroom', 'Magic Mushroom'],
    ['star', 'Star Shield'],
    ['crystal', 'Pink Crystal'],
    ['heart', 'Heart +1 HP'],
  ];
  items.forEach(([kind, label], i) => {
    const x = 105 + i * 118;
    drawCoin(ctx, x, 415, t + i, 1);
    if (kind !== 'coin') drawPickup(ctx, kind, x, 415, t + i);
    text(ctx, label, x, 448, 9.5, '#fff', {});
  });
  // creatures strip
  drawGrumblit(ctx, 672, 442, t, 1, false);
  text(ctx, 'Stomp!', 672, 452, 9, '#fff', {});
  drawSpikeling(ctx, 724, 444, t, 1, false);
  text(ctx, 'Use magic!', 724, 452, 9, '#fff', {});
  drawShellby(ctx, 778, 444, t, 1, 'walk', 0);
  text(ctx, 'Stomp & kick!', 778, 452, 9, '#fff', {});
  drawSnapBloom(ctx, 832, 452, 1, t);
  text(ctx, 'No touch!', 832, 452, 9, '#fff', {});
  drawFlapper(ctx, 882, 432, t, 1, false);
  drawDandy(ctx, 928, 440, { facing: -1, run: 0, moving: false, onGround: true, vy: 0, mode: 'taunt', throwT: 0, t, scale: 0.7 });
  text(ctx, 'DANDY!', 928, 452, 9, '#ff6b6b', {});
  drawBtn(ctx, howBackBtn, sel === 0, t);
}

// ---------- SETTINGS ----------
export function settingsButtons(save: SaveData): Btn[] {
  return [
    { x: VIEW_W / 2 - 170, y: 200, w: 340, h: 46, label: `SOUND EFFECTS: ${save.sound ? 'ON' : 'OFF'}` },
    { x: VIEW_W / 2 - 170, y: 258, w: 340, h: 46, label: `MUSIC: ${save.music ? 'ON' : 'OFF'}` },
    { x: VIEW_W / 2 - 170, y: 316, w: 340, h: 46, label: 'RESET PROGRESS' },
    { x: VIEW_W / 2 - 170, y: 374, w: 340, h: 46, label: 'BACK' },
  ];
}

export function drawSettings(ctx: Ctx, t: number, sel: number, save: SaveData): void {
  drawBackground(ctx, 'sky', 20, t);
  ctx.fillStyle = 'rgba(30,10,35,0.55)';
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  text(ctx, 'SETTINGS', VIEW_W / 2, 90, 40, '#fff', { stroke: '#ff5fa8', strokeW: 8 });
  drawAurynFace(ctx, VIEW_W / 2, 160, 1.4);
  const btns = settingsButtons(save);
  btns.forEach((b, i) => drawBtn(ctx, b, i === sel, t));
}

// ---------- PAUSE ----------
export function pauseButtons(): Btn[] {
  return [
    { x: VIEW_W / 2 - 140, y: 216, w: 280, h: 44, label: 'RESUME' },
    { x: VIEW_W / 2 - 140, y: 272, w: 280, h: 44, label: 'RESTART WORLD' },
    { x: VIEW_W / 2 - 140, y: 328, w: 280, h: 44, label: 'QUIT TO MENU' },
  ];
}

export function drawPause(ctx: Ctx, t: number, sel: number): void {
  ctx.fillStyle = 'rgba(20,8,25,0.7)';
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  text(ctx, 'PAUSED', VIEW_W / 2, 130, 44, '#fff', { stroke: '#ff5fa8', strokeW: 8 });
  drawAuryn(ctx, VIEW_W / 2 - 130, 460, { facing: 1, run: 0, moving: false, onGround: true, vy: 0, attackT: 0, hurtT: 0, power: false, invuln: false, win: false, crouch: false, t });
  drawDandy(ctx, VIEW_W / 2 + 130, 460, { facing: -1, run: 0, moving: false, onGround: true, vy: 0, mode: 'walk', throwT: 0, t, scale: 1 });
  pauseButtons().forEach((b, i) => drawBtn(ctx, b, i === sel, t));
}

// ---------- HUD ----------
export function drawHUD(
  ctx: Ctx, t: number,
  data: {
    lives: number; hp: number; maxHp: number; coins: number; score: number;
    worldLabel: string; progress: number; bossHp: number; bossMax: number; showBoss: boolean;
  }
): void {
  const pad = (n: number, w: number): string => String(Math.max(0, Math.floor(n))).padStart(w, '0');
  const chip = (x: number, y: number, w: number, h: number): void => {
    ctx.fillStyle = 'rgba(35,14,40,0.72)';
    rr(ctx, x, y, w, h, 14);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,143,199,0.8)';
    ctx.lineWidth = 2;
    ctx.stroke();
  };

  // ---- panel A: LIVES ×03 + hearts (like the reference art) ----
  chip(10, 10, 224, 74);
  drawAurynFace(ctx, 36, 38, 1.05);
  text(ctx, 'LIVES', 62, 25, 10, '#ffb0d4', { align: 'left', stroke: '#3a1030', strokeW: 3 });
  text(ctx, `×${pad(data.lives, 2)}`, 96, 26, 19, '#fff', { align: 'left', stroke: '#3a1030', strokeW: 3 });
  for (let i = 0; i < data.maxHp; i++) {
    const filled = i < data.hp;
    heart(ctx, 70 + i * 24, 55, filled ? 9 : 8, filled ? '#ff4f8b' : 'rgba(255,255,255,0.22)', filled ? '#c22b5e' : 'rgba(255,255,255,0.3)');
  }

  // ---- panel B: coins ×27 ----
  chip(244, 10, 112, 54);
  drawCoin(ctx, 268, 37, t * 2, 1.05);
  text(ctx, `×${pad(data.coins, 2)}`, 284, 43, 18, '#ffe14d', { align: 'left', stroke: '#3a1030', strokeW: 3 });

  // ---- panel C: SCORE 0003200 ----
  chip(VIEW_W - 232, 10, 222, 54);
  text(ctx, 'SCORE', VIEW_W - 121, 26, 10, '#ffb0d4', { stroke: '#3a1030', strokeW: 3 });
  text(ctx, pad(data.score, 7), VIEW_W - 121, 49, 21, '#fff', { stroke: '#3a1030', strokeW: 3 });

  // ---- world + progress bar (top right, second row) ----
  const px0 = VIEW_W - 302;
  chip(px0, 70, 292, 40);
  text(ctx, data.worldLabel, px0 + 146, 82, 10.5, '#ffd7ec', { stroke: '#3a1030', strokeW: 3 });
  const bw = 264;
  ctx.fillStyle = 'rgba(255,255,255,0.25)';
  rr(ctx, px0 + 14, 90, bw, 9, 4.5);
  ctx.fill();
  ctx.fillStyle = '#ff5fa8';
  rr(ctx, px0 + 14, 90, Math.max(6, bw * data.progress), 9, 4.5);
  ctx.fill();
  star(ctx, px0 + 14 + bw + 8, 94, 7, 3.2, 5, '#ffe14d', '#d99a00', t);

  // ---- boss bar: DANDY the Vampire Lord (avatar + ornate frame, per reference) ----
  if (data.showBoss) {
    const w = 340;
    const x = VIEW_W / 2 - w / 2 + 26;
    const by = 70;
    // drop shadow panel
    ctx.fillStyle = 'rgba(15,4,12,0.82)';
    rr(ctx, x - 10, by - 2, w + 20, 46, 14);
    ctx.fill();
    ctx.strokeStyle = '#ff4d6d';
    ctx.lineWidth = 2.5;
    ctx.stroke();
    // circular avatar with crimson ring
    ctx.save();
    ctx.beginPath();
    ctx.arc(x + 14, by + 21, 22, 0, Math.PI * 2);
    ctx.fillStyle = '#1c0712';
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#ff2e4d';
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(x + 14, by + 21, 19, 0, Math.PI * 2);
    ctx.clip();
    drawDandyFace(ctx, x + 14, by + 21, 1.7);
    ctx.restore();
    // name + title
    text(ctx, 'DANDY', x + 44, by + 12, 16, '#ff6b6b', { align: 'left', stroke: '#2a0812', strokeW: 4 });
    text(ctx, 'THE VAMPIRE LORD', x + 44, by + 24, 7.5, '#ffb0c0', { align: 'left', stroke: '#2a0812', strokeW: 3 });
    // HP bar with ornate frame
    const bx = x + 44;
    const bw = w - 106;
    const frac = data.bossMax > 0 ? data.bossHp / data.bossMax : 0;
    ctx.fillStyle = 'rgba(255,255,255,0.18)';
    rr(ctx, bx, by + 28, bw, 12, 6);
    ctx.fill();
    if (frac > 0) {
      const g = ctx.createLinearGradient(bx, 0, bx + bw, 0);
      g.addColorStop(0, '#ff2e4d');
      g.addColorStop(1, '#8a1030');
      ctx.fillStyle = g;
      rr(ctx, bx, by + 28, Math.max(8, bw * frac), 12, 6);
      ctx.fill();
      // glossy highlight
      ctx.fillStyle = 'rgba(255,255,255,0.3)';
      rr(ctx, bx + 2, by + 29.5, Math.max(4, bw * frac - 4), 4, 2);
      ctx.fill();
    }
    // phase pips (3 diamonds)
    const bossFrac = data.bossMax > 0 ? data.bossHp / data.bossMax : 0;
    for (let i = 0; i < 3; i++) {
      const lit = bossFrac > (2 - i) / 3;
      const pxx = bx + bw + 10 + i * 13;
      ctx.save();
      ctx.translate(pxx, by + 34);
      ctx.rotate(Math.PI / 4);
      ctx.fillStyle = lit ? '#ff2e4d' : 'rgba(255,255,255,0.2)';
      ctx.strokeStyle = '#2a0812';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.rect(-4, -4, 8, 8);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
    // bat icon at the right end (per reference asset)
    drawBat(ctx, x + w + 2, by + 22, t, 1);
  }
}

// ---------- TITLE CARD ----------
export function drawTitleCard(ctx: Ctx, world: number, name: string, t: number, lives: number): void {
  ctx.fillStyle = 'rgba(25,8,30,0.78)';
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  const k = Math.min(1, t * 2.4);
  ctx.save();
  ctx.translate(VIEW_W / 2, VIEW_H / 2 - 30);
  ctx.scale(k, k);
  text(ctx, `WORLD ${world}`, 0, -40, 52, '#ffd7ec', { stroke: '#ff5fa8', strokeW: 9 });
  text(ctx, name, 0, 16, 26, '#fff', { stroke: '#7a2b56', strokeW: 6 });
  if (world === 5) text(ctx, 'FINAL SHOWDOWN AWAITS...', 0, 58, 14, '#ffe14d', { stroke: '#3a1030', strokeW: 3 });
  ctx.restore();
  drawAurynFace(ctx, VIEW_W / 2 - 60, VIEW_H / 2 + 90, 1.5);
  text(ctx, `× ${lives}`, VIEW_W / 2 - 28, VIEW_H / 2 + 92, 22, '#fff', { align: 'left', stroke: '#3a1030', strokeW: 4 });
}

// ---------- LEVEL END ----------
export function drawLevelEnd(
  ctx: Ctx, t: number,
  stats: { coins: number; timeBonus: number; kills: number; score: number },
  done: boolean
): void {
  ctx.fillStyle = 'rgba(25,8,30,0.72)';
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  panel(ctx, VIEW_W / 2 - 240, 96, 480, 320);
  text(ctx, 'LEVEL CLEAR!', VIEW_W / 2, 146, 40, '#ffe14d', { stroke: '#ff5fa8', strokeW: 8 });
  for (let i = 0; i < 6; i++) {
    const a = t * 2 + i;
    star(ctx, VIEW_W / 2 + Math.cos(a) * 210, 146 + Math.sin(a) * 30, 6, 3, 5, '#fff', '#ff9ad5', a);
  }
  const rows: [string, string][] = [
    [`Coins collected`, `${stats.coins}`],
    [`Enemies defeated`, `${stats.kills}`],
    [`Time bonus`, `${stats.timeBonus}`],
    [`TOTAL SCORE`, `${stats.score}`],
  ];
  rows.forEach(([k, v], i) => {
    const y = 210 + i * 42;
    text(ctx, k, VIEW_W / 2 - 180, y, 17, i === 3 ? '#ffe14d' : '#fff', { align: 'left', stroke: '#3a1030', strokeW: 3 });
    text(ctx, v, VIEW_W / 2 + 180, y, 20, i === 3 ? '#ffe14d' : '#ffd7ec', { align: 'right', stroke: '#3a1030', strokeW: 4 });
  });
  if (done) {
    if (Math.floor(t * 2) % 2 === 0) text(ctx, 'PRESS JUMP / ENTER TO CONTINUE', VIEW_W / 2, 380, 14, '#7fe38a', { stroke: '#3a1030', strokeW: 3 });
  }
}

// ---------- GAME OVER ----------
export const gameOverButtons = (): Btn[] => [
  { x: VIEW_W / 2 - 140, y: 330, w: 280, h: 46, label: 'TRY AGAIN' },
  { x: VIEW_W / 2 - 140, y: 388, w: 280, h: 46, label: 'MENU' },
];

export function drawGameOver(ctx: Ctx, t: number, sel: number): void {
  ctx.fillStyle = 'rgba(30,6,18,0.82)';
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  text(ctx, 'GAME OVER', VIEW_W / 2, 150, 52, '#ff6b6b', { stroke: '#2a0812', strokeW: 10 });
  drawDandy(ctx, VIEW_W / 2, 300, { facing: 1, run: 0, moving: false, onGround: true, vy: 0, mode: 'taunt', throwT: 0, t, scale: 1.5 });
  text(ctx, '"Better luck next time, Auryn!"', VIEW_W / 2, 250, 16, '#ffb0c8', { stroke: '#2a0812', strokeW: 4 });
  gameOverButtons().forEach((b, i) => drawBtn(ctx, b, i === sel, t));
}

// ---------- VICTORY ----------
export const victoryButtons = (): Btn[] => [
  { x: VIEW_W / 2 - 140, y: 400, w: 280, h: 46, label: 'PLAY AGAIN' },
  { x: VIEW_W / 2 - 140, y: 458, w: 280, h: 46, label: 'MENU' },
];

export function drawVictory(
  ctx: Ctx, t: number, sel: number,
  stats: { coins: number; timeBonus: number; kills: number; score: number }
): void {
  const g = ctx.createLinearGradient(0, 0, 0, VIEW_H);
  g.addColorStop(0, '#4a1a52');
  g.addColorStop(1, '#ff8fc7');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  drawBackground(ctx, 'castle', 60, t);
  ctx.fillStyle = 'rgba(30,8,35,0.35)';
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  text(ctx, 'CONGRATULATIONS!', VIEW_W / 2, 96, 44, '#ffe14d', { stroke: '#ff5fa8', strokeW: 9 });
  text(ctx, 'Auryn opened the victory gate and saved the fantasy kingdom!', VIEW_W / 2, 140, 15, '#fff', { stroke: '#7a2b56', strokeW: 4 });
  drawAuryn(ctx, VIEW_W / 2 - 150, 330, { facing: 1, run: 0, moving: false, onGround: true, vy: 0, attackT: 0, hurtT: 0, power: true, invuln: false, win: true, crouch: false, t });
  text(ctx, 'AURYN', VIEW_W / 2 - 150, 356, 15, '#ffd7ec', { stroke: '#7a2b56', strokeW: 4 });
  drawDandy(ctx, VIEW_W / 2 + 150, 330, { facing: -1, run: 0, moving: false, onGround: true, vy: 0, mode: 'defeat', throwT: 0, t, scale: 1.2 });
  text(ctx, 'DANDY', VIEW_W / 2 + 150, 356, 15, '#ffb0b0', { stroke: '#4a1030', strokeW: 4 });
  for (let i = 0; i < 10; i++) {
    const a = t * 1.6 + i * 0.63;
    star(ctx, VIEW_W / 2 + Math.cos(a) * (180 + (i % 4) * 40), 230 + Math.sin(a * 1.3) * 40, 7, 3.2, 5, i % 2 ? '#ffe14d' : '#fff', '#ff9ad5', a);
  }
  text(ctx, `FINAL SCORE  ${stats.score}`, VIEW_W / 2, 200, 24, '#fff', { stroke: '#7a2b56', strokeW: 5 });
  text(ctx, `Coins ${stats.coins}   •   Time bonus ${stats.timeBonus}   •   Enemies ${stats.kills}`, VIEW_W / 2, 236, 14, '#ffd7ec', { stroke: '#3a1030', strokeW: 3 });
  victoryButtons().forEach((b, i) => drawBtn(ctx, b, i === sel, t));
}
