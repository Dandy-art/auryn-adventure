// Procedural audio engine: chiptune music loops + synthesized SFX (Web Audio API)
const NOTE_RE = /^([A-G])(#|b)?(\d)$/;
const SEMI: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };

export function noteFreq(n: string): number {
  const m = NOTE_RE.exec(n);
  if (!m) return 0;
  let s = SEMI[m[1]];
  if (m[2] === '#') s += 1;
  if (m[2] === 'b') s -= 1;
  const midi = (parseInt(m[3], 10) + 1) * 12 + s;
  return 440 * Math.pow(2, (midi - 69) / 12);
}

interface TrackDef {
  bpm: number;
  mel: (string | null)[];
  bass: (string | null)[];
  melWave: OscillatorType;
  bassWave: OscillatorType;
  drums: string; // per step: k=kick h=hat s=snare .=none
  melVol?: number;
  bassVol?: number;
}

const R = null;
// --- Music tracks (8th-note grids, 32 steps = 4 bars) ---
const TRACKS: Record<string, TrackDef> = {
  menu: {
    bpm: 116,
    mel: ['C5', R, 'E5', R, 'G5', R, 'E5', R, 'A5', R, 'G5', R, 'E5', 'D5', R, R,
      'C5', R, 'E5', R, 'G5', R, 'A5', R, 'G5', R, 'E5', R, 'D5', R, 'C5', R],
    bass: ['C3', 'G2', 'C3', 'G2', 'A2', 'E2', 'A2', 'E2', 'F2', 'C3', 'F2', 'C3', 'G2', 'G2', 'B2', 'D3',
      'C3', 'G2', 'C3', 'G2', 'A2', 'E2', 'A2', 'E2', 'F2', 'C3', 'F2', 'C3', 'G2', 'B2', 'C3', 'C3'],
    melWave: 'square', bassWave: 'triangle',
    drums: 'k.h.s.h.k.h.s.hkk.h.s.h.k.hhs.h.',
  },
  world1: {
    bpm: 128,
    mel: ['D5', R, 'G5', R, 'B5', R, 'A5', 'G5', 'E5', R, 'G5', R, 'D5', R, 'B4', R,
      'C5', R, 'E5', R, 'A5', R, 'G5', R, 'F#5', R, 'D5', R, 'E5', R, 'G5', R],
    bass: ['G2', 'D3', 'G2', 'D3', 'E2', 'B2', 'E2', 'B2', 'C3', 'G2', 'C3', 'G2', 'D3', 'A2', 'D3', 'A2',
      'G2', 'D3', 'G2', 'D3', 'E2', 'B2', 'E2', 'B2', 'C3', 'C3', 'D3', 'D3', 'G2', 'B2', 'D3', 'G2'],
    melWave: 'square', bassWave: 'triangle',
    drums: 'k.h.s.h.k.hks.h.k.h.s.h.k.hhshh.',
  },
  world2: {
    bpm: 122,
    mel: ['F5', R, 'A5', 'C6', 'A5', R, 'F5', R, 'D5', R, 'F5', 'G5', 'A5', R, R, R,
      'C6', R, 'A5', 'F5', 'G5', R, 'E5', R, 'F5', R, 'G5', 'A5', 'F5', R, R, R],
    bass: ['F2', 'C3', 'F2', 'C3', 'D3', 'A2', 'D3', 'A2', 'Bb2', 'F2', 'Bb2', 'F2', 'C3', 'G2', 'C3', 'C3',
      'F2', 'C3', 'F2', 'C3', 'D3', 'A2', 'D3', 'A2', 'Bb2', 'Bb2', 'C3', 'C3', 'F2', 'A2', 'C3', 'F2'],
    melWave: 'triangle', bassWave: 'triangle',
    drums: 'k.h.s.h.k.h.s.h.k.h.s.h.k.hhs.h.',
  },
  world3: {
    bpm: 132,
    mel: ['E5', 'G5', 'B5', R, 'A5', 'G5', 'E5', R, 'D5', 'E5', 'G5', R, 'E5', R, R, R,
      'E5', 'G5', 'B5', R, 'C6', 'B5', 'A5', R, 'G5', 'E5', 'D5', 'E5', 'E5', R, R, R],
    bass: ['E2', 'E3', 'E2', 'B2', 'C3', 'C3', 'G2', 'G2', 'A2', 'A2', 'E2', 'E2', 'B2', 'B2', 'B2', 'B2',
      'E2', 'E3', 'E2', 'B2', 'C3', 'C3', 'G2', 'G2', 'A2', 'B2', 'C3', 'B2', 'E2', 'G2', 'B2', 'E2'],
    melWave: 'square', bassWave: 'sawtooth',
    drums: 'k.hks.hkk.hks.h.k.hks.hkk.hhs.hh.',
  },
  world4: {
    bpm: 104,
    mel: ['D5', R, R, 'F5', R, R, 'A5', R, 'G5', R, R, 'E5', R, R, 'D5', R,
      'D5', R, R, 'F5', R, R, 'Bb5', R, 'A5', R, 'G5', R, 'E5', R, 'C5', R],
    bass: ['D2', R, 'D2', R, 'D2', R, 'A2', R, 'G2', R, 'G2', R, 'D2', R, 'D2', R,
      'Bb2', R, 'Bb2', R, 'G2', R, 'G2', R, 'A2', R, 'A2', R, 'D2', R, 'A2', R],
    melWave: 'triangle', bassWave: 'sawtooth',
    drums: 'k...h...k...h...k...h...k..hh...',
  },
  world5: {
    bpm: 138,
    mel: ['A5', R, 'A5', 'G5', 'A5', R, 'E5', R, 'C5', R, 'E5', 'G5', 'A5', R, R, R,
      'A5', R, 'A5', 'G5', 'A5', R, 'C6', R, 'B5', 'A5', 'G#5', 'E5', 'A5', R, R, R],
    bass: ['A2', 'A2', 'E2', 'E2', 'A2', 'A2', 'E2', 'E2', 'F2', 'F2', 'C3', 'C3', 'G2', 'G2', 'E2', 'E2',
      'A2', 'A2', 'E2', 'E2', 'F2', 'F2', 'F2', 'F2', 'E2', 'E2', 'E2', 'E2', 'A2', 'E2', 'A2', 'A2'],
    melWave: 'square', bassWave: 'sawtooth',
    drums: 'k.hks.hkk.hks.h.k.hks.hkkhhks.hh.',
  },
  boss: {
    bpm: 150,
    mel: ['C5', 'C5', R, 'Eb5', 'C5', 'C5', R, 'G5', 'F5', R, 'Eb5', R, 'D5', R, 'C5', R,
      'C5', 'C5', R, 'Eb5', 'G5', R, 'Ab5', 'G5', 'F5', 'Eb5', 'D5', 'Eb5', 'C5', R, R, R],
    bass: ['C2', 'C2', 'C2', 'C2', 'G2', 'G2', 'G2', 'G2', 'Ab2', 'Ab2', 'Ab2', 'Ab2', 'G2', 'G2', 'B2', 'B2',
      'C2', 'C2', 'C2', 'C2', 'G2', 'G2', 'G2', 'G2', 'Ab2', 'B2', 'C3', 'B2', 'C2', 'G2', 'C2', 'C2'],
    melWave: 'square', bassWave: 'sawtooth',
    drums: 'khhskhhkkhhskhhkkhhskhhkkhhskhhk',
  },
  victory: {
    bpm: 120,
    mel: ['G5', R, 'G5', 'G5', 'C6', R, 'B5', 'A5', 'G5', 'A5', 'B5', 'C6', 'D6', R, R, R,
      'E6', R, 'D6', 'C6', 'B5', R, 'A5', 'B5', 'C6', R, R, R, 'C6', R, R, R],
    bass: ['C3', R, 'G2', R, 'C3', R, 'G2', R, 'A2', R, 'E2', R, 'F2', R, 'G2', R,
      'C3', R, 'G2', R, 'A2', R, 'F2', R, 'C3', R, 'G2', R, 'C3', R, 'C3', R],
    melWave: 'square', bassWave: 'triangle',
    drums: 'k.h.s.h.k.h.s.h.k.h.s.h.k.hhs.h.',
  },
};

type SfxName =
  | 'jump' | 'coin' | 'stomp' | 'bump' | 'break' | 'powerup' | 'pipe' | 'hurt'
  | 'magic' | 'enemyDie' | 'checkpoint' | 'flag' | 'uiMove' | 'uiSelect' | 'heart'
  | 'crystal' | 'star' | 'bossHit' | 'roar' | 'dandyHit' | 'dandyDefeat' | 'gate'
  | 'death' | 'gameover' | 'victory' | 'shoot' | 'warp' | 'kick' | 'bat';

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  soundOn = true;
  musicOn = true;
  private trackName: string | null = null;
  private step = 0;
  private nextTime = 0;
  private timer: ReturnType<typeof setInterval> | null = null;

  /** Must be called from a user gesture to unlock audio. */
  unlock(): void {
    if (!this.ctx) {
      type Ctor = typeof AudioContext;
      const W = window as unknown as { AudioContext: Ctor; webkitAudioContext?: Ctor };
      const Ctx = W.AudioContext || W.webkitAudioContext;
      if (!Ctx) return;
      this.ctx = new Ctx();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.8;
      this.master.connect(this.ctx.destination);
      this.musicBus = this.ctx.createGain();
      this.musicBus.gain.value = 0.5;
      this.musicBus.connect(this.master);
      this.sfxBus = this.ctx.createGain();
      this.sfxBus.gain.value = 0.9;
      this.sfxBus.connect(this.master);
      this.timer = setInterval(() => this.pump(), 60);
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
  }

  setSound(on: boolean): void {
    this.soundOn = on;
    if (this.sfxBus) this.sfxBus.gain.value = on ? 0.9 : 0;
  }
  setMusic(on: boolean): void {
    this.musicOn = on;
    if (this.musicBus) this.musicBus.gain.value = on ? 0.5 : 0;
  }

  // ---------- music ----------
  playMusic(name: string): void {
    if (this.trackName === name) return;
    this.trackName = name;
    this.step = 0;
    const t = TRACKS[name];
    if (this.ctx) this.nextTime = this.ctx.currentTime + 0.08;
    else this.nextTime = 0;
    if (t && this.musicOn) this.pump();
  }
  stopMusic(): void {
    this.trackName = null;
  }

  private pump(): void {
    if (!this.ctx || !this.musicBus) return;
    const name = this.trackName;
    if (!name || !this.musicOn) return;
    const tr = TRACKS[name];
    if (!tr) return;
    if (this.nextTime < this.ctx.currentTime) {
      // resync (first unlock, tab sleep, or drift)
      this.nextTime = this.ctx.currentTime + 0.06;
    }
    const stepDur = 30 / tr.bpm; // 8th note
    while (this.nextTime < this.ctx.currentTime + 0.18) {
      this.scheduleStep(tr, this.step, this.nextTime, stepDur);
      this.step = (this.step + 1) % 32;
      this.nextTime += stepDur;
    }
  }

  private scheduleStep(tr: TrackDef, step: number, time: number, dur: number): void {
    if (!this.ctx || !this.musicBus) return;
    const melN = tr.mel[step];
    if (melN) this.blip(noteFreq(melN), time, dur * 0.92, tr.melWave, tr.melVol ?? 0.16, this.musicBus);
    const bassN = tr.bass[step];
    if (bassN) this.blip(noteFreq(bassN), time, dur * 0.95, tr.bassWave, tr.bassVol ?? 0.2, this.musicBus);
    const d = tr.drums[step];
    if (d === 'k') this.kick(time);
    else if (d === 'h') this.hat(time);
    else if (d === 's') this.snare(time);
  }

  private blip(freq: number, time: number, dur: number, wave: OscillatorType, vol: number, dest: AudioNode): void {
    if (!this.ctx || freq <= 0) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = wave;
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, time);
    g.gain.linearRampToValueAtTime(vol, time + 0.012);
    g.gain.setValueAtTime(vol, time + dur * 0.6);
    g.gain.exponentialRampToValueAtTime(0.0001, time + dur);
    o.connect(g);
    g.connect(dest);
    o.start(time);
    o.stop(time + dur + 0.02);
  }

  private kick(time: number): void {
    if (!this.ctx || !this.musicBus) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = 'sine';
    o.frequency.setValueAtTime(150, time);
    o.frequency.exponentialRampToValueAtTime(40, time + 0.1);
    g.gain.setValueAtTime(0.5, time);
    g.gain.exponentialRampToValueAtTime(0.001, time + 0.12);
    o.connect(g);
    g.connect(this.musicBus);
    o.start(time);
    o.stop(time + 0.14);
  }
  private hat(time: number): void {
    this.noiseBurst(time, 0.03, 0.06, 7000, this.musicBus);
  }
  private snare(time: number): void {
    this.noiseBurst(time, 0.09, 0.14, 2200, this.musicBus);
  }
  private noiseBurst(time: number, dur: number, vol: number, hp: number, dest: AudioNode | null): void {
    if (!this.ctx || !dest) return;
    const len = Math.max(1, Math.floor(this.ctx.sampleRate * dur));
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const f = this.ctx.createBiquadFilter();
    f.type = 'highpass';
    f.frequency.value = hp;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, time);
    g.gain.exponentialRampToValueAtTime(0.001, time + dur);
    src.connect(f);
    f.connect(g);
    g.connect(dest);
    src.start(time);
    src.stop(time + dur + 0.02);
  }

  // ---------- sfx ----------
  sfx(name: SfxName): void {
    if (!this.ctx || !this.sfxBus || !this.soundOn) return;
    const t = this.ctx.currentTime + 0.001;
    const bus = this.sfxBus;
    const tone = (
      f0: number, f1: number, dur: number, wave: OscillatorType, vol: number, delay = 0
    ): void => {
      const o = this.ctx!.createOscillator();
      const g = this.ctx!.createGain();
      o.type = wave;
      const st = t + delay;
      o.frequency.setValueAtTime(f0, st);
      if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), st + dur);
      g.gain.setValueAtTime(0.0001, st);
      g.gain.linearRampToValueAtTime(vol, st + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0001, st + dur);
      o.connect(g);
      g.connect(bus);
      o.start(st);
      o.stop(st + dur + 0.03);
    };
    switch (name) {
      case 'jump': tone(260, 660, 0.18, 'square', 0.22); break;
      case 'coin': tone(1046, 1046, 0.07, 'square', 0.2); tone(1568, 1568, 0.18, 'square', 0.2, 0.07); break;
      case 'stomp': this.noiseBurst(t, 0.12, 0.3, 500, bus); tone(420, 120, 0.14, 'triangle', 0.3); break;
      case 'bump': tone(180, 90, 0.1, 'triangle', 0.3); break;
      case 'kick': tone(520, 140, 0.12, 'square', 0.28); this.noiseBurst(t, 0.06, 0.18, 1200, bus); break;
      case 'break': this.noiseBurst(t, 0.16, 0.28, 900, bus); tone(300, 80, 0.15, 'square', 0.18); break;
      case 'powerup':
        [523, 659, 784, 1046, 1318].forEach((f, i) => tone(f, f, 0.1, 'square', 0.18, i * 0.07));
        break;
      case 'heart': tone(660, 990, 0.2, 'sine', 0.25); tone(990, 1320, 0.2, 'sine', 0.2, 0.12); break;
      case 'crystal': tone(1318, 1760, 0.25, 'sine', 0.22); tone(2637, 2637, 0.2, 'sine', 0.12, 0.1); break;
      case 'star':
        [784, 988, 1175, 1568, 1976].forEach((f, i) => tone(f, f, 0.09, 'triangle', 0.2, i * 0.06));
        break;
      case 'pipe': tone(500, 120, 0.45, 'square', 0.25); break;
      case 'warp': tone(200, 900, 0.4, 'sine', 0.22); break;
      case 'hurt': tone(400, 110, 0.28, 'sawtooth', 0.28); break;
      case 'magic': tone(880, 1760, 0.12, 'sine', 0.2); tone(1760, 440, 0.16, 'triangle', 0.15, 0.05); break;
      case 'shoot': tone(320, 180, 0.2, 'sawtooth', 0.2); break;
      case 'enemyDie': this.noiseBurst(t, 0.2, 0.25, 800, bus); tone(600, 100, 0.22, 'triangle', 0.2); break;
      case 'checkpoint': tone(784, 784, 0.12, 'square', 0.2); tone(1175, 1175, 0.25, 'square', 0.2, 0.12); break;
      case 'flag':
        [523, 659, 784, 1046].forEach((f, i) => tone(f, f, 0.16, 'square', 0.22, i * 0.12));
        break;
      case 'gate': tone(140, 700, 0.6, 'sine', 0.25); break;
      case 'bossHit': tone(240, 90, 0.16, 'sawtooth', 0.3); this.noiseBurst(t, 0.08, 0.2, 1400, bus); break;
      case 'roar': tone(140, 60, 0.7, 'sawtooth', 0.4); tone(90, 45, 0.8, 'square', 0.3, 0.05); break;
      case 'dandyHit': tone(500, 200, 0.14, 'square', 0.25); break;
      case 'dandyDefeat':
        tone(600, 80, 0.8, 'sawtooth', 0.3);
        [784, 659, 523, 392].forEach((f, i) => tone(f, f * 0.8, 0.18, 'square', 0.2, 0.15 * i));
        break;
      case 'death': tone(600, 100, 0.9, 'square', 0.3); break;
      case 'gameover':
        [392, 330, 262, 196].forEach((f, i) => tone(f, f, 0.3, 'triangle', 0.25, i * 0.28));
        break;
      case 'victory':
        [523, 659, 784, 1046, 784, 1046, 1318].forEach((f, i) =>
          tone(f, f, 0.18, 'square', 0.22, i * 0.14)
        );
        break;
      case 'uiMove': tone(600, 700, 0.06, 'square', 0.14); break;
      case 'uiSelect': tone(700, 1050, 0.12, 'square', 0.2); break;
      case 'bat':
        // screech — bat familiar summoned
        tone(1900, 2600, 0.14, 'sawtooth', 0.14);
        tone(2400, 1500, 0.18, 'sawtooth', 0.1, 0.1);
        this.noiseBurst(t, 0.12, 0.08, 3200, bus);
        break;
    }
  }

  destroy(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    if (this.ctx) void this.ctx.close();
    this.ctx = null;
  }
}
